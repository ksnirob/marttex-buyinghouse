import { j as jsxRuntimeExports } from "../_libs/react.mjs";
import { S as SiteLayout, P as PageHeader } from "./Layout-F5tIfk4_.mjs";
import { f as factory, s as sourcing } from "./router-Cn102jAX.mjs";
import { y as Shirt, g as ClipboardCheck, j as FlaskConical, u as Ruler, x as ShieldCheck, F as Factory, G as Gauge, P as PackageCheck } from "../_libs/lucide-react.mjs";
import "../_libs/tanstack__react-router.mjs";
import "../_libs/tanstack__router-core.mjs";
import "../_libs/tanstack__history.mjs";
import "../_libs/cookie-es.mjs";
import "../_libs/seroval.mjs";
import "../_libs/seroval-plugins.mjs";
import "node:stream/web";
import "node:stream";
import "../_libs/react-dom.mjs";
import "util";
import "crypto";
import "async_hooks";
import "stream";
import "../_libs/isbot.mjs";
import "../_libs/tanstack__query-core.mjs";
import "../_libs/tanstack__react-query.mjs";
const stats = [{
  value: "2010",
  label: "Established"
}, {
  value: "14,000",
  label: "Sq ft production space"
}, {
  value: "149",
  label: "Listed machines"
}, {
  value: "2M+",
  label: "Own factory pieces / year"
}];
const products = [{
  title: "Womenswear",
  items: "T-shirts, polos, sweatshirts, hoodies, skirts, dresses, tops, blouses and tank tops."
}, {
  title: "Menswear",
  items: "T-shirts, polos, sweatshirts, hoodies, underwear, boxers, shorts, swimming shorts and briefs."
}, {
  title: "Kidswear",
  items: "Hoodies, frocks with lace, floral and sequins, girls' skirts, T-shirts, polos, sweatshirts and underwear."
}, {
  title: "Bottoms & Denim",
  items: "Knit or woven trousers, denim pants, shorts, skirts and boxers in canvas, twill, bedford, ripstop and denim."
}];
const qualitySops = ["Fabric and shade band inspection", "Trim and accessories inspection", "Pattern, spreading and cutting control", "Sewing quality and measurement checks", "Needle, sharp edge and metal detection control", "Finishing, packing and final inspection"];
const machines = [{
  name: "Plain stitching",
  qty: "50",
  type: "Sewing"
}, {
  name: "Overlock",
  qty: "45",
  type: "Sewing"
}, {
  name: "Flat bed",
  qty: "12",
  type: "Sewing"
}, {
  name: "Cylinder bed",
  qty: "6",
  type: "Special"
}, {
  name: "Iron tables",
  qty: "6",
  type: "Finishing"
}, {
  name: "Cutting machines",
  qty: "2",
  type: "Cutting"
}, {
  name: "Generator",
  qty: "150 KV",
  type: "Utility"
}];
function Profile() {
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(SiteLayout, { children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx(PageHeader, { eyebrow: "Company profile", title: "Mart Tex apparel manufacturing and sourcing capability.", lead: "A Bangladesh readymade garment manufacturer, supplier and exporter producing knitwear in-house while sourcing woven, denim and lingerie programs through partner factories." }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("section", { className: "section-reveal bg-white py-20 md:py-28", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "container-x grid gap-12 lg:grid-cols-[1.05fr_0.95fr]", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "eyebrow", children: "Overview" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "mt-3 font-display text-4xl text-primary md:text-5xl", children: "Production, sourcing and supply chain under one accountable team." }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-6 text-muted-foreground", children: "Mart Tex is an apparel manufacturing, international garment sourcing and supply chain management company focused on delivering the right goods to the right place at the right time. The company produces around 2 million pieces of garments per year in its own facility and can supply more than 20 million pieces through partner factories." }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-4 text-muted-foreground", children: "Its own factory focuses mainly on knitwear, with partner capability across woven, denim and lingerie programs. Payment modes include L/C and TT, with FOB, CIF and CF terms available." })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "grid gap-4 sm:grid-cols-2", children: stats.map((s) => /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rounded-2xl border border-border bg-[oklch(0.985_0.006_205)] p-6", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "font-display text-4xl text-primary", children: s.value }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-2 text-sm text-muted-foreground", children: s.label })
      ] }, s.label)) })
    ] }) }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("section", { className: "section-reveal bg-[linear-gradient(180deg,oklch(0.95_0.014_205)_0%,oklch(0.985_0.004_205)_100%)] py-20 md:py-28", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "container-x grid gap-12 lg:grid-cols-[0.95fr_1.05fr]", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("img", { src: factory, alt: "Garment production floor", width: 1600, height: 1e3, loading: "lazy", className: "aspect-[5/4] w-full rounded-3xl object-cover shadow-[0_30px_80px_-55px_oklch(0.22_0.04_220/0.55)]" }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "eyebrow", children: "Product capability" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "mt-3 font-display text-4xl text-primary md:text-5xl", children: "Knitwear, woven bottoms, denim and kidswear programs." }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "mt-8 grid gap-4 sm:grid-cols-2", children: products.map((product) => /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rounded-2xl border border-white/80 bg-white p-6 shadow-sm", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Shirt, { className: "h-6 w-6 text-primary" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "mt-4 font-display text-2xl text-primary", children: product.title }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-2 text-sm text-muted-foreground", children: product.items })
        ] }, product.title)) })
      ] })
    ] }) }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("section", { className: "section-reveal bg-white py-20 md:py-28", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "container-x", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid gap-12 lg:grid-cols-[0.8fr_1.2fr]", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "eyebrow", children: "Quality assurance" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "mt-3 font-display text-4xl text-primary md:text-5xl", children: "Built-in quality from fabric to final packing." }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-6 text-muted-foreground", children: "The profile describes a zero-defect quality mindset supported by SOPs throughout fabric inspection, cutting, sewing, finishing and final inspection." })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "grid gap-4 sm:grid-cols-2", children: qualitySops.map((item) => /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex gap-3 rounded-2xl border border-border bg-card p-5", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(ClipboardCheck, { className: "mt-0.5 h-5 w-5 shrink-0 text-primary" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm text-muted-foreground", children: item })
        ] }, item)) })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-14 grid gap-6 lg:grid-cols-3", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(Feature, { icon: FlaskConical, title: "Laboratory testing", text: "Pre-production, production and shipment samples can be tested through accredited labs such as Intertek, SGS, Bureau Veritas, TUV and UL." }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(Feature, { icon: Ruler, title: "Inspection steps", text: "Pre-production, during-production and final inspections cover fabric, measurements, trims, workmanship, packing and assortment." }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(Feature, { icon: ShieldCheck, title: "Safety control", text: "Workplace and product safety areas include building, fire, health, electrical, chemical, washing and raw material controls." })
      ] })
    ] }) }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("section", { className: "section-reveal bg-[oklch(0.24_0.07_205)] py-20 text-white md:py-28", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "container-x grid items-start gap-12 lg:grid-cols-[0.95fr_1.05fr]", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "eyebrow text-white/70", children: "Machine resources" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "font-display text-4xl text-white md:text-5xl", children: "A practical machine base for knit and light woven production." }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-6 max-w-2xl text-white/70", children: "The profile lists core sewing, cutting, finishing and utility equipment, including plain stitching, overlock, flat bed, cylinder bed, bar tack, button stitch, button hole, cutting, boiler and generator resources." })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "rounded-3xl border border-white/15 bg-white/8 p-5 shadow-[0_30px_90px_-70px_black] backdrop-blur", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid gap-4 sm:grid-cols-2", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "rounded-2xl border border-accent/20 bg-[oklch(0.31_0.075_214)] p-6 text-white sm:col-span-2", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between gap-4", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs font-medium uppercase tracking-[0.22em] text-white/55", children: "Total listed resources" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-2 font-display text-5xl", children: "149" })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "grid h-14 w-14 place-items-center rounded-2xl bg-accent text-accent-foreground", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Factory, { className: "h-7 w-7" }) })
        ] }) }),
        machines.map((machine) => /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "rounded-2xl border border-white/12 bg-white/10 p-5 transition hover:-translate-y-0.5 hover:bg-white/15", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-start justify-between gap-4", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs uppercase tracking-[0.18em] text-white/45", children: machine.type }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "mt-2 text-sm font-medium text-white", children: machine.name })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "font-display text-3xl leading-none text-white", children: machine.qty })
        ] }) }, machine.name))
      ] }) })
    ] }) }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("section", { className: "section-reveal bg-white py-20 md:py-28", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "container-x grid gap-8 lg:grid-cols-3", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rounded-3xl border border-border bg-card p-8", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(Factory, { className: "h-8 w-8 text-primary" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "mt-5 font-display text-2xl text-primary", children: "Factory address" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-3 text-sm text-muted-foreground", children: "Nikunja-02, Road-09, House-07, Khilkhet, Dhaka-1229, Bangladesh." })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rounded-3xl border border-border bg-card p-8", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(Gauge, { className: "h-8 w-8 text-primary" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "mt-5 font-display text-2xl text-primary", children: "Capacity model" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-3 text-sm text-muted-foreground", children: "Own factory knitwear production with partner factory support for larger and more varied product programs." })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rounded-3xl border border-border bg-card p-8", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(PackageCheck, { className: "h-8 w-8 text-primary" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "mt-5 font-display text-2xl text-primary", children: "Payment terms" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-3 text-sm text-muted-foreground", children: "L/C and TT payment modes with FOB, CIF and CF commercial terms." })
      ] })
    ] }) }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("section", { className: "section-reveal container-x pb-24 md:pb-32", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative overflow-hidden rounded-3xl", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("img", { src: sourcing, alt: "Garments and sourcing materials", width: 1600, height: 1e3, loading: "lazy", className: "h-80 w-full object-cover md:h-[28rem]" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "absolute inset-0 bg-gradient-to-r from-primary/90 via-primary/55 to-transparent" }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "absolute inset-y-0 left-0 flex max-w-2xl flex-col justify-center p-8 text-primary-foreground md:p-12", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "eyebrow text-primary-foreground/70", children: "Quality culture" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "mt-3 font-display text-4xl md:text-5xl", children: "Control the value chain before defects reach the buyer." }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-5 max-w-lg text-sm leading-relaxed text-primary-foreground/80", children: "Mart Tex's quality system focuses on early detection across fabric, trims, cutting, sewing, finishing and final inspection, supported by lab testing where required." })
      ] })
    ] }) })
  ] });
}
function Feature({
  icon: Icon,
  title,
  text
}) {
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rounded-2xl border border-border bg-[oklch(0.985_0.006_205)] p-7", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx(Icon, { className: "h-7 w-7 text-primary" }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "mt-5 font-display text-2xl text-primary", children: title }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-2 text-sm text-muted-foreground", children: text })
  ] });
}
export {
  Profile as component
};
