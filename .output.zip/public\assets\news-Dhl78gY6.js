import{j as t,O as o}from"./index-DM_E0Tci.js";const n=()=>t.jsx(o,{});export{n as component};
