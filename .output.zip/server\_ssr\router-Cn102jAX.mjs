import { Q as QueryClient } from "../_libs/tanstack__query-core.mjs";
import { Q as QueryClientProvider } from "../_libs/tanstack__react-query.mjs";
import { b as createRouter, a as createRootRouteWithContext, d as useRouter, L as Link, O as Outlet, H as HeadContent, S as Scripts, c as createFileRoute, l as lazyRouteComponent, u as useLocation } from "../_libs/tanstack__react-router.mjs";
import { j as jsxRuntimeExports, r as reactExports } from "../_libs/react.mjs";
import "../_libs/tanstack__router-core.mjs";
import "../_libs/tanstack__history.mjs";
import "../_libs/cookie-es.mjs";
import "../_libs/seroval.mjs";
import "../_libs/seroval-plugins.mjs";
import "node:stream/web";
import "node:stream";
import "../_libs/react-dom.mjs";
import "util";
import "crypto";
import "async_hooks";
import "stream";
import "../_libs/isbot.mjs";
const appCss = "/assets/styles-B-1pBU68.css";
const API_URL = "https://api.marttex.net";
function assetUrl(value) {
  if (!value) return "";
  if (/^https?:\/\//i.test(value)) return value;
  return `${API_URL}${value.startsWith("/") ? "" : "/"}${value}`;
}
async function getPublicSiteData() {
  const [settingsResponse, categoriesResponse] = await Promise.all([
    fetch(`${API_URL}/api/site-settings`),
    fetch(`${API_URL}/api/categories`)
  ]);
  if (!settingsResponse.ok || !categoriesResponse.ok) {
    throw new Error("Could not load site options.");
  }
  const settings = await settingsResponse.json();
  const categories = await categoriesResponse.json();
  return { settings: settings.data || {}, categories: categories.data || [] };
}
function NotFoundComponent() {
  return /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex min-h-screen items-center justify-center bg-background px-4", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "max-w-md text-center", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx("h1", { className: "font-display text-7xl text-primary", children: "404" }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "mt-4 text-xl font-semibold", children: "Page not found" }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-2 text-sm text-muted-foreground", children: "The page you're looking for doesn't exist." }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "mt-6", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Link, { to: "/", className: "btn-primary", children: "Go home" }) })
  ] }) });
}
function ErrorComponent({ error, reset }) {
  console.error(error);
  const router2 = useRouter();
  return /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex min-h-screen items-center justify-center bg-background px-4", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "max-w-md text-center", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx("h1", { className: "text-xl font-semibold", children: "This page didn't load" }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-2 text-sm text-muted-foreground", children: "Something went wrong. Try refreshing or head back home." }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-6 flex flex-wrap justify-center gap-2", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("button", { onClick: () => {
        router2.invalidate();
        reset();
      }, className: "btn-primary", children: "Try again" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("a", { href: "/", className: "btn-outline", children: "Go home" })
    ] })
  ] }) });
}
const Route$d = createRootRouteWithContext()({
  head: () => ({
    meta: [
      { charSet: "utf-8" },
      { name: "viewport", content: "width=device-width, initial-scale=1" },
      { title: "Mart Tex — Bangladesh Garment Buying House" },
      { name: "description", content: "Mart Tex is a trusted Bangladesh buying house — ethical sourcing, production and quality assurance for global fashion brands." },
      { property: "og:title", content: "Mart Tex — Bangladesh Garment Buying House" },
      { property: "og:description", content: "Mart Tex is a trusted Bangladesh buying house — ethical sourcing, production and quality assurance for global fashion brands." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
      { name: "twitter:title", content: "Mart Tex — Bangladesh Garment Buying House" },
      { name: "twitter:description", content: "Mart Tex is a trusted Bangladesh buying house — ethical sourcing, production and quality assurance for global fashion brands." },
      { property: "og:image", content: "https://pub-bb2e103a32db4e198524a2e9ed8f35b4.r2.dev/2b3356f2-032f-4d10-9405-1a401e61d91e/id-preview-880f56c3--f2a35a8b-c1bc-4a04-a87a-7ef079ae797c.lovable.app-1778955039972.png" },
      { name: "twitter:image", content: "https://pub-bb2e103a32db4e198524a2e9ed8f35b4.r2.dev/2b3356f2-032f-4d10-9405-1a401e61d91e/id-preview-880f56c3--f2a35a8b-c1bc-4a04-a87a-7ef079ae797c.lovable.app-1778955039972.png" }
    ],
    links: [
      { rel: "stylesheet", href: appCss },
      { rel: "icon", href: `${API_URL}/api/favicon` },
      { rel: "shortcut icon", href: `${API_URL}/api/favicon` },
      { rel: "preconnect", href: "https://fonts.googleapis.com" },
      { rel: "preconnect", href: "https://fonts.gstatic.com", crossOrigin: "anonymous" },
      {
        rel: "stylesheet",
        href: "https://fonts.googleapis.com/css2?family=Fraunces:opsz,wght@9..144,400;9..144,500;9..144,600&family=Inter:wght@400;500;600&display=swap"
      }
    ]
  }),
  shellComponent: RootShell,
  component: RootComponent,
  notFoundComponent: NotFoundComponent,
  errorComponent: ErrorComponent
});
function RootShell({ children }) {
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("html", { lang: "en", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx("head", { children: /* @__PURE__ */ jsxRuntimeExports.jsx(HeadContent, {}) }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("body", { children: [
      children,
      /* @__PURE__ */ jsxRuntimeExports.jsx(Scripts, {})
    ] })
  ] });
}
function RootComponent() {
  const { queryClient } = Route$d.useRouteContext();
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(QueryClientProvider, { client: queryClient, children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx(SmoothScrollToTop, {}),
    /* @__PURE__ */ jsxRuntimeExports.jsx(Outlet, {})
  ] });
}
function SmoothScrollToTop() {
  const location = useLocation();
  reactExports.useEffect(() => {
    window.scrollTo({ top: 0, left: 0, behavior: "smooth" });
  }, [location.pathname]);
  return null;
}
const $$splitComponentImporter$c = () => import("./services-K4cVV8Rh.mjs");
const Route$c = createFileRoute("/services")({
  component: lazyRouteComponent($$splitComponentImporter$c, "component"),
  head: () => ({
    meta: [{
      title: "Services — Mart Tex"
    }, {
      name: "description",
      content: "Sourcing, sampling, production, QA, compliance and logistics services."
    }]
  })
});
const quality = "/assets/quality-Da0hWhni.jpg";
const $$splitComponentImporter$b = () => import("./profile-DmvtCH3N.mjs");
const Route$b = createFileRoute("/profile")({
  component: lazyRouteComponent($$splitComponentImporter$b, "component"),
  head: () => ({
    meta: [{
      title: "Company Profile - Mart Tex"
    }, {
      name: "description",
      content: "Mart Tex company profile: apparel manufacturing, sourcing, quality assurance, production capacity and product capabilities."
    }]
  })
});
const $$splitComponentImporter$a = () => import("./products-BFsOu0JM.mjs");
const Route$a = createFileRoute("/products")({
  component: lazyRouteComponent($$splitComponentImporter$a, "component")
});
const $$splitComponentImporter$9 = () => import("./news-BFsOu0JM.mjs");
const Route$9 = createFileRoute("/news")({
  component: lazyRouteComponent($$splitComponentImporter$9, "component")
});
const $$splitComponentImporter$8 = () => import("./gallery-CuvnZEDI.mjs");
const Route$8 = createFileRoute("/gallery")({
  component: lazyRouteComponent($$splitComponentImporter$8, "component"),
  head: () => ({
    meta: [{
      title: "Gallery — Mart Tex"
    }]
  })
});
const $$splitComponentImporter$7 = () => import("./contact-CiUVmnyJ.mjs");
const Route$7 = createFileRoute("/contact")({
  component: lazyRouteComponent($$splitComponentImporter$7, "component"),
  head: () => ({
    meta: [{
      title: "Contact — Mart Tex"
    }, {
      name: "description",
      content: "Request a quote or get in touch with our Dhaka team."
    }]
  })
});
const $$splitComponentImporter$6 = () => import("./admin-T_qf_Dnv.mjs");
const Route$6 = createFileRoute("/admin")({
  component: lazyRouteComponent($$splitComponentImporter$6, "component"),
  head: () => ({
    meta: [{
      title: "Admin Dashboard - Mart Tex"
    }]
  })
});
const $$splitComponentImporter$5 = () => import("./about-W5CcC7Sq.mjs");
const Route$5 = createFileRoute("/about")({
  component: lazyRouteComponent($$splitComponentImporter$5, "component"),
  head: () => ({
    meta: [{
      title: "About - Mart Tex"
    }, {
      name: "description",
      content: "Our story, values and team behind Mart Tex apparel manufacturing and sourcing."
    }]
  })
});
const sourcing = "/assets/sourcing-BgwhvRNY.jpg";
const $$splitComponentImporter$4 = () => import("./index-H5qvcVng.mjs");
const Route$4 = createFileRoute("/")({
  loader: loadHomeContent,
  component: lazyRouteComponent($$splitComponentImporter$4, "component"),
  head: () => ({
    meta: [{
      title: "Mart Tex — Built on Threads, Driven by Trust"
    }]
  })
});
async function loadHomeContent() {
  try {
    const [brandsResponse, testimonialsResponse] = await Promise.all([fetch(`${API_URL}/api/content/home-brands`), fetch(`${API_URL}/api/content/home-testimonials`)]);
    const [brandsResult, testimonialsResult] = await Promise.all([brandsResponse.json(), testimonialsResponse.json()]);
    const brandLogos = Array.isArray(brandsResult.data?.items) ? brandsResult.data.items.map((item) => assetUrl(item.image)).filter(Boolean) : [];
    const testimonials = Array.isArray(testimonialsResult.data?.items) ? testimonialsResult.data.items : [];
    return {
      brandLogos,
      testimonials
    };
  } catch {
    return {
      brandLogos: [],
      testimonials: []
    };
  }
}
const $$splitComponentImporter$3 = () => import("./products.index-DhgwjpFl.mjs");
const Route$3 = createFileRoute("/products/")({
  component: lazyRouteComponent($$splitComponentImporter$3, "component"),
  head: () => ({
    meta: [{
      title: "Products — Mart Tex"
    }]
  })
});
const $$splitComponentImporter$2 = () => import("./news.index-CCJ6PjN-.mjs");
const Route$2 = createFileRoute("/news/")({
  component: lazyRouteComponent($$splitComponentImporter$2, "component"),
  head: () => ({
    meta: [{
      title: "News — Mart Tex"
    }]
  })
});
const $$splitComponentImporter$1 = () => import("./products._category-B9DbiSpr.mjs");
const Route$1 = createFileRoute("/products/$category")({
  component: lazyRouteComponent($$splitComponentImporter$1, "component"),
  head: ({
    params
  }) => ({
    meta: [{
      title: `${params.category} — Mart Tex`
    }]
  })
});
const factory = "/assets/factory-BUD3QnGw.jpg";
const articles = [{
  slug: "bangladesh-rmg-exports",
  img: factory,
  tag: "Industry",
  date: "April 2026",
  title: "Bangladesh RMG exports cross USD 50B — what it means for buyers",
  lead: "Bangladesh's ready-made garment sector has crossed a historic milestone, surpassing USD 50 billion in annual exports for the first time. For global buyers, this signals both a maturing supplier ecosystem and a new set of strategic opportunities.",
  body: ["The Bangladesh Garment Manufacturers and Exporters Association (BGMEA) confirmed the milestone in its Q1 2026 report, attributing the growth to stronger demand from the EU, UK and USA, alongside a significant uptick in value-added product categories such as outerwear, knitwear and technical fabrics.", "For buying houses and brand sourcing teams, the milestone carries practical implications. A larger export base means more factories competing for orders — which typically improves lead times and pricing. However, it also means capacity is tighter at the top end, where compliance-certified and sustainability-audited factories are increasingly in demand.", "Mart Tex's sourcing team has noted a 22% increase in new factory inquiries over the past two quarters, with brands specifically asking for WRAP, BSCI and GOTS-certified production partners. Our vetted network currently spans 60+ factories across Dhaka, Gazipur and Chittagong.", "The key takeaway for buyers entering or scaling Bangladesh sourcing: the ecosystem is more sophisticated than ever, but so is the competition for the best factory slots. Establishing long-term relationships with a trusted local partner remains the most reliable way to lock in capacity and quality."]
}, {
  slug: "cotton-recycled-blends",
  img: sourcing,
  tag: "Sourcing",
  date: "March 2026",
  title: "Cotton vs. recycled blends: a cost and quality comparison for SS27",
  lead: "As sustainability mandates increase, more brands are asking us to spec recycled polyester and organic cotton blends. Here is a frank breakdown of where the cost and quality tradeoffs actually sit for SS27 production.",
  body: ["Recycled polyester (rPET) derived from post-consumer bottles has become the most commercially accessible sustainable fibre in Bangladesh's supply chain. Mill-gate pricing is now within 8–12% of virgin poly, down from a 25%+ premium three years ago. For performance-oriented knitwear — activewear, outerwear linings, interlock fleece — rPET is often the right call.", "Organic cotton tells a different story. The premium over conventional cotton sits at 18–30% depending on certification (GOTS vs. OCS) and yarn count. The quality uplift is real — better handle, cleaner dye uptake, less fibre breakage — but for basic T-shirt programmes where brand marketing doesn't lean into sustainability, the math rarely closes.", "The winning formula we're seeing for SS27: hybrid specs. A 70/30 conventional cotton / rPET blend for core basics hits a sweet spot of cost, performance and a credible sustainability story. For hero pieces, full organic or full rPET with a verified chain of custody.", "Mart Tex can arrange fabric lab dips and salesman samples in 12–15 days from most partner mills. Reach out with your fibre brief and target FOB and we'll map the right options."]
}, {
  slug: "qa-protocol",
  img: quality,
  tag: "Quality",
  date: "February 2026",
  title: "Inside our in-line QA protocol — how we cut defect rates by 38%",
  lead: "Quality assurance at final inspection is too late. Our multi-stage in-line protocol, refined over 18 years, is how we reduced client-reported defect rates by 38% across all programmes in 2025.",
  body: ["The standard factory QA model — one final inspection before shipping — catches defects after the cost has already been incurred. Rework at final stage is expensive, time-consuming and rarely perfect. Our protocol intervenes at three earlier points: pre-production, during cutting, and at 50% inline.", "Pre-production sign-off covers the approved trim card, fabric shrinkage and colour fastness results, and a first pattern check against the approved sample. This single gate eliminates roughly 40% of downstream defects in our experience.", "The cutting room check audits lay planning, marker efficiency and first-ply inspection. Fabric defects caught here cost nothing to fix; the same defect at packing costs three times as much in rework labour and delays the line.", "Our 50% inline audit uses AQL 2.5 sampling on a live production run. This is where fit, stitch quality, label placement and trims are validated against the approved counter sample. Any critical finding triggers a line stop until corrective action is confirmed.", "The result across our 2025 programmes: average final inspection defect rate down from 3.1% to 1.9%. For clients shipping 500,000+ pieces annually, that is thousands of fewer rejects per season."]
}, {
  slug: "knitwear-capacity",
  img: factory,
  tag: "Capability",
  date: "January 2026",
  title: "Knitwear capacity: what 12M pieces a season looks like",
  lead: "Scaling knitwear production to 12 million pieces a season requires more than factory space. Here is how we approach capacity planning, factory alignment and risk distribution across our knit partner network.",
  body: ["Knitwear is Bangladesh's largest export category by volume, accounting for nearly 60% of total RMG output. The country's knit factories range from small 200-machine operations to vertically integrated giants running 3,000+ circular knitting machines with in-house dyeing, cutting and finishing.", "For a 12M piece season across multiple styles and constructions, we typically distribute across three to five factories. Single-factory concentration creates schedule risk — a machine breakdown, a power disruption or a compliance issue can cascade into a missed shipment window.", "Our capacity allocation model starts with style complexity. Basic single-jersey tees and polos go to high-volume, mid-tier factories where efficiency is paramount. Engineered stripes, jacquards, full-fashion knitwear and heavy fleece are allocated to specialist mills with the right equipment and pattern-making capability.", "Lead times for knit programmes: 90–110 days from approved sample to loading, assuming fabric is in-stock at the mill. Custom yarn colours add 15–20 days. Rush programmes can be accommodated at select factories for an FOB premium of 4–8%."]
}];
const $$splitComponentImporter = () => import("./news._slug-BhP_m3tG.mjs");
const Route = createFileRoute("/news/$slug")({
  component: lazyRouteComponent($$splitComponentImporter, "component"),
  head: ({
    params
  }) => {
    const article = articles.find((a) => a.slug === params.slug);
    return {
      meta: [{
        title: article ? `${article.title} — Mart Tex` : "Article — Mart Tex"
      }]
    };
  }
});
const ServicesRoute = Route$c.update({
  id: "/services",
  path: "/services",
  getParentRoute: () => Route$d
});
const ProfileRoute = Route$b.update({
  id: "/profile",
  path: "/profile",
  getParentRoute: () => Route$d
});
const ProductsRoute = Route$a.update({
  id: "/products",
  path: "/products",
  getParentRoute: () => Route$d
});
const NewsRoute = Route$9.update({
  id: "/news",
  path: "/news",
  getParentRoute: () => Route$d
});
const GalleryRoute = Route$8.update({
  id: "/gallery",
  path: "/gallery",
  getParentRoute: () => Route$d
});
const ContactRoute = Route$7.update({
  id: "/contact",
  path: "/contact",
  getParentRoute: () => Route$d
});
const AdminRoute = Route$6.update({
  id: "/admin",
  path: "/admin",
  getParentRoute: () => Route$d
});
const AboutRoute = Route$5.update({
  id: "/about",
  path: "/about",
  getParentRoute: () => Route$d
});
const IndexRoute = Route$4.update({
  id: "/",
  path: "/",
  getParentRoute: () => Route$d
});
const ProductsIndexRoute = Route$3.update({
  id: "/",
  path: "/",
  getParentRoute: () => ProductsRoute
});
const NewsIndexRoute = Route$2.update({
  id: "/",
  path: "/",
  getParentRoute: () => NewsRoute
});
const ProductsCategoryRoute = Route$1.update({
  id: "/$category",
  path: "/$category",
  getParentRoute: () => ProductsRoute
});
const NewsSlugRoute = Route.update({
  id: "/$slug",
  path: "/$slug",
  getParentRoute: () => NewsRoute
});
const NewsRouteChildren = {
  NewsSlugRoute,
  NewsIndexRoute
};
const NewsRouteWithChildren = NewsRoute._addFileChildren(NewsRouteChildren);
const ProductsRouteChildren = {
  ProductsCategoryRoute,
  ProductsIndexRoute
};
const ProductsRouteWithChildren = ProductsRoute._addFileChildren(
  ProductsRouteChildren
);
const rootRouteChildren = {
  IndexRoute,
  AboutRoute,
  AdminRoute,
  ContactRoute,
  GalleryRoute,
  NewsRoute: NewsRouteWithChildren,
  ProductsRoute: ProductsRouteWithChildren,
  ProfileRoute,
  ServicesRoute
};
const routeTree = Route$d._addFileChildren(rootRouteChildren)._addFileTypes();
const getRouter = () => {
  const queryClient = new QueryClient();
  const router2 = createRouter({
    routeTree,
    context: { queryClient },
    scrollRestoration: true,
    defaultPreloadStaleTime: 0
  });
  return router2;
};
const router = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  getRouter
}, Symbol.toStringTag, { value: "Module" }));
export {
  API_URL as A,
  Route$4 as R,
  Route$1 as a,
  Route as b,
  articles as c,
  assetUrl as d,
  factory as f,
  getPublicSiteData as g,
  quality as q,
  router as r,
  sourcing as s
};
