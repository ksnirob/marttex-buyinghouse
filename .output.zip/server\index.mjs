globalThis.__nitro_main__ = import.meta.url;
import { N as NodeResponse, s as serve } from "./_libs/srvx.mjs";
import { d as defineHandler, a as HTTPError, t as toEventHandler, b as defineLazyEventHandler, H as H3Core } from "./_libs/h3.mjs";
import { d as decodePath, w as withLeadingSlash, a as withoutTrailingSlash, j as joinURL } from "./_libs/ufo.mjs";
import { promises } from "node:fs";
import { fileURLToPath } from "node:url";
import { dirname, resolve } from "node:path";
import "node:http";
import "node:stream";
import "node:stream/promises";
import "node:https";
import "node:http2";
import "./_libs/rou3.mjs";
function lazyService(loader) {
  let promise, mod;
  return {
    fetch(req) {
      if (mod) {
        return mod.fetch(req);
      }
      if (!promise) {
        promise = loader().then((_mod) => mod = _mod.default || _mod);
      }
      return promise.then((mod2) => mod2.fetch(req));
    }
  };
}
const services = {
  ["ssr"]: lazyService(() => import("./_ssr/index.mjs"))
};
globalThis.__nitro_vite_envs__ = services;
const headers = ((m) => function headersRouteRule(event) {
  for (const [key2, value] of Object.entries(m.options || {})) {
    event.res.headers.set(key2, value);
  }
});
const assets = {
  "/robots.txt": {
    "type": "text/plain; charset=utf-8",
    "etag": '"19-yHADZo6lKl+mSNPU9098EiqzPCE"',
    "mtime": "2026-05-21T12:36:07.800Z",
    "size": 25,
    "path": "../public/robots.txt"
  },
  "/assets/admin-BVE2kvmW.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"a46d-6yCxUr4ksXWAJN85z4aQgaKlOZs"',
    "mtime": "2026-07-16T13:46:36.949Z",
    "size": 42093,
    "path": "../public/assets/admin-BVE2kvmW.js"
  },
  "/assets/BgShapes-DfRxGtVA.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"810-Z3RFnlYJRrimKN8CL1Tvxwj7kv8"',
    "mtime": "2026-07-16T13:46:36.950Z",
    "size": 2064,
    "path": "../public/assets/BgShapes-DfRxGtVA.js"
  },
  "/assets/boxes-DwDzOAkx.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"350-dSnJQbvqIJrRr+WxWI2Afdd/qEo"',
    "mtime": "2026-07-16T13:46:36.949Z",
    "size": 848,
    "path": "../public/assets/boxes-DwDzOAkx.js"
  },
  "/assets/about-dSgVB9hH.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"e89-X+0iTMbIvXc0w3msRS3du2EXAKg"',
    "mtime": "2026-07-16T13:46:36.949Z",
    "size": 3721,
    "path": "../public/assets/about-dSgVB9hH.js"
  },
  "/assets/calendar-DxQhYdpL.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"fe-Q7X8nywWvJRIDw0au3yUEMGBDLc"',
    "mtime": "2026-07-16T13:46:36.951Z",
    "size": 254,
    "path": "../public/assets/calendar-DxQhYdpL.js"
  },
  "/assets/arrow-left-D-KiX_PC.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"a2-OtHryZRi8OBH9Pq9jkQY7NFmR34"',
    "mtime": "2026-07-16T13:46:36.951Z",
    "size": 162,
    "path": "../public/assets/arrow-left-D-KiX_PC.js"
  },
  "/assets/chevron-right-BzW00tbB.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"d1-iXcPmyBCTYvs9lKADtoRgA2bUwg"',
    "mtime": "2026-07-16T13:46:36.950Z",
    "size": 209,
    "path": "../public/assets/chevron-right-BzW00tbB.js"
  },
  "/assets/circle-check-CnOzNpAc.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"aa-kMfXEOLrS2rFMXqTCeBow1P00Hg"',
    "mtime": "2026-07-16T13:46:36.949Z",
    "size": 170,
    "path": "../public/assets/circle-check-CnOzNpAc.js"
  },
  "/assets/contact-DKOjxnNZ.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"12b3-BMU0H8Ctc03SfpZPPUU+F73SXbE"',
    "mtime": "2026-07-16T13:46:36.949Z",
    "size": 4787,
    "path": "../public/assets/contact-DKOjxnNZ.js"
  },
  "/assets/factory-CQyUDOhW.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"194-D1KRCp8XW/vJJRwS9VAEtaGoE8Q"',
    "mtime": "2026-07-16T13:46:36.949Z",
    "size": 404,
    "path": "../public/assets/factory-CQyUDOhW.js"
  },
  "/assets/index-Bho6BYJo.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"1458f-KMtINfx8/e5U7mCI/3SyRy9WiIM"',
    "mtime": "2026-07-16T13:46:36.949Z",
    "size": 83343,
    "path": "../public/assets/index-Bho6BYJo.js"
  },
  "/assets/layers-DWHZ8h-1.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"2fb-bz8iO0MZEKtWD8VaJPB6goMjSjY"',
    "mtime": "2026-07-16T13:46:36.949Z",
    "size": 763,
    "path": "../public/assets/layers-DWHZ8h-1.js"
  },
  "/assets/gallery-Bzh98_Rr.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"46e-osKeHURZl+OBBDkm0315HQ864Uw"',
    "mtime": "2026-07-16T13:46:36.949Z",
    "size": 1134,
    "path": "../public/assets/gallery-Bzh98_Rr.js"
  },
  "/assets/Layout-1428-v7Y.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"2f3b-gyRKyvFBQyXGksYT+xqDNok3wo4"',
    "mtime": "2026-07-16T13:46:36.951Z",
    "size": 12091,
    "path": "../public/assets/Layout-1428-v7Y.js"
  },
  "/assets/factory-BUD3QnGw.jpg": {
    "type": "image/jpeg",
    "etag": '"3674d-FTQiGg1WB1FYmMZ711M1xWLH8lE"',
    "mtime": "2026-07-16T13:46:36.944Z",
    "size": 223053,
    "path": "../public/assets/factory-BUD3QnGw.jpg"
  },
  "/assets/Lightbox-By12L_9n.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"8ff-kqOjjkZkHtaZrfcKGCth1mz4Xlo"',
    "mtime": "2026-07-16T13:46:36.950Z",
    "size": 2303,
    "path": "../public/assets/Lightbox-By12L_9n.js"
  },
  "/assets/hero-garments-CIxYALS4.jpg": {
    "type": "image/jpeg",
    "etag": '"3dc5d-T9DW5w4otFMIPzlWImUjElSOMP4"',
    "mtime": "2026-07-16T13:46:36.948Z",
    "size": 253021,
    "path": "../public/assets/hero-garments-CIxYALS4.jpg"
  },
  "/assets/index-DM_E0Tci.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"584e8-+W7cdrkeNkdyPBwuKNlaO3edOiE"',
    "mtime": "2026-07-16T13:46:36.949Z",
    "size": 361704,
    "path": "../public/assets/index-DM_E0Tci.js"
  },
  "/assets/model-s2-kid-B9ft34Kz.png": {
    "type": "image/png",
    "etag": '"687c0-urFYsDupRj8c6AfKnPtVqI/FrcE"',
    "mtime": "2026-07-16T13:46:36.948Z",
    "size": 427968,
    "path": "../public/assets/model-s2-kid-B9ft34Kz.png"
  },
  "/assets/model-s2-male1-BuGgDqm4.png": {
    "type": "image/png",
    "etag": '"61175-cd3fkZCGdcMyAmPJ4IGoxvyXWtg"',
    "mtime": "2026-07-16T13:46:36.948Z",
    "size": 397685,
    "path": "../public/assets/model-s2-male1-BuGgDqm4.png"
  },
  "/assets/model-s2-male2-BrTDs8Gy.png": {
    "type": "image/png",
    "etag": '"866e9-S1h6+qAcNL4wQBVNAQvMzlseZhc"',
    "mtime": "2026-07-16T13:46:36.951Z",
    "size": 550633,
    "path": "../public/assets/model-s2-male2-BrTDs8Gy.png"
  },
  "/assets/model-male-2-D2UiDuxX.png": {
    "type": "image/png",
    "etag": '"ae992-/E6ooTZDO7b1LxE6/sN8WP+bJM0"',
    "mtime": "2026-07-16T13:46:36.951Z",
    "size": 715154,
    "path": "../public/assets/model-male-2-D2UiDuxX.png"
  },
  "/assets/model-male-1-C-QSinrP.png": {
    "type": "image/png",
    "etag": '"bc99c-FlX9+6cLpOiWPR73wOYrINuJ2Us"',
    "mtime": "2026-07-16T13:46:36.952Z",
    "size": 772508,
    "path": "../public/assets/model-male-1-C-QSinrP.png"
  },
  "/assets/model-kid-BcXzc0og.png": {
    "type": "image/png",
    "etag": '"e69f6-BwUffu0l0rzO6ztiGfqg8znsgjQ"',
    "mtime": "2026-07-16T13:46:36.952Z",
    "size": 944630,
    "path": "../public/assets/model-kid-BcXzc0og.png"
  },
  "/assets/news.index-DPxNJMYC.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"6a7-eP+BhhnzKM5ECBQsGx42pZHOjWA"',
    "mtime": "2026-07-16T13:46:36.950Z",
    "size": 1703,
    "path": "../public/assets/news.index-DPxNJMYC.js"
  },
  "/assets/model-s3-kid-DDTwOuBJ.png": {
    "type": "image/png",
    "etag": '"41248-wkvZmT2RTdvYdQbWJr0MVofJN8M"',
    "mtime": "2026-07-16T13:46:36.948Z",
    "size": 266824,
    "path": "../public/assets/model-s3-kid-DDTwOuBJ.png"
  },
  "/assets/product-kids-CxfrayWT.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"c5-avO4aZV7IZsjPcqOy53u+LFyBLg"',
    "mtime": "2026-07-16T13:46:36.950Z",
    "size": 197,
    "path": "../public/assets/product-kids-CxfrayWT.js"
  },
  "/assets/news._slug-B0iN-gzO.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"875-HLkAvxgc7rIfYZKS3xrcPrOtK/4"',
    "mtime": "2026-07-16T13:46:36.950Z",
    "size": 2165,
    "path": "../public/assets/news._slug-B0iN-gzO.js"
  },
  "/assets/product-kids-DgcnQG_p.jpg": {
    "type": "image/jpeg",
    "etag": '"cd10-7Pxnl359qXBT/5v6CwsWlhhvfn8"',
    "mtime": "2026-07-16T13:46:36.944Z",
    "size": 52496,
    "path": "../public/assets/product-kids-DgcnQG_p.jpg"
  },
  "/assets/product-denim-CDQDm1R3.jpg": {
    "type": "image/jpeg",
    "etag": '"19661-UnSNbbIQvztF0zDfgJg2YW1PC48"',
    "mtime": "2026-07-16T13:46:36.945Z",
    "size": 104033,
    "path": "../public/assets/product-denim-CDQDm1R3.jpg"
  },
  "/assets/model-s3-male2-uHDxJdAg.png": {
    "type": "image/png",
    "etag": '"707b1-dEa4n+xdSM1LfrC46LP3pHSl/as"',
    "mtime": "2026-07-16T13:46:36.948Z",
    "size": 460721,
    "path": "../public/assets/model-s3-male2-uHDxJdAg.png"
  },
  "/assets/news-Dhl78gY6.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"5f-p7HL7d5nTiHODQrkAKCxxkpRsIo"',
    "mtime": "2026-07-16T13:46:36.949Z",
    "size": 95,
    "path": "../public/assets/news-Dhl78gY6.js"
  },
  "/assets/products.index-BrAFknsH.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"ca0-LkHFkMbabO6g6ZcyzRrizK23sUA"',
    "mtime": "2026-07-16T13:46:36.949Z",
    "size": 3232,
    "path": "../public/assets/products.index-BrAFknsH.js"
  },
  "/assets/products-Dhl78gY6.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"5f-p7HL7d5nTiHODQrkAKCxxkpRsIo"',
    "mtime": "2026-07-16T13:46:36.949Z",
    "size": 95,
    "path": "../public/assets/products-Dhl78gY6.js"
  },
  "/assets/profile-DS2cDwG4.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"2cd0-Wm6inm7MF4HOG366CUTu10MENgc"',
    "mtime": "2026-07-16T13:46:36.949Z",
    "size": 11472,
    "path": "../public/assets/profile-DS2cDwG4.js"
  },
  "/assets/products._category-DWzyt40i.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"723-zrOBY378CJCWDiBvWmB/jRiBKNE"',
    "mtime": "2026-07-16T13:46:36.950Z",
    "size": 1827,
    "path": "../public/assets/products._category-DWzyt40i.js"
  },
  "/assets/product-woven-CUPOsHic.jpg": {
    "type": "image/jpeg",
    "etag": '"d5cb-Ud/kblLkHHEHfXFc9ktRJLJyKck"',
    "mtime": "2026-07-16T13:46:36.946Z",
    "size": 54731,
    "path": "../public/assets/product-woven-CUPOsHic.jpg"
  },
  "/assets/services-CRwUsJfs.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"ddb-25fcXRz+QofD2f8//3Ep1mBa+No"',
    "mtime": "2026-07-16T13:46:36.949Z",
    "size": 3547,
    "path": "../public/assets/services-CRwUsJfs.js"
  },
  "/assets/shield-check-CIV-gIMb.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"39b-oaggb8B2a/jjs2YyNOiVFbjLABY"',
    "mtime": "2026-07-16T13:46:36.949Z",
    "size": 923,
    "path": "../public/assets/shield-check-CIV-gIMb.js"
  },
  "/assets/quality-Da0hWhni.jpg": {
    "type": "image/jpeg",
    "etag": '"14814-mQEH2Eygoyw9mQfwhlqLh/ukRcU"',
    "mtime": "2026-07-16T13:46:36.944Z",
    "size": 83988,
    "path": "../public/assets/quality-Da0hWhni.jpg"
  },
  "/assets/styles-B-1pBU68.css": {
    "type": "text/css; charset=utf-8",
    "etag": '"1bcc9-2BtDb58Rrp9s6a5psFHBbzQ1G/w"',
    "mtime": "2026-07-16T13:46:36.949Z",
    "size": 113865,
    "path": "../public/assets/styles-B-1pBU68.css"
  },
  "/assets/product-knit-Cr2DhAld.jpg": {
    "type": "image/jpeg",
    "etag": '"57927-mW3XxE4Se+jvC/AuisjuGqT9qfI"',
    "mtime": "2026-07-16T13:46:36.946Z",
    "size": 358695,
    "path": "../public/assets/product-knit-Cr2DhAld.jpg"
  },
  "/assets/sourcing-BgwhvRNY.jpg": {
    "type": "image/jpeg",
    "etag": '"28464-IjoKLrHaHrBK9IBWd3dfZsqZmAw"',
    "mtime": "2026-07-16T13:46:36.944Z",
    "size": 164964,
    "path": "../public/assets/sourcing-BgwhvRNY.jpg"
  },
  "/assets/x-CUco9UyX.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"5f4-+f8t+NNZeGHvgdSLzM/SJlKjSIE"',
    "mtime": "2026-07-16T13:46:36.951Z",
    "size": 1524,
    "path": "../public/assets/x-CUco9UyX.js"
  },
  "/assets/model-s3-male1-BJhwrFuc.png": {
    "type": "image/png",
    "etag": '"9fd7f-i8W7xgtgnX65ZBiULQXRSpHJOE0"',
    "mtime": "2026-07-16T13:46:36.951Z",
    "size": 654719,
    "path": "../public/assets/model-s3-male1-BJhwrFuc.png"
  }
};
function readAsset(id) {
  const serverDir = dirname(fileURLToPath(globalThis.__nitro_main__));
  return promises.readFile(resolve(serverDir, assets[id].path));
}
const publicAssetBases = {};
function isPublicAssetURL(id = "") {
  if (assets[id]) {
    return true;
  }
  for (const base in publicAssetBases) {
    if (id.startsWith(base)) {
      return true;
    }
  }
  return false;
}
function getAsset(id) {
  return assets[id];
}
const METHODS = /* @__PURE__ */ new Set(["HEAD", "GET"]);
const EncodingMap = {
  gzip: ".gz",
  br: ".br",
  zstd: ".zst"
};
const _esMaHO = defineHandler((event) => {
  if (event.req.method && !METHODS.has(event.req.method)) {
    return;
  }
  let id = decodePath(withLeadingSlash(withoutTrailingSlash(event.url.pathname)));
  let asset;
  const encodingHeader = event.req.headers.get("accept-encoding") || "";
  const encodings = [...encodingHeader.split(",").map((e) => EncodingMap[e.trim()]).filter(Boolean).sort(), ""];
  for (const encoding of encodings) {
    for (const _id of [id + encoding, joinURL(id, "index.html" + encoding)]) {
      const _asset = getAsset(_id);
      if (_asset) {
        asset = _asset;
        id = _id;
        break;
      }
    }
  }
  if (!asset) {
    if (isPublicAssetURL(id)) {
      event.res.headers.delete("Cache-Control");
      throw new HTTPError({ status: 404 });
    }
    return;
  }
  if (encodings.length > 1) {
    event.res.headers.append("Vary", "Accept-Encoding");
  }
  const ifNotMatch = event.req.headers.get("if-none-match") === asset.etag;
  if (ifNotMatch) {
    event.res.status = 304;
    event.res.statusText = "Not Modified";
    return "";
  }
  const ifModifiedSinceH = event.req.headers.get("if-modified-since");
  const mtimeDate = new Date(asset.mtime);
  if (ifModifiedSinceH && asset.mtime && new Date(ifModifiedSinceH) >= mtimeDate) {
    event.res.status = 304;
    event.res.statusText = "Not Modified";
    return "";
  }
  if (asset.type) {
    event.res.headers.set("Content-Type", asset.type);
  }
  if (asset.etag && !event.res.headers.has("ETag")) {
    event.res.headers.set("ETag", asset.etag);
  }
  if (asset.mtime && !event.res.headers.has("Last-Modified")) {
    event.res.headers.set("Last-Modified", mtimeDate.toUTCString());
  }
  if (asset.encoding && !event.res.headers.has("Content-Encoding")) {
    event.res.headers.set("Content-Encoding", asset.encoding);
  }
  if (asset.size > 0 && !event.res.headers.has("Content-Length")) {
    event.res.headers.set("Content-Length", asset.size.toString());
  }
  return readAsset(id);
});
const findRouteRules = /* @__PURE__ */ (() => {
  const $0 = [{ name: "headers", route: "/assets/**", handler: headers, options: { "cache-control": "public, max-age=31536000, immutable" } }];
  return (m, p) => {
    let r = [];
    if (p.charCodeAt(p.length - 1) === 47) p = p.slice(0, -1) || "/";
    let s = p.split("/"), l = s.length;
    if (l > 1) {
      if (s[1] === "assets") {
        r.unshift({ data: $0, params: { "_": s.slice(2).join("/") } });
      }
    }
    return r;
  };
})();
const _lazy_Jqd10v = defineLazyEventHandler(() => import("./_chunks/ssr-renderer.mjs"));
const findRoute = /* @__PURE__ */ (() => {
  const data = { route: "/**", handler: _lazy_Jqd10v };
  return ((_m, p) => {
    return { data, params: { "_": p.slice(1) } };
  });
})();
const globalMiddleware = [
  toEventHandler(_esMaHO)
].filter(Boolean);
const errorHandler$1 = (error, event) => {
  const res = defaultHandler(error, event);
  return new NodeResponse(typeof res.body === "string" ? res.body : JSON.stringify(res.body, null, 2), res);
};
function defaultHandler(error, event) {
  const unhandled = error.unhandled ?? !HTTPError.isError(error);
  const { status = 500, statusText = "" } = unhandled ? {} : error;
  if (status === 404) {
    const url = event.url || new URL(event.req.url);
    const baseURL = "/";
    if (/^\/[^/]/.test(baseURL) && !url.pathname.startsWith(baseURL)) {
      return {
        status: 302,
        headers: new Headers({ location: `${baseURL}${url.pathname.slice(1)}${url.search}` })
      };
    }
  }
  const headers2 = new Headers(unhandled ? {} : error.headers);
  headers2.set("content-type", "application/json; charset=utf-8");
  const jsonBody = unhandled ? {
    status,
    unhandled: true
  } : typeof error.toJSON === "function" ? error.toJSON() : {
    status,
    statusText,
    message: error.message
  };
  return {
    status,
    statusText,
    headers: headers2,
    body: {
      error: true,
      ...jsonBody
    }
  };
}
const errorHandlers = [errorHandler$1];
async function errorHandler(error, event) {
  for (const handler of errorHandlers) {
    try {
      const response = await handler(error, event, { defaultHandler });
      if (response) {
        return response;
      }
    } catch (error2) {
      console.error(error2);
    }
  }
}
function createNitroApp() {
  const captureError = (error, errorCtx) => {
    if (errorCtx?.event) {
      const errors = errorCtx.event.req.context?.nitro?.errors;
      if (errors) {
        errors.push({ error, context: errorCtx });
      }
    }
  };
  const h3App = createH3App({
    onError(error, event) {
      return errorHandler(error, event);
    }
  });
  let appHandler = (req) => {
    req.context ||= {};
    req.context.nitro = req.context.nitro || { errors: [] };
    return h3App.fetch(req);
  };
  return {
    fetch: appHandler,
    h3: h3App,
    hooks: void 0,
    captureError
  };
}
function createH3App(config) {
  const h3App = new H3Core(config);
  h3App["~findRoute"] = (event) => findRoute(event.req.method, event.url.pathname);
  h3App["~middleware"].push(...globalMiddleware);
  h3App["~getMiddleware"] = (event, route) => {
    const pathname = event.url.pathname;
    const method = event.req.method;
    const middleware = [];
    const routeRules = getRouteRules(method, pathname);
    event.context.routeRules = routeRules?.routeRules;
    if (routeRules?.routeRuleMiddleware.length) {
      middleware.push(...routeRules.routeRuleMiddleware);
    }
    middleware.push(...h3App["~middleware"]);
    if (route?.data?.middleware?.length) {
      middleware.push(...route.data.middleware);
    }
    return middleware;
  };
  return h3App;
}
const APP_ID = "default";
function useNitroApp() {
  let instance = useNitroApp._instance;
  if (instance) {
    return instance;
  }
  instance = useNitroApp._instance = createNitroApp();
  globalThis.__nitro__ = globalThis.__nitro__ || {};
  globalThis.__nitro__[APP_ID] = instance;
  return instance;
}
function getRouteRules(method, pathname) {
  const m = findRouteRules(method, pathname);
  if (!m?.length) {
    return { routeRuleMiddleware: [] };
  }
  const routeRules = {};
  for (const layer of m) {
    for (const rule of layer.data) {
      const currentRule = routeRules[rule.name];
      if (currentRule) {
        if (rule.options === false) {
          delete routeRules[rule.name];
          continue;
        }
        if (typeof currentRule.options === "object" && typeof rule.options === "object") {
          currentRule.options = {
            ...currentRule.options,
            ...rule.options
          };
        } else {
          currentRule.options = rule.options;
        }
        currentRule.route = rule.route;
        currentRule.params = {
          ...currentRule.params,
          ...layer.params
        };
      } else if (rule.options !== false) {
        routeRules[rule.name] = {
          ...rule,
          params: layer.params
        };
      }
    }
  }
  const middleware = [];
  const orderedRules = Object.values(routeRules).sort((a, b) => (a.handler?.order || 0) - (b.handler?.order || 0));
  for (const rule of orderedRules) {
    if (rule.options === false || !rule.handler) {
      continue;
    }
    middleware.push(rule.handler(rule));
  }
  return {
    routeRules,
    routeRuleMiddleware: middleware
  };
}
function _captureError(error, type) {
  console.error(`[${type}]`, error);
  useNitroApp().captureError?.(error, { tags: [type] });
}
function trapUnhandledErrors() {
  process.on("unhandledRejection", (error) => _captureError(error, "unhandledRejection"));
  process.on("uncaughtException", (error) => _captureError(error, "uncaughtException"));
}
const tracingSrvxPlugins = [];
const _parsedPort = Number.parseInt(process.env.NITRO_PORT ?? process.env.PORT ?? "");
const port = Number.isNaN(_parsedPort) ? 3e3 : _parsedPort;
const host = process.env.NITRO_HOST || process.env.HOST;
const cert = process.env.NITRO_SSL_CERT;
const key = process.env.NITRO_SSL_KEY;
const nitroApp = useNitroApp();
serve({
  port,
  hostname: host,
  tls: cert && key ? {
    cert,
    key
  } : void 0,
  fetch: nitroApp.fetch,
  plugins: [...tracingSrvxPlugins]
});
trapUnhandledErrors();
const nodeServer = {};
export {
  nodeServer as default
};
