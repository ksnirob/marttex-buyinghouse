import { r as reactExports, j as jsxRuntimeExports } from "../_libs/react.mjs";
import { S as SiteLayout, P as PageHeader } from "./Layout-F5tIfk4_.mjs";
import { B as BgShapes } from "./BgShapes-C2HctgSA.mjs";
import { u as useLightbox, L as Lightbox } from "./Lightbox-0tM-xTMN.mjs";
import { g as getPublicSiteData, d as assetUrl } from "./router-Cn102jAX.mjs";
import { Z as ZoomIn } from "../_libs/lucide-react.mjs";
import "../_libs/tanstack__react-router.mjs";
import "../_libs/tanstack__router-core.mjs";
import "../_libs/tanstack__history.mjs";
import "../_libs/cookie-es.mjs";
import "../_libs/seroval.mjs";
import "../_libs/seroval-plugins.mjs";
import "node:stream/web";
import "node:stream";
import "../_libs/react-dom.mjs";
import "util";
import "crypto";
import "async_hooks";
import "stream";
import "../_libs/isbot.mjs";
import "../_libs/tanstack__query-core.mjs";
import "../_libs/tanstack__react-query.mjs";
function Products() {
  const [active, setActive] = reactExports.useState("all");
  const [categories, setCategories] = reactExports.useState([]);
  const [loading, setLoading] = reactExports.useState(true);
  const lb = useLightbox();
  reactExports.useEffect(() => {
    getPublicSiteData().then((site) => {
      setCategories(site.categories);
    }).finally(() => setLoading(false));
  }, []);
  const visibleCategories = active === "all" ? categories : categories.filter((item) => item.slug === active);
  const images = visibleCategories.flatMap((category) => category.galleryImages || []).map((image) => assetUrl(image.url));
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(SiteLayout, { children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(BgShapes, { variant: "default" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(PageHeader, { eyebrow: "Products", title: "From concept to collection.", lead: "Explore the garments, fabrics and finishes we source, develop and deliver for fashion brands worldwide." })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("section", { className: "sticky top-20 z-40 border-b border-border/60 bg-background/85 backdrop-blur-md", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "container-x flex gap-2 overflow-x-auto py-4", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(FilterPill, { label: "All", active: active === "all", onClick: () => setActive("all"), count: categories.reduce((total, category) => total + (category.galleryImages?.length || 0), 0) }),
      categories.map((category) => /* @__PURE__ */ jsxRuntimeExports.jsx(FilterPill, { label: category.name, active: active === category.slug, onClick: () => setActive(category.slug), count: category.galleryImages?.length || 0 }, category._id))
    ] }) }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("section", { className: "relative", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(BgShapes, { variant: "soft" }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "container-x space-y-20 py-20", children: [
        loading && /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-muted-foreground", children: "Loading products..." }),
        !loading && visibleCategories.every((category) => !category.galleryImages?.length) && /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "rounded-2xl border border-border bg-card p-8 text-muted-foreground", children: "No gallery images have been added to this category yet." }),
        visibleCategories.map((category) => {
          const gallery = category.galleryImages || [];
          if (!gallery.length) return null;
          return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "eyebrow", children: "Category" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "mt-3 font-display text-4xl text-primary md:text-5xl", children: category.name }),
            category.description && /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-3 max-w-2xl text-muted-foreground", children: category.description }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "mt-8 grid gap-5 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4", children: gallery.map((image) => {
              const src = assetUrl(image.url);
              const index = images.indexOf(src);
              return /* @__PURE__ */ jsxRuntimeExports.jsx("button", { onClick: () => lb.open(index), className: "group overflow-hidden rounded-2xl border border-border bg-card text-left shadow-sm transition hover:-translate-y-1 hover:shadow-xl", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative aspect-[4/5] overflow-hidden", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("img", { src, alt: image.alt || category.name, className: "h-full w-full object-cover transition duration-700 group-hover:scale-105" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "absolute inset-0 grid place-items-center bg-primary/35 opacity-0 transition group-hover:opacity-100", children: /* @__PURE__ */ jsxRuntimeExports.jsx(ZoomIn, { className: "h-7 w-7 text-white" }) })
              ] }) }, `${category._id}-${src}`);
            }) })
          ] }, category._id);
        })
      ] })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsx(Lightbox, { images, index: lb.index, onClose: lb.close, onIndex: lb.to })
  ] });
}
function FilterPill({
  label,
  active,
  onClick,
  count
}) {
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("button", { onClick, className: `flex shrink-0 items-center gap-2 rounded-full border px-5 py-2.5 text-sm font-medium ${active ? "border-primary bg-primary text-primary-foreground" : "border-border bg-card text-foreground/70"}`, children: [
    label,
    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "rounded-full bg-muted px-2 py-0.5 text-[10px] text-foreground", children: count })
  ] });
}
export {
  Products as component
};
