import { r as reactExports, j as jsxRuntimeExports } from "../_libs/react.mjs";
import { u as useLocation, L as Link } from "../_libs/tanstack__react-router.mjs";
import { g as getPublicSiteData, d as assetUrl, A as API_URL } from "./router-Cn102jAX.mjs";
import { c as ChevronDown, b as ArrowUpRight, X, p as Menu, o as MapPin, U as User, s as Phone, M as Mail } from "../_libs/lucide-react.mjs";
const defaultMenu = [
  { label: "Home", path: "/" },
  { label: "About", path: "/about" },
  { label: "Products", path: "/products" },
  { label: "Profile", path: "/profile" },
  { label: "Services", path: "/services" },
  { label: "Gallery", path: "/gallery" },
  { label: "News", path: "/news" }
];
function Nav({ settings, categories }) {
  const [open, setOpen] = reactExports.useState(false);
  const [mobileProducts, setMobileProducts] = reactExports.useState(false);
  const location = useLocation();
  const menu = (settings.menuItems?.length ? settings.menuItems : defaultMenu).filter(
    (item) => item.isActive !== false
  );
  const logo = assetUrl(settings.logoUrl || "/uploads/logo.png");
  const company = settings.companyName || "Mart Tex";
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("header", { className: "sticky top-0 z-50 border-b border-border/60 bg-background/80 backdrop-blur-md", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "container-x flex h-20 items-center justify-between", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(Link, { to: "/", className: "flex items-center gap-2", children: logo && /* @__PURE__ */ jsxRuntimeExports.jsx("img", { src: logo, alt: company, className: "h-11 w-auto max-w-44 object-contain" }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("nav", { className: "hidden items-center gap-7 lg:flex", children: menu.map(
        (item) => item.path === "/products" ? /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "group relative", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs(Link, { to: "/products", className: `inline-flex items-center gap-1 border-b-2 py-2 text-sm transition ${location.pathname.startsWith("/products") ? "border-primary text-primary" : "border-transparent text-foreground/80 hover:text-primary"}`, children: [
            item.label,
            " ",
            /* @__PURE__ */ jsxRuntimeExports.jsx(ChevronDown, { className: "h-4 w-4 transition group-hover:rotate-180" })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "invisible absolute left-1/2 top-full z-50 w-64 -translate-x-1/2 translate-y-2 opacity-0 transition-all group-hover:visible group-hover:translate-y-0 group-hover:opacity-100", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-3 rounded-2xl border border-border bg-card p-2 shadow-2xl", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Link, { to: "/products", className: "flex rounded-lg px-4 py-2.5 text-sm hover:bg-secondary", children: "All Products" }),
            categories.map((category) => /* @__PURE__ */ jsxRuntimeExports.jsx(Link, { to: "/products/$category", params: { category: category.slug }, className: "flex rounded-lg px-4 py-2.5 text-sm hover:bg-secondary", children: category.name }, category._id))
          ] }) })
        ] }, item.path) : /* @__PURE__ */ jsxRuntimeExports.jsx(Link, { to: item.path, className: `border-b-2 py-2 text-sm transition ${location.pathname === item.path || item.path !== "/" && location.pathname.startsWith(`${item.path}/`) ? "border-primary text-primary" : "border-transparent text-foreground/80 hover:text-primary"}`, children: item.label }, item.path)
      ) }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs(Link, { to: "/contact", className: "hidden btn-primary lg:inline-flex", children: [
          "Let's Talk ",
          /* @__PURE__ */ jsxRuntimeExports.jsx(ArrowUpRight, { className: "h-4 w-4" })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("button", { "aria-label": "Toggle menu", className: "grid h-10 w-10 place-items-center rounded-full border border-border lg:hidden", onClick: () => setOpen(!open), children: open ? /* @__PURE__ */ jsxRuntimeExports.jsx(X, { className: "h-5 w-5" }) : /* @__PURE__ */ jsxRuntimeExports.jsx(Menu, { className: "h-5 w-5" }) })
      ] })
    ] }),
    open && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "border-t border-border bg-background lg:hidden", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "container-x flex flex-col gap-1 py-4", children: [
      menu.map(
        (item) => item.path === "/products" ? /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("button", { onClick: () => setMobileProducts(!mobileProducts), className: "flex w-full items-center justify-between rounded-md px-2 py-3 text-sm hover:bg-muted", children: [
            item.label,
            /* @__PURE__ */ jsxRuntimeExports.jsx(ChevronDown, { className: `h-4 w-4 transition ${mobileProducts ? "rotate-180" : ""}` })
          ] }),
          mobileProducts && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "ml-3 flex flex-col border-l border-border pl-3", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Link, { to: "/products", onClick: () => setOpen(false), className: "rounded-md px-2 py-2 text-sm hover:bg-muted", children: "All Products" }),
            categories.map((category) => /* @__PURE__ */ jsxRuntimeExports.jsx(Link, { to: "/products/$category", params: { category: category.slug }, onClick: () => setOpen(false), className: "rounded-md px-2 py-2 text-sm hover:bg-muted", children: category.name }, category._id))
          ] })
        ] }, item.path) : /* @__PURE__ */ jsxRuntimeExports.jsx(Link, { to: item.path, onClick: () => setOpen(false), className: `rounded-md border-l-2 px-2 py-3 text-sm ${location.pathname === item.path ? "border-primary bg-muted text-primary" : "border-transparent hover:bg-muted"}`, children: item.label }, item.path)
      ),
      /* @__PURE__ */ jsxRuntimeExports.jsx(Link, { to: "/contact", onClick: () => setOpen(false), className: "btn-primary mt-2 justify-center", children: "Let's Talk" })
    ] }) })
  ] });
}
const defaultExplore = [
  { label: "About", path: "/about" },
  { label: "Profile", path: "/profile" },
  { label: "Products", path: "/products" },
  { label: "Services", path: "/services" },
  { label: "Gallery", path: "/gallery" },
  { label: "News", path: "/news" }
];
function Footer({ settings }) {
  const company = settings.companyName || "Mart Tex";
  const logo = assetUrl(settings.logoUrl || "/uploads/logo.png");
  const links = (settings.menuItems?.length ? settings.menuItems : defaultExplore).filter(
    (item) => item.isActive !== false && item.path !== "/"
  );
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("footer", { className: "border-t border-border bg-primary text-primary-foreground", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "container-x grid gap-12 py-20 lg:grid-cols-4", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "lg:col-span-2", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex items-center gap-2", children: logo ? /* @__PURE__ */ jsxRuntimeExports.jsx("img", { src: logo, alt: company, className: "h-12 w-auto max-w-52 object-contain brightness-0 invert" }) : /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "grid h-9 w-9 place-items-center rounded-full bg-primary-foreground font-display text-lg text-primary", children: company.charAt(0) }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-display text-xl", children: company })
        ] }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-4 max-w-md text-sm text-primary-foreground/70", children: settings.footerText || "A Bangladesh-based buying house connecting global fashion brands with vetted, ethical garment manufacturers — from sample to shipment." })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("h4", { className: "text-sm font-medium", children: "Explore" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("ul", { className: "mt-4 space-y-2 text-sm text-primary-foreground/70", children: links.map((item) => /* @__PURE__ */ jsxRuntimeExports.jsx("li", { children: /* @__PURE__ */ jsxRuntimeExports.jsx(Link, { to: item.path, className: "hover:text-primary-foreground", children: item.label }) }, item.path)) })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("h4", { className: "text-sm font-medium", children: "Contact" }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("ul", { className: "mt-4 space-y-3 text-sm text-primary-foreground/70", children: [
          settings.address && /* @__PURE__ */ jsxRuntimeExports.jsxs("li", { className: "flex items-start gap-2", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(MapPin, { className: "mt-0.5 h-4 w-4 shrink-0" }),
            settings.address
          ] }),
          settings.contactPerson && /* @__PURE__ */ jsxRuntimeExports.jsxs("li", { className: "flex items-start gap-2", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(User, { className: "mt-0.5 h-4 w-4 shrink-0" }),
            settings.contactPerson
          ] }),
          (settings.phones || []).map((phone) => /* @__PURE__ */ jsxRuntimeExports.jsxs("li", { className: "flex items-start gap-2", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Phone, { className: "mt-0.5 h-4 w-4 shrink-0" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("a", { href: `tel:${phone}`, className: "hover:text-primary-foreground", children: phone })
          ] }, phone)),
          settings.email && /* @__PURE__ */ jsxRuntimeExports.jsxs("li", { className: "flex items-start gap-2", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Mail, { className: "mt-0.5 h-4 w-4 shrink-0" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("a", { href: `mailto:${settings.email}`, className: "hover:text-primary-foreground", children: settings.email })
          ] })
        ] })
      ] })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "border-t border-primary-foreground/15", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "container-x flex flex-col items-start justify-between gap-2 py-6 text-sm text-primary-foreground/60 sm:flex-row", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { children: [
        "© ",
        (/* @__PURE__ */ new Date()).getFullYear(),
        " ",
        company,
        ". ",
        settings.copyrightText || "All rights reserved."
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { children: [
        "Developed by",
        " ",
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "a",
          {
            href: "https://ksnirob.com",
            target: "_blank",
            rel: "noreferrer",
            className: "text-primary-foreground/80 transition hover:text-primary-foreground",
            children: "KS Nirob"
          }
        )
      ] })
    ] }) })
  ] });
}
function SiteLayout({ children }) {
  const location = useLocation();
  const [settings, setSettings] = reactExports.useState({});
  const [categories, setCategories] = reactExports.useState([]);
  reactExports.useEffect(() => {
    void getPublicSiteData().then((data) => {
      setSettings(data.settings);
      setCategories(data.categories);
    }).catch(() => void 0);
  }, []);
  reactExports.useEffect(() => {
    const faviconUrl = assetUrl(settings.faviconUrl);
    if (!faviconUrl) return;
    const versionedUrl = `${faviconUrl}${faviconUrl.includes("?") ? "&" : "?"}v=${encodeURIComponent(settings.faviconUrl || "")}`;
    const setIcon = (rel) => {
      let icon = document.head.querySelector(`link[rel="${rel}"]`);
      if (!icon) {
        icon = document.createElement("link");
        icon.rel = rel;
        document.head.appendChild(icon);
      }
      icon.href = versionedUrl;
    };
    setIcon("icon");
    setIcon("shortcut icon");
    setIcon("apple-touch-icon");
  }, [settings.faviconUrl]);
  reactExports.useEffect(() => {
    const sections = Array.from(document.querySelectorAll(".section-reveal"));
    if (!("IntersectionObserver" in window)) {
      sections.forEach((section) => section.classList.add("is-visible"));
      return;
    }
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add("is-visible");
            observer.unobserve(entry.target);
          }
        });
      },
      { threshold: 0.15, rootMargin: "0px 0px -10% 0px" }
    );
    const frame = window.requestAnimationFrame(() => {
      sections.forEach((section) => observer.observe(section));
    });
    return () => {
      window.cancelAnimationFrame(frame);
      observer.disconnect();
    };
  }, [location.pathname]);
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex min-h-screen flex-col bg-background", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx(Nav, { settings, categories }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("main", { className: "flex-1", children }),
    /* @__PURE__ */ jsxRuntimeExports.jsx(Footer, { settings }),
    /* @__PURE__ */ jsxRuntimeExports.jsx(
      "a",
      {
        href: `https://wa.me/${(settings.whatsapp || settings.phones?.[0] || "8801905450850").replace(/\D/g, "")}`,
        target: "_blank",
        rel: "noopener noreferrer",
        "aria-label": "Chat on WhatsApp",
        className: "fixed bottom-6 right-6 z-50 flex h-14 w-14 items-center justify-center rounded-full bg-[#25D366] shadow-lg transition-transform duration-300 hover:scale-110 hover:shadow-xl",
        children: /* @__PURE__ */ jsxRuntimeExports.jsx("svg", { viewBox: "0 0 24 24", fill: "white", className: "h-7 w-7", children: /* @__PURE__ */ jsxRuntimeExports.jsx("path", { d: "M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z" }) })
      }
    )
  ] });
}
function PageHeader({
  eyebrow,
  title,
  lead
}) {
  const location = useLocation();
  const [pageContent, setPageContent] = reactExports.useState(null);
  reactExports.useEffect(() => {
    const path = location.pathname.replace(/^\/|\/$/g, "");
    const supportedPages = /* @__PURE__ */ new Set([
      "about",
      "profile",
      "products",
      "services",
      "gallery",
      "news",
      "contact"
    ]);
    if (!supportedPages.has(path)) {
      setPageContent(null);
      return;
    }
    const controller = new AbortController();
    fetch(`${API_URL}/api/content/page-${path}-header`, { signal: controller.signal }).then((response) => response.json()).then((result) => setPageContent(result.data || null)).catch(() => setPageContent(null));
    return () => controller.abort();
  }, [location.pathname]);
  reactExports.useEffect(() => {
    if (!pageContent) return;
    const seoTitle = pageContent.seoTitle || pageContent.title;
    const seoDescription = pageContent.seoDescription || pageContent.body;
    const thumbnail = assetUrl(pageContent.thumbnail);
    if (seoTitle) document.title = seoTitle;
    const setMeta = (selector, attribute, key, content) => {
      if (!content) return;
      let element = document.head.querySelector(selector);
      if (!element) {
        element = document.createElement("meta");
        element.setAttribute(attribute, key);
        document.head.appendChild(element);
      }
      element.content = content;
    };
    setMeta('meta[name="description"]', "name", "description", seoDescription);
    setMeta('meta[property="og:title"]', "property", "og:title", seoTitle);
    setMeta('meta[property="og:description"]', "property", "og:description", seoDescription);
    setMeta('meta[name="twitter:title"]', "name", "twitter:title", seoTitle);
    setMeta('meta[name="twitter:description"]', "name", "twitter:description", seoDescription);
    setMeta('meta[property="og:image"]', "property", "og:image", thumbnail);
    setMeta('meta[name="twitter:image"]', "name", "twitter:image", thumbnail);
  }, [pageContent]);
  const displayedTitle = pageContent?.title || title;
  const displayedLead = pageContent?.body || lead;
  return /* @__PURE__ */ jsxRuntimeExports.jsx("section", { className: "section-reveal border-b border-border/60 bg-secondary/40", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "container-x py-20 md:py-28", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "eyebrow", children: eyebrow }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("h1", { className: "mt-4 max-w-3xl font-display text-5xl leading-[1.05] text-primary md:text-6xl", children: displayedTitle }),
    displayedLead && /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-6 max-w-2xl text-lg text-muted-foreground", children: displayedLead })
  ] }) });
}
export {
  PageHeader as P,
  SiteLayout as S
};
