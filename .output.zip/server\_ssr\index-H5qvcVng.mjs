import { r as reactExports, j as jsxRuntimeExports } from "../_libs/react.mjs";
import { L as Link } from "../_libs/tanstack__react-router.mjs";
import { R as Route$4, f as factory, q as quality, s as sourcing, A as API_URL, d as assetUrl } from "./router-Cn102jAX.mjs";
import { a as knit, w as woven, d as denim, k as kids } from "./product-kids-BAtRuyBg.mjs";
import { S as SiteLayout } from "./Layout-F5tIfk4_.mjs";
import { B as BgShapes } from "./BgShapes-C2HctgSA.mjs";
import { u as useEmblaCarousel } from "../_libs/embla-carousel-react.mjs";
import { c as clsx } from "../_libs/clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
import { S as Slot } from "../_libs/radix-ui__react-slot.mjs";
import { c as cva } from "../_libs/class-variance-authority.mjs";
import { z as Sparkles, m as Leaf, w as Shield, E as Earth, b as ArrowUpRight, F as Factory, L as Layers, C as Calendar, d as ChevronLeft, e as ChevronRight, A as ArrowLeft, a as ArrowRight } from "../_libs/lucide-react.mjs";
import "../_libs/tanstack__router-core.mjs";
import "../_libs/tanstack__history.mjs";
import "../_libs/cookie-es.mjs";
import "../_libs/seroval.mjs";
import "../_libs/seroval-plugins.mjs";
import "node:stream/web";
import "node:stream";
import "../_libs/react-dom.mjs";
import "util";
import "crypto";
import "async_hooks";
import "stream";
import "../_libs/isbot.mjs";
import "../_libs/tanstack__query-core.mjs";
import "../_libs/tanstack__react-query.mjs";
import "../_libs/embla-carousel-reactive-utils.mjs";
import "../_libs/embla-carousel.mjs";
import "../_libs/radix-ui__react-compose-refs.mjs";
const male1 = "/assets/model-male-1-C-QSinrP.png";
const kid = "/assets/model-kid-BcXzc0og.png";
const male2 = "/assets/model-male-2-D2UiDuxX.png";
const s2a = "/assets/model-s2-male1-BuGgDqm4.png";
const s2k = "/assets/model-s2-kid-B9ft34Kz.png";
const s2b = "/assets/model-s2-male2-BrTDs8Gy.png";
const s3a = "/assets/model-s3-male1-BJhwrFuc.png";
const s3k = "/assets/model-s3-kid-DDTwOuBJ.png";
const s3b = "/assets/model-s3-male2-uHDxJdAg.png";
const scenes = [
  {
    word: "CRAFT",
    eyebrow: "Spring / Summer 27",
    desc: "Defy the ordinary. Garments engineered with the kind of patience and detail your customer can feel.",
    models: [male1, kid, male2]
  },
  {
    word: "SOURCE",
    eyebrow: "Built in Bangladesh",
    desc: "Sourced, cut and stitched in audited Dhaka factories — the same hands behind the brands you already wear.",
    models: [s2a, s2k, s2b]
  },
  {
    word: "FAMILY",
    eyebrow: "Men · Women · Kids",
    desc: "From everyday menswear to soft, safe kidswear — one team, one quality bar, across every category.",
    models: [s3a, s3k, s3b]
  }
];
const HOLD = 4200;
const MODEL_SLOT_COUNT = 3;
const MODEL_TARGET_VISIBLE_HEIGHT = 1.08;
const defaultModelFit = { scale: 0.9, y: 0 };
const modelFitCache = /* @__PURE__ */ new Map();
function clamp(value, min, max) {
  return Math.min(max, Math.max(min, value));
}
function getModelSlots(models) {
  const visibleModels = models.filter(Boolean).slice(0, MODEL_SLOT_COUNT);
  if (visibleModels.length === 1) return ["", visibleModels[0], ""];
  if (visibleModels.length === 2) return [visibleModels[0], "", visibleModels[1]];
  return Array.from({ length: MODEL_SLOT_COUNT }, (_, idx) => visibleModels[idx] || "");
}
function HeroModelImage({ src }) {
  const [fit, setFit] = reactExports.useState(() => modelFitCache.get(src) || defaultModelFit);
  reactExports.useEffect(() => {
    if (!src) return;
    const cached = modelFitCache.get(src);
    if (cached) {
      setFit(cached);
      return;
    }
    let cancelled = false;
    const image = new Image();
    image.crossOrigin = "anonymous";
    image.onload = () => {
      try {
        const sampleWidth = 180;
        const ratio = sampleWidth / image.naturalWidth;
        const sampleHeight = Math.max(1, Math.round(image.naturalHeight * ratio));
        const canvas = document.createElement("canvas");
        canvas.width = sampleWidth;
        canvas.height = sampleHeight;
        const context = canvas.getContext("2d", { willReadFrequently: true });
        if (!context) return;
        context.drawImage(image, 0, 0, sampleWidth, sampleHeight);
        const data = context.getImageData(0, 0, sampleWidth, sampleHeight).data;
        let minY = sampleHeight;
        let maxY = -1;
        for (let y = 0; y < sampleHeight; y += 1) {
          for (let x = 0; x < sampleWidth; x += 1) {
            if (data[(y * sampleWidth + x) * 4 + 3] > 10) {
              if (y < minY) minY = y;
              if (y > maxY) maxY = y;
            }
          }
        }
        if (maxY < minY) return;
        const visibleRatio = (maxY - minY + 1) / sampleHeight;
        const bottomPadRatio = (sampleHeight - maxY - 1) / sampleHeight;
        const nextFit = {
          scale: clamp(MODEL_TARGET_VISIBLE_HEIGHT / visibleRatio, 1, 1.3),
          y: bottomPadRatio * 100
        };
        modelFitCache.set(src, nextFit);
        if (!cancelled) setFit(nextFit);
      } catch {
        if (!cancelled) setFit(defaultModelFit);
      }
    };
    image.onerror = () => {
      if (!cancelled) setFit(defaultModelFit);
    };
    image.src = src;
    return () => {
      cancelled = true;
    };
  }, [src]);
  return /* @__PURE__ */ jsxRuntimeExports.jsx(
    "img",
    {
      src,
      alt: "",
      width: 768,
      height: 1536,
      className: "relative z-10 h-full w-auto max-w-full object-contain drop-shadow-[0_30px_40px_oklch(0.22_0.04_220/0.25)]",
      style: {
        transform: `translateY(${fit.y}%) scale(${fit.scale})`,
        transformOrigin: "bottom center"
      }
    }
  );
}
function HeroSlider() {
  const [i, setI] = reactExports.useState(0);
  const [transitioning, setTransitioning] = reactExports.useState(false);
  const [dynamicScenes, setDynamicScenes] = reactExports.useState([]);
  const activeScenes = dynamicScenes.length ? dynamicScenes : scenes;
  const total = activeScenes.length;
  const go = (n) => {
    setTransitioning(true);
    window.setTimeout(() => {
      setI((n + total) % total);
      setTransitioning(false);
    }, 650);
  };
  reactExports.useEffect(() => {
    const id = window.setInterval(() => go(i + 1), HOLD);
    return () => window.clearInterval(id);
  }, [i]);
  reactExports.useEffect(() => {
    fetch(`${API_URL}/api/content/page-home`).then((response) => response.json()).then((result) => {
      const content = result.data;
      const items = Array.isArray(content?.items) ? content.items : [];
      const nextScenes = items.map((item) => ({
        word: item.word || "CREATE",
        eyebrow: item.eyebrow || "",
        desc: item.description || "",
        models: (item.images || []).map(assetUrl)
      })).filter((item) => item.models.length > 0);
      if (nextScenes.length) {
        setDynamicScenes(nextScenes);
        setI(0);
      }
      if (content?.seoTitle) document.title = content.seoTitle;
      const metadata = [
        ["name", "description", content?.seoDescription],
        ["property", "og:title", content?.seoTitle],
        ["property", "og:description", content?.seoDescription],
        ["property", "og:image", assetUrl(content?.thumbnail)],
        ["name", "twitter:title", content?.seoTitle],
        ["name", "twitter:description", content?.seoDescription],
        ["name", "twitter:image", assetUrl(content?.thumbnail)]
      ];
      metadata.forEach(([attribute, key, value]) => {
        if (!value) return;
        let meta = document.head.querySelector(`meta[${attribute}="${key}"]`);
        if (!meta) {
          meta = document.createElement("meta");
          meta.setAttribute(attribute, key);
          document.head.appendChild(meta);
        }
        meta.content = value;
      });
    }).catch(() => void 0);
  }, []);
  const s = activeScenes[i] || activeScenes[0];
  const modelSlots = getModelSlots(s.models);
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative isolate overflow-hidden bg-[oklch(0.975_0.006_205)]", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx(
      "div",
      {
        "aria-hidden": true,
        className: "pointer-events-none absolute inset-x-0 bottom-0 -z-10 h-[55%]",
        style: {
          backgroundImage: "linear-gradient(to right, oklch(0.36 0.07 220 / 0.08) 1px, transparent 1px), linear-gradient(to bottom, oklch(0.36 0.07 220 / 0.08) 1px, transparent 1px)",
          backgroundSize: "80px 80px",
          maskImage: "linear-gradient(to top, black, transparent)",
          transform: "perspective(900px) rotateX(60deg)",
          transformOrigin: "bottom"
        }
      }
    ),
    /* @__PURE__ */ jsxRuntimeExports.jsx(
      "div",
      {
        "aria-hidden": true,
        className: "pointer-events-none absolute -top-40 left-1/2 -z-10 h-[40rem] w-[60rem] -translate-x-1/2 rounded-full bg-accent/15 blur-3xl"
      }
    ),
    /* @__PURE__ */ jsxRuntimeExports.jsx(
      "div",
      {
        "aria-hidden": true,
        className: "pointer-events-none absolute bottom-0 right-0 -z-10 h-72 w-72 rounded-full bg-primary/10 blur-3xl"
      }
    ),
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "container-x flex items-center justify-between pt-6 text-[10px] uppercase tracking-[0.3em] text-primary/60 sm:pt-6", children: /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: s.eyebrow }) }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative pt-3 sm:pt-12 xl:pt-14", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "pointer-events-none absolute inset-x-0 top-5 z-0 flex justify-center sm:inset-x-0 sm:top-12 sm:bottom-0 sm:items-center sm:pb-0 xl:top-14", children: /* @__PURE__ */ jsxRuntimeExports.jsx(
        "h1",
        {
          className: "select-none whitespace-nowrap font-display font-bold leading-none text-primary text-[clamp(4.7rem,24vw,22rem)] sm:text-[clamp(6rem,22vw,22rem)]",
          style: {
            letterSpacing: "-0.04em",
            animation: transitioning ? "word-out 0.65s cubic-bezier(.7,0,.3,1) forwards" : "word-in 0.9s cubic-bezier(.2,.7,.2,1) forwards",
            WebkitTextStroke: "1px oklch(0.36 0.07 220)"
          },
          children: /* @__PURE__ */ jsxRuntimeExports.jsx(
            "span",
            {
              style: {
                background: "linear-gradient(180deg, oklch(0.36 0.07 220) 0%, oklch(0.36 0.07 220) 55%, oklch(0.7 0.13 55) 100%)",
                WebkitBackgroundClip: "text",
                backgroundClip: "text",
                WebkitTextFillColor: "transparent"
              },
              children: s.word
            }
          )
        },
        `w-${i}`
      ) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "container-x relative mt-7 grid h-[300px] grid-cols-3 items-end gap-2 pt-24 sm:mt-0 sm:h-[clamp(380px,64svh,690px)] sm:gap-6 sm:pt-0", children: modelSlots.map((src, idx) => {
        const delay = idx * 120;
        return /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "figure",
          {
            className: "relative flex h-[210px] items-end justify-center sm:h-[clamp(330px,60svh,650px)]",
            style: {
              animation: transitioning ? `model-out 0.55s ease-out ${delay}ms forwards` : `model-in 0.9s cubic-bezier(.2,.7,.2,1) ${delay}ms both`
            },
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                "span",
                {
                  "aria-hidden": true,
                  className: "absolute bottom-[6%] left-1/2 h-4 w-3/4 -translate-x-1/2 rounded-full bg-primary/25 blur-2xl"
                }
              ),
              src && /* @__PURE__ */ jsxRuntimeExports.jsx(HeroModelImage, { src })
            ]
          },
          `${i}-${idx}-${src || "empty"}`
        );
      }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "pointer-events-none relative z-20 mt-5 flex justify-center px-6 pb-3 sm:mt-6 sm:px-6 sm:pb-4", children: /* @__PURE__ */ jsxRuntimeExports.jsx(
        "p",
        {
          className: "pointer-events-auto max-w-md text-center text-sm leading-relaxed text-primary/75 sm:text-base",
          style: {
            animation: transitioning ? "fade-out-soft 0.4s forwards" : "fade-up 0.8s 0.3s both"
          },
          children: s.desc
        },
        `d-${i}`
      ) })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "container-x grid items-center gap-4 border-t border-primary/10 py-4 sm:mt-0 md:grid-cols-[1fr_auto_1fr]", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 justify-self-center md:justify-self-start", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "button",
          {
            onClick: () => go(i - 1),
            "aria-label": "Previous",
            className: "grid h-10 w-10 place-items-center rounded-full border border-primary/20 text-primary transition hover:bg-primary hover:text-primary-foreground",
            children: /* @__PURE__ */ jsxRuntimeExports.jsx(ChevronLeft, { className: "h-4 w-4" })
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "button",
          {
            onClick: () => go(i + 1),
            "aria-label": "Next",
            className: "grid h-10 w-10 place-items-center rounded-full border border-primary/20 text-primary transition hover:bg-primary hover:text-primary-foreground",
            children: /* @__PURE__ */ jsxRuntimeExports.jsx(ChevronRight, { className: "h-4 w-4" })
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "ml-3 flex items-center gap-2", children: activeScenes.map((_, idx) => /* @__PURE__ */ jsxRuntimeExports.jsx(
          "button",
          {
            onClick: () => idx !== i && go(idx),
            "aria-label": `Scene ${idx + 1}`,
            className: "h-1.5 rounded-full transition-all duration-500 " + (idx === i ? "w-10 bg-primary" : "w-4 bg-primary/25 hover:bg-primary/50")
          },
          idx
        )) })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs(
        Link,
        {
          to: "/products",
          className: "inline-flex max-w-full items-center justify-self-center gap-2 rounded-full bg-primary px-5 py-2.5 text-[10px] font-medium uppercase tracking-[0.18em] text-primary-foreground transition hover:-translate-y-0.5 hover:shadow-lg sm:px-6 sm:text-[11px] sm:tracking-[0.25em]",
          children: [
            "Explore the collection ",
            /* @__PURE__ */ jsxRuntimeExports.jsx(ArrowUpRight, { className: "h-4 w-4" })
          ]
        }
      ),
      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { "aria-hidden": true, className: "hidden md:block" })
    ] })
  ] });
}
function cn(...inputs) {
  return twMerge(clsx(inputs));
}
const buttonVariants = cva(
  "inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-md text-sm font-medium cursor-pointer transition-colors focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:pointer-events-none disabled:opacity-50 disabled:cursor-not-allowed [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0",
  {
    variants: {
      variant: {
        default: "bg-primary text-primary-foreground shadow hover:bg-primary/90",
        destructive: "bg-destructive text-destructive-foreground shadow-sm hover:bg-destructive/90",
        outline: "border border-input bg-background shadow-sm hover:bg-accent hover:text-accent-foreground",
        secondary: "bg-secondary text-secondary-foreground shadow-sm hover:bg-secondary/80",
        ghost: "hover:bg-accent hover:text-accent-foreground",
        link: "text-primary underline-offset-4 hover:underline"
      },
      size: {
        default: "h-9 px-4 py-2",
        sm: "h-8 rounded-md px-3 text-xs",
        lg: "h-10 rounded-md px-8",
        icon: "h-9 w-9"
      }
    },
    defaultVariants: {
      variant: "default",
      size: "default"
    }
  }
);
const Button = reactExports.forwardRef(
  ({ className, variant, size, asChild = false, ...props }, ref) => {
    const Comp = asChild ? Slot : "button";
    return /* @__PURE__ */ jsxRuntimeExports.jsx(Comp, { className: cn(buttonVariants({ variant, size, className })), ref, ...props });
  }
);
Button.displayName = "Button";
const CarouselContext = reactExports.createContext(null);
function useCarousel() {
  const context = reactExports.useContext(CarouselContext);
  if (!context) {
    throw new Error("useCarousel must be used within a <Carousel />");
  }
  return context;
}
const Carousel = reactExports.forwardRef(({ orientation = "horizontal", opts, setApi, plugins, className, children, ...props }, ref) => {
  const [carouselRef, api] = useEmblaCarousel(
    {
      ...opts,
      axis: orientation === "horizontal" ? "x" : "y"
    },
    plugins
  );
  const [canScrollPrev, setCanScrollPrev] = reactExports.useState(false);
  const [canScrollNext, setCanScrollNext] = reactExports.useState(false);
  const onSelect = reactExports.useCallback((api2) => {
    if (!api2) {
      return;
    }
    setCanScrollPrev(api2.canScrollPrev());
    setCanScrollNext(api2.canScrollNext());
  }, []);
  const scrollPrev = reactExports.useCallback(() => {
    api?.scrollPrev();
  }, [api]);
  const scrollNext = reactExports.useCallback(() => {
    api?.scrollNext();
  }, [api]);
  const handleKeyDown = reactExports.useCallback(
    (event) => {
      if (event.key === "ArrowLeft") {
        event.preventDefault();
        scrollPrev();
      } else if (event.key === "ArrowRight") {
        event.preventDefault();
        scrollNext();
      }
    },
    [scrollPrev, scrollNext]
  );
  reactExports.useEffect(() => {
    if (!api || !setApi) {
      return;
    }
    setApi(api);
  }, [api, setApi]);
  reactExports.useEffect(() => {
    if (!api) {
      return;
    }
    onSelect(api);
    api.on("reInit", onSelect);
    api.on("select", onSelect);
    return () => {
      api?.off("select", onSelect);
    };
  }, [api, onSelect]);
  return /* @__PURE__ */ jsxRuntimeExports.jsx(
    CarouselContext.Provider,
    {
      value: {
        carouselRef,
        api,
        opts,
        orientation: orientation || (opts?.axis === "y" ? "vertical" : "horizontal"),
        scrollPrev,
        scrollNext,
        canScrollPrev,
        canScrollNext
      },
      children: /* @__PURE__ */ jsxRuntimeExports.jsx(
        "div",
        {
          ref,
          onKeyDownCapture: handleKeyDown,
          className: cn("relative", className),
          role: "region",
          "aria-roledescription": "carousel",
          ...props,
          children
        }
      )
    }
  );
});
Carousel.displayName = "Carousel";
const CarouselContent = reactExports.forwardRef(
  ({ className, ...props }, ref) => {
    const { carouselRef, orientation } = useCarousel();
    return /* @__PURE__ */ jsxRuntimeExports.jsx("div", { ref: carouselRef, className: "overflow-hidden", children: /* @__PURE__ */ jsxRuntimeExports.jsx(
      "div",
      {
        ref,
        className: cn(
          "flex",
          orientation === "horizontal" ? "-ml-4" : "-mt-4 flex-col",
          className
        ),
        ...props
      }
    ) });
  }
);
CarouselContent.displayName = "CarouselContent";
const CarouselItem = reactExports.forwardRef(
  ({ className, ...props }, ref) => {
    const { orientation } = useCarousel();
    return /* @__PURE__ */ jsxRuntimeExports.jsx(
      "div",
      {
        ref,
        role: "group",
        "aria-roledescription": "slide",
        className: cn(
          "min-w-0 shrink-0 grow-0 basis-full",
          orientation === "horizontal" ? "pl-4" : "pt-4",
          className
        ),
        ...props
      }
    );
  }
);
CarouselItem.displayName = "CarouselItem";
const CarouselPrevious = reactExports.forwardRef(
  ({ className, variant = "outline", size = "icon", ...props }, ref) => {
    const { orientation, scrollPrev, canScrollPrev } = useCarousel();
    return /* @__PURE__ */ jsxRuntimeExports.jsxs(
      Button,
      {
        ref,
        variant,
        size,
        className: cn(
          "absolute  h-8 w-8 rounded-full",
          orientation === "horizontal" ? "-left-12 top-1/2 -translate-y-1/2" : "-top-12 left-1/2 -translate-x-1/2 rotate-90",
          className
        ),
        disabled: !canScrollPrev,
        onClick: scrollPrev,
        ...props,
        children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(ArrowLeft, { className: "h-4 w-4" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "sr-only", children: "Previous slide" })
        ]
      }
    );
  }
);
CarouselPrevious.displayName = "CarouselPrevious";
const CarouselNext = reactExports.forwardRef(
  ({ className, variant = "outline", size = "icon", ...props }, ref) => {
    const { orientation, scrollNext, canScrollNext } = useCarousel();
    return /* @__PURE__ */ jsxRuntimeExports.jsxs(
      Button,
      {
        ref,
        variant,
        size,
        className: cn(
          "absolute h-8 w-8 rounded-full",
          orientation === "horizontal" ? "-right-12 top-1/2 -translate-y-1/2" : "-bottom-12 left-1/2 -translate-x-1/2 rotate-90",
          className
        ),
        disabled: !canScrollNext,
        onClick: scrollNext,
        ...props,
        children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(ArrowRight, { className: "h-4 w-4" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "sr-only", children: "Next slide" })
        ]
      }
    );
  }
);
CarouselNext.displayName = "CarouselNext";
const products = [{
  img: knit,
  name: "Knit & Jersey",
  desc: "T-shirts, polos, sweats, loungewear"
}, {
  img: woven,
  name: "Woven Shirts",
  desc: "Casual, formal, oxford, flannel"
}, {
  img: denim,
  name: "Denim & Bottoms",
  desc: "Jeans, chinos, shorts, jackets"
}, {
  img: kids,
  name: "Kids & Babywear",
  desc: "Soft, safe, certified fabrics"
}];
const services = [{
  icon: Layers,
  t: "Sourcing",
  d: "Fabric, trims and accessories at the best mill price."
}, {
  icon: Factory,
  t: "Production",
  d: "Vetted factories, audited for compliance and capacity."
}, {
  icon: Shield,
  t: "Quality Assurance",
  d: "In-line and final inspections aligned to AQL 2.5."
}, {
  icon: Earth,
  t: "Logistics",
  d: "Door-to-door shipping, customs and consolidation."
}];
function Index() {
  const homeContent = Route$4.useLoaderData();
  const [testimonialApi, setTestimonialApi] = reactExports.useState();
  const brandLogos = homeContent.brandLogos;
  const testimonials = homeContent.testimonials;
  reactExports.useEffect(() => {
    if (!testimonialApi) return;
    const id = window.setInterval(() => {
      testimonialApi.scrollNext();
    }, 3500);
    return () => window.clearInterval(id);
  }, [testimonialApi]);
  const countryRows = [{
    code: "us",
    name: "United States"
  }, {
    code: "gb",
    name: "United Kingdom"
  }, {
    code: "de",
    name: "Germany"
  }, {
    code: "fr",
    name: "France"
  }, {
    code: "nl",
    name: "Netherlands"
  }, {
    code: "se",
    name: "Sweden"
  }, {
    code: "dk",
    name: "Denmark"
  }, {
    code: "es",
    name: "Spain"
  }, {
    code: "it",
    name: "Italy"
  }, {
    code: "ca",
    name: "Canada"
  }, {
    code: "au",
    name: "Australia"
  }, {
    code: "jp",
    name: "Japan"
  }, {
    code: "kr",
    name: "South Korea"
  }, {
    code: "pl",
    name: "Poland"
  }, {
    code: "be",
    name: "Belgium"
  }, {
    code: "no",
    name: "Norway"
  }];
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(SiteLayout, { children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("section", { className: "relative overflow-hidden", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(BgShapes, { variant: "hero" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(HeroSlider, {})
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("section", { className: "section-reveal bg-white py-24 lg:py-32", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "container-x grid gap-12 lg:grid-cols-2", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("img", { src: factory, alt: "Garment factory floor", width: 1600, height: 1e3, loading: "lazy", className: "aspect-[5/4] w-full rounded-3xl object-cover shadow-[0_30px_80px_-55px_oklch(0.22_0.04_220/0.55)]" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("img", { src: quality, alt: "Fabric quality inspection", width: 1200, height: 1400, loading: "lazy", className: "absolute -bottom-10 -right-6 hidden aspect-[3/4] w-48 rounded-2xl border-4 border-white object-cover shadow-xl md:block" })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "lg:pl-8", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "eyebrow", children: "About us" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "mt-4 font-display text-4xl leading-tight text-primary md:text-5xl", children: "A buying house that feels like an extension of your team." }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-6 text-muted-foreground", children: "For nearly two decades we have helped brands navigate Bangladesh's garment industry — from the first sketch to the final container. We pair the right factory to the right product, hold the line on quality, and keep your timeline honest." }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("ul", { className: "mt-8 grid gap-4 sm:grid-cols-2", children: [{
          i: Sparkles,
          t: "Design to delivery"
        }, {
          i: Leaf,
          t: "Ethical, audited supply"
        }, {
          i: Shield,
          t: "AQL inspections"
        }, {
          i: Earth,
          t: "Worldwide logistics"
        }].map(({
          i: Icon,
          t
        }) => /* @__PURE__ */ jsxRuntimeExports.jsxs("li", { className: "flex items-center gap-3 rounded-xl border border-border/80 bg-[oklch(0.985_0.006_205)] p-4 shadow-sm", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "grid h-10 w-10 place-items-center rounded-full bg-accent/12 text-primary", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Icon, { className: "h-5 w-5" }) }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-sm font-medium", children: t })
        ] }, t)) }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs(Link, { to: "/about", className: "mt-10 inline-flex items-center gap-2 text-sm font-medium text-primary underline-offset-4 hover:underline", children: [
          "Read our story ",
          /* @__PURE__ */ jsxRuntimeExports.jsx(ArrowUpRight, { className: "h-4 w-4" })
        ] })
      ] })
    ] }) }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("section", { className: "section-reveal bg-[oklch(0.24_0.07_205)] py-20 text-white md:py-24", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "container-x grid gap-10 lg:grid-cols-[0.85fr_1.15fr]", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "eyebrow text-white/70", children: "Factory profile" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "mt-3 font-display text-4xl text-white md:text-5xl", children: "Established manufacturing capacity with partner factory reach." }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-5 text-white/70", children: "Mart Tex was established in 2010 with own knitwear production, a 14,000 sq ft facility and partner factory support for woven, denim and larger apparel programs." }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs(Link, { to: "/profile", className: "mt-8 inline-flex items-center gap-2 rounded-full bg-white px-6 py-3 text-sm font-medium text-primary transition hover:-translate-y-0.5 hover:shadow-lg", children: [
          "View company profile ",
          /* @__PURE__ */ jsxRuntimeExports.jsx(ArrowUpRight, { className: "h-4 w-4" })
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "grid gap-4 sm:grid-cols-2", children: [{
        icon: Factory,
        value: "14,000",
        label: "Sq ft production space"
      }, {
        icon: Layers,
        value: "2M+",
        label: "Own factory pieces / year"
      }, {
        icon: Shield,
        value: "149",
        label: "Listed machines"
      }, {
        icon: Earth,
        value: "20M+",
        label: "Partner factory supply capacity"
      }].map(({
        icon: Icon,
        value,
        label
      }) => /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rounded-2xl border border-white/15 bg-white/8 p-6", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(Icon, { className: "h-6 w-6 text-accent" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-5 font-display text-4xl text-white", children: value }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-2 text-sm text-white/65", children: label })
      ] }, label)) })
    ] }) }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("section", { className: "section-reveal bg-[linear-gradient(180deg,oklch(0.95_0.014_205)_0%,oklch(0.985_0.004_205)_100%)] py-24 md:py-32", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "container-x", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-wrap items-end justify-between gap-6", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "eyebrow", children: "Product capability" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "mt-3 max-w-xl font-display text-4xl text-primary md:text-5xl", children: "What we make, what we ship." })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs(Link, { to: "/products", className: "btn-outline", children: [
          "All categories ",
          /* @__PURE__ */ jsxRuntimeExports.jsx(ArrowUpRight, { className: "h-4 w-4" })
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "mt-12 grid gap-6 sm:grid-cols-2 lg:grid-cols-4", children: products.map((p) => /* @__PURE__ */ jsxRuntimeExports.jsxs(Link, { to: "/products", className: "group overflow-hidden rounded-2xl border border-white/70 bg-white shadow-sm transition hover:-translate-y-1 hover:shadow-xl", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "aspect-[4/5] overflow-hidden", children: /* @__PURE__ */ jsxRuntimeExports.jsx("img", { src: p.img, alt: p.name, width: 1e3, height: 1200, loading: "lazy", className: "h-full w-full object-cover transition duration-700 group-hover:scale-105" }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-5", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "font-display text-xl text-primary", children: p.name }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-1 text-sm text-muted-foreground", children: p.desc })
        ] })
      ] }, p.name)) })
    ] }) }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("section", { className: "section-reveal overflow-hidden bg-[oklch(0.24_0.07_205)] py-16 text-white md:py-24", children: /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "container-x", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "overflow-hidden py-12 md:py-16", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "px-6 text-center", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "eyebrow justify-center rounded-full bg-white/10 px-4 py-2 text-white/70", children: "Global reach" }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("h2", { className: "mt-5 font-display text-4xl text-white md:text-5xl", children: [
          "We Export To ",
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-accent", children: "15+ Countries" })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mx-auto mt-4 max-w-2xl text-white/70", children: "From North America to Asia-Pacific, our garments reach buyers and retailers across the globe." })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative left-1/2 mt-10 w-screen -translate-x-1/2 space-y-4 overflow-hidden", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "overflow-hidden", children: /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex w-max animate-country-left gap-4", children: [...countryRows, ...countryRows].map((country, i) => /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex h-14 min-w-44 items-center gap-3 rounded-2xl border border-white/15 bg-white/95 px-5 text-sm font-medium text-foreground shadow-sm", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("img", { src: `https://flagcdn.com/w40/${country.code}.png`, alt: `${country.name} flag`, width: 28, height: 20, loading: "lazy", className: "h-5 w-7 rounded-[2px] object-cover" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: country.name })
        ] }, `top-${country.name}-${i}`)) }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "overflow-hidden", children: /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex w-max animate-country-right gap-4", children: [...countryRows].reverse().concat([...countryRows].reverse()).map((country, i) => /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex h-14 min-w-44 items-center gap-3 rounded-2xl border border-white/15 bg-white/95 px-5 text-sm font-medium text-foreground shadow-sm", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("img", { src: `https://flagcdn.com/w40/${country.code}.png`, alt: `${country.name} flag`, width: 28, height: 20, loading: "lazy", className: "h-5 w-7 rounded-[2px] object-cover" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: country.name })
        ] }, `bottom-${country.name}-${i}`)) }) })
      ] })
    ] }) }) }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("section", { className: "section-reveal bg-white py-24 md:py-32", children: /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "container-x", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid gap-12 lg:grid-cols-[1fr_1.2fr]", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "eyebrow", children: "Services" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "mt-3 font-display text-4xl text-primary md:text-5xl", children: "From the first stitch to the last mile." }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-6 max-w-md text-muted-foreground", children: "Four core services, one accountable team. We work as an integrated partner so your buyers stay focused on the brand, not on the back-office." }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs(Link, { to: "/services", className: "btn-primary mt-8", children: [
          "Explore services ",
          /* @__PURE__ */ jsxRuntimeExports.jsx(ArrowUpRight, { className: "h-4 w-4" })
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "grid gap-5 sm:grid-cols-2", children: services.map(({
        icon: Icon,
        t,
        d
      }) => /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rounded-2xl border border-border/80 bg-[oklch(0.985_0.006_205)] p-6 shadow-sm", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "grid h-12 w-12 place-items-center rounded-xl bg-primary text-primary-foreground shadow-sm", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Icon, { className: "h-6 w-6" }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "mt-5 font-display text-xl text-primary", children: t }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-2 text-sm text-muted-foreground", children: d })
      ] }, t)) })
    ] }) }) }),
    brandLogos.length > 0 && /* @__PURE__ */ jsxRuntimeExports.jsx("section", { className: "section-reveal overflow-hidden border-y border-border bg-[linear-gradient(180deg,white_0%,oklch(0.97_0.006_205)_100%)] py-12 md:py-16", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "container-x", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-center", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "eyebrow justify-center", children: "Trusted by" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "mt-4 font-display text-4xl text-primary md:text-5xl", children: "Top Brands" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mx-auto mt-4 max-w-3xl text-muted-foreground", children: "We connect global fashion brands with Bangladesh's top garment manufacturers — handling sourcing, sampling, production and shipping under one roof." })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "mx-auto mt-8 w-full max-w-6xl overflow-hidden", children: /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex w-max animate-brand-marquee items-center gap-3 sm:gap-5 md:gap-8", children: [...brandLogos, ...brandLogos].map((logo, i) => /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex h-20 w-28 shrink-0 items-center justify-center px-1 sm:w-32 md:h-24 md:w-44", children: /* @__PURE__ */ jsxRuntimeExports.jsx("img", { src: logo, alt: "", loading: "lazy", className: "h-16 w-auto max-w-[130px] object-contain sm:h-20 sm:max-w-[160px] md:h-24 md:max-w-[210px]" }) }, i)) }) })
    ] }) }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("section", { className: "section-reveal bg-[oklch(0.975_0.006_205)] py-24 md:py-32", children: /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "container-x", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative grid items-center overflow-hidden rounded-3xl border border-border/80 bg-[linear-gradient(135deg,white_0%,oklch(0.94_0.015_205)_100%)] shadow-[0_30px_90px_-70px_oklch(0.22_0.04_220/0.7)] md:grid-cols-[1.1fr_1fr]", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("svg", { "aria-hidden": true, viewBox: "0 0 400 400", className: "pointer-events-none absolute right-1/3 top-1/2 hidden h-[28rem] w-[28rem] -translate-y-1/2 text-primary/[0.06] md:block", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("path", { d: "M200 40 C 90 90 50 200 90 320 C 160 290 220 220 240 140 C 250 100 230 60 200 40 Z", fill: "currentColor" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("path", { d: "M210 80 C 240 140 240 220 200 300", stroke: "currentColor", strokeWidth: "2", fill: "none" })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative z-10 p-10 md:p-16", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "eyebrow", children: "Get in touch" }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("h2", { className: "mt-4 font-display text-5xl leading-[1.05] text-primary md:text-6xl", children: [
          "Let's Work ",
          /* @__PURE__ */ jsxRuntimeExports.jsx("em", { className: "italic font-normal", children: "Together." })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-6 max-w-md text-muted-foreground", children: "Whether you're sampling a capsule or scaling a season, our Dhaka team plugs into your workflow — quick replies, transparent costing and factories that match your product." }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-8 flex flex-wrap gap-3", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs(Link, { to: "/contact", className: "btn-primary", children: [
            "Contact us ",
            /* @__PURE__ */ jsxRuntimeExports.jsx(ArrowUpRight, { className: "h-4 w-4" })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs(Link, { to: "/services", className: "btn-outline", children: [
            "How we work ",
            /* @__PURE__ */ jsxRuntimeExports.jsx(ArrowUpRight, { className: "h-4 w-4" })
          ] })
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative h-72 md:h-full md:min-h-[28rem]", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("img", { src: sourcing, alt: "Stacked garments on a studio chair", loading: "lazy", className: "absolute inset-0 h-full w-full object-cover" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "absolute inset-0 bg-gradient-to-r from-white/85 via-transparent to-transparent md:from-[oklch(0.94_0.015_205)] md:via-[oklch(0.94_0.015_205/0.3)]" })
      ] })
    ] }) }) }),
    testimonials.length > 0 && /* @__PURE__ */ jsxRuntimeExports.jsxs("section", { className: "section-reveal relative overflow-hidden bg-[oklch(0.965_0.011_205)] py-24 md:py-32", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "pointer-events-none absolute inset-0 bg-[radial-gradient(ellipse_at_top_left,oklch(0.61_0.14_150/0.12),transparent_58%)]" }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "container-x text-center", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "eyebrow justify-center", children: "Partner voices" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "mt-4 font-display text-4xl text-primary md:text-5xl", children: "Testimonials" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mx-auto mt-5 max-w-2xl text-muted-foreground", children: "We're not just another buying house — we're your local production partner in Bangladesh, trusted by global fashion brands for reliability, transparency and craft." })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "container-x mt-14", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(Carousel, { opts: {
        align: "start",
        loop: true
      }, setApi: setTestimonialApi, className: "w-full", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(CarouselContent, { className: "-ml-5", children: testimonials.map((t) => /* @__PURE__ */ jsxRuntimeExports.jsx(CarouselItem, { className: "pl-5 md:basis-1/2 lg:basis-1/3", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("figure", { className: "flex h-full flex-col rounded-2xl border border-white/80 bg-white p-7 shadow-md transition-all duration-300 hover:-translate-y-1 hover:shadow-xl", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-display text-5xl leading-none text-primary/20", children: '"' }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "-mt-2 flex gap-0.5 text-amber-400", children: Array.from({
            length: 5
          }).map((_, i) => /* @__PURE__ */ jsxRuntimeExports.jsx("svg", { viewBox: "0 0 20 20", fill: "currentColor", className: "h-4 w-4", children: /* @__PURE__ */ jsxRuntimeExports.jsx("path", { d: "M10 1.5l2.6 5.6 6.1.6-4.6 4.2 1.3 6L10 14.9 4.6 17.9l1.3-6L1.3 7.7l6.1-.6L10 1.5z" }) }, i)) }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("blockquote", { className: "mt-4 flex-1 text-[15px] leading-relaxed text-foreground/80", children: t.quote }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("figcaption", { className: "mt-6 flex items-center gap-3 border-t border-border pt-5", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "grid h-11 w-11 place-items-center rounded-full bg-primary/10 font-display text-sm text-primary", children: t.initials }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "font-medium leading-tight text-foreground", children: t.name }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-muted-foreground", children: t.role })
            ] })
          ] })
        ] }) }, t.name)) }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-8 flex justify-center gap-3", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(CarouselPrevious, { className: "relative left-auto top-auto translate-y-0 h-11 w-11 rounded-full border-border bg-white shadow-md hover:bg-primary hover:text-primary-foreground hover:border-primary" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(CarouselNext, { className: "relative right-auto top-auto translate-y-0 h-11 w-11 rounded-full border-border bg-white shadow-md hover:bg-primary hover:text-primary-foreground hover:border-primary" })
        ] })
      ] }) })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("section", { className: "section-reveal relative overflow-hidden bg-white py-24 md:py-32", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(BgShapes, { variant: "soft" }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "container-x", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-wrap items-end justify-between gap-6", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "eyebrow", children: "News & insights" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "mt-3 max-w-xl font-display text-4xl text-primary md:text-5xl", children: "From the floor, to your feed." })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs(Link, { to: "/news", className: "btn-outline", children: [
            "All articles ",
            /* @__PURE__ */ jsxRuntimeExports.jsx(ArrowUpRight, { className: "h-4 w-4" })
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-14 grid gap-8 lg:grid-cols-[1.4fr_1fr]", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs(Link, { to: "/news/$slug", params: {
            slug: "bangladesh-rmg-exports"
          }, className: "group relative block overflow-hidden rounded-3xl border border-border bg-card", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "aspect-[16/11] overflow-hidden", children: /* @__PURE__ */ jsxRuntimeExports.jsx("img", { src: factory, alt: "", loading: "lazy", className: "h-full w-full object-cover transition-transform duration-[1400ms] group-hover:scale-110" }) }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-8 md:p-10", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-3 text-[11px] uppercase tracking-[0.25em] text-muted-foreground", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "rounded-full bg-secondary px-3 py-1", children: "Industry" }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "inline-flex items-center gap-1.5", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(Calendar, { className: "h-3 w-3" }),
                  " April 2026"
                ] })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "mt-4 max-w-2xl font-display text-3xl leading-tight text-primary md:text-4xl", children: "Bangladesh RMG exports cross USD 50B — what it means for buyers" }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "mt-5 inline-flex items-center gap-2 text-sm font-medium text-primary", children: [
                "Read story",
                " ",
                /* @__PURE__ */ jsxRuntimeExports.jsx(ArrowUpRight, { className: "h-4 w-4 transition group-hover:translate-x-1" })
              ] })
            ] })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex flex-col gap-6", children: [{
            slug: "cotton-recycled-blends",
            img: sourcing,
            tag: "Sourcing",
            date: "March 2026",
            title: "Cotton vs. recycled blends: a cost & quality look at SS27"
          }, {
            slug: "qa-protocol",
            img: quality,
            tag: "Quality",
            date: "February 2026",
            title: "Inside our QA protocol — defect rate cut by 38%"
          }, {
            slug: "knitwear-capacity",
            img: knit,
            tag: "Capability",
            date: "January 2026",
            title: "Knitwear capacity: what 12M pieces a season looks like"
          }].map((p) => /* @__PURE__ */ jsxRuntimeExports.jsxs(Link, { to: "/news/$slug", params: {
            slug: p.slug
          }, className: "group grid grid-cols-[140px_1fr] gap-5 overflow-hidden rounded-2xl border border-border bg-card transition hover:-translate-y-0.5 hover:shadow-lg sm:grid-cols-[180px_1fr]", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "overflow-hidden", children: /* @__PURE__ */ jsxRuntimeExports.jsx("img", { src: p.img, alt: "", loading: "lazy", className: "h-full w-full object-cover transition-transform duration-700 group-hover:scale-110" }) }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-col justify-center py-4 pr-5", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 text-[10px] uppercase tracking-[0.2em] text-muted-foreground", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: p.tag }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-primary/30", children: "·" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: p.date })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "mt-2 font-display text-lg leading-snug text-primary md:text-xl", children: p.title }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "mt-3 inline-flex items-center gap-1.5 text-xs font-medium text-primary opacity-70 transition group-hover:opacity-100", children: [
                "Read more ",
                /* @__PURE__ */ jsxRuntimeExports.jsx(ArrowUpRight, { className: "h-3.5 w-3.5" })
              ] })
            ] })
          ] }, p.slug)) })
        ] })
      ] })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("section", { className: "section-reveal bg-white pb-24 md:pb-32", children: /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "container-x", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative grid place-items-center gap-10 overflow-hidden rounded-3xl bg-[linear-gradient(135deg,oklch(0.24_0.07_205)_0%,oklch(0.31_0.075_214)_58%,oklch(0.38_0.11_150)_100%)] p-10 text-center text-primary-foreground shadow-[0_35px_90px_-55px_oklch(0.24_0.07_205/0.8)] md:p-16", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "absolute -right-20 -top-20 h-72 w-72 rounded-full bg-accent/25 blur-3xl" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "absolute -bottom-20 -left-10 h-72 w-72 rounded-full bg-white/10 blur-3xl" }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative max-w-3xl", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "font-display text-4xl md:text-5xl", children: "Have a tech pack? Let's price it." }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mx-auto mt-4 max-w-lg text-primary-foreground/80", children: "Send your tech pack, target FOB and quantity. We'll come back within 48 hours with the right factory and a clear quote." })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative flex flex-wrap justify-center gap-3", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs(Link, { to: "/contact", className: "inline-flex w-full items-center justify-center gap-2 rounded-full bg-primary-foreground px-6 py-3 text-sm font-medium text-primary transition hover:-translate-y-0.5 hover:shadow-lg sm:w-auto", children: [
          "Request a Quote ",
          /* @__PURE__ */ jsxRuntimeExports.jsx(ArrowUpRight, { className: "h-4 w-4" })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("a", { href: "mailto:info@marttex.net", className: "inline-flex w-full items-center justify-center gap-2 rounded-full border border-primary-foreground/40 px-6 py-3 text-sm font-medium text-primary-foreground transition hover:bg-primary-foreground/10 sm:w-auto", children: [
          "Email us ",
          /* @__PURE__ */ jsxRuntimeExports.jsx(ArrowUpRight, { className: "h-4 w-4" })
        ] })
      ] })
    ] }) }) })
  ] });
}
export {
  Index as component
};
