import { j as jsxRuntimeExports } from "../_libs/react.mjs";
import { S as SiteLayout, P as PageHeader } from "./Layout-DmJfC9JZ.mjs";
import { f as factory, q as quality } from "./router-BdpYW1Gv.mjs";
import { f as CircleCheck } from "../_libs/lucide-react.mjs";
import "../_libs/tanstack__react-router.mjs";
import "../_libs/tanstack__router-core.mjs";
import "../_libs/tanstack__history.mjs";
import "../_libs/cookie-es.mjs";
import "../_libs/seroval.mjs";
import "../_libs/seroval-plugins.mjs";
import "node:stream/web";
import "node:stream";
import "../_libs/react-dom.mjs";
import "util";
import "crypto";
import "async_hooks";
import "stream";
import "../_libs/isbot.mjs";
import "../_libs/tanstack__query-core.mjs";
import "../_libs/tanstack__react-query.mjs";
const values = [{
  t: "Integrity first",
  d: "We say what we mean, quote what we'll deliver and own the gaps when they appear."
}, {
  t: "Quality is non-negotiable",
  d: "Inspections at every step, from fabric and trims to sewing, finishing and final packing."
}, {
  t: "People before pieces",
  d: "Workplace safety, health safety, fire safety and product safety are part of the production system."
}, {
  t: "Reliable supply",
  d: "Own factory production is supported by partner factory capacity for larger and more varied programs."
}];
function About() {
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(SiteLayout, { children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx(PageHeader, { eyebrow: "About", title: "A manufacturing and sourcing team focused on getting garments right.", lead: "Established in 2010 in Dhaka, Mart Tex is a readymade garment manufacturer, supplier and exporter with own knitwear production and partner factory capacity across woven, denim and lingerie." }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("section", { className: "section-reveal container-x grid gap-12 py-24 lg:grid-cols-2", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("img", { src: factory, alt: "Factory floor", width: 1600, height: 1e3, loading: "lazy", className: "aspect-[5/4] w-full rounded-3xl object-cover" }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "eyebrow", children: "Our story" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "mt-3 font-display text-4xl text-primary md:text-5xl", children: "From own knitwear production to partner factory supply." }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-6 text-muted-foreground", children: "Mart Tex produces around 2 million pieces of garments per year in its own facility and can supply more than 20 million pieces through partner factories. The work spans manufacturing, sourcing, quality assurance and supply chain management." }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-4 text-muted-foreground", children: "The factory and office are located at Nikunja-02, Road-09, House-07, Khilkhet, Dhaka-1229, Bangladesh." })
      ] })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("section", { className: "section-reveal bg-secondary/40 py-24", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "container-x", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "eyebrow", children: "Our values" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "mt-3 max-w-2xl font-display text-4xl text-primary md:text-5xl", children: "Four things we will not compromise on." }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "mt-12 grid gap-6 md:grid-cols-2", children: values.map((v) => /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rounded-2xl border border-border bg-card p-8", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(CircleCheck, { className: "h-7 w-7 text-primary" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "mt-4 font-display text-2xl text-primary", children: v.t }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-2 text-muted-foreground", children: v.d })
      ] }, v.t)) })
    ] }) }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("section", { className: "section-reveal container-x grid items-center gap-12 py-24 lg:grid-cols-[1fr_1.2fr]", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("img", { src: quality, alt: "Fabric quality check", width: 1200, height: 1400, loading: "lazy", className: "aspect-[3/4] w-full rounded-3xl object-cover" }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "eyebrow", children: "Quality and safety" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "mt-3 font-display text-4xl text-primary md:text-5xl", children: "Controls you can stand behind." }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-6 text-muted-foreground", children: "The factory profile describes SOP-driven quality control, laboratory testing through accredited labs, workplace safety monitoring and product safety checks across raw material sourcing, dyeing, washing and chemicals." }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "mt-8 grid grid-cols-2 gap-4 sm:grid-cols-3", children: ["Fabric SOP", "Cutting SOP", "Sewing QA", "Final Inspection", "Lab Testing", "Safety Control"].map((c) => /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "rounded-xl border border-border bg-card px-4 py-5 text-center font-display text-lg text-primary", children: c }, c)) })
      ] })
    ] })
  ] });
}
export {
  About as component
};
