import { j as jsxRuntimeExports } from "../_libs/react.mjs";
import { S as SiteLayout, P as PageHeader } from "./Layout-DmJfC9JZ.mjs";
import { r as Palette, L as Layers, u as Ruler, F as Factory, x as ShieldCheck, g as ClipboardCheck, B as Boxes, E as Earth } from "../_libs/lucide-react.mjs";
import "../_libs/tanstack__react-router.mjs";
import "../_libs/tanstack__router-core.mjs";
import "../_libs/tanstack__history.mjs";
import "../_libs/cookie-es.mjs";
import "../_libs/seroval.mjs";
import "../_libs/seroval-plugins.mjs";
import "node:stream/web";
import "node:stream";
import "../_libs/react-dom.mjs";
import "util";
import "crypto";
import "async_hooks";
import "stream";
import "../_libs/isbot.mjs";
import "./router-BdpYW1Gv.mjs";
import "../_libs/tanstack__query-core.mjs";
import "../_libs/tanstack__react-query.mjs";
const items = [{
  i: Palette,
  t: "Product Development",
  d: "From mood board and tech pack to first proto. Pattern, fit and trim engineering done in-house."
}, {
  i: Layers,
  t: "Sourcing",
  d: "Fabric, trims and accessories from mills we know personally. Best price, predictable lead times."
}, {
  i: Ruler,
  t: "Sampling",
  d: "Salesman, fit, size set and PPS samples in nine days on average."
}, {
  i: Factory,
  t: "Production",
  d: "Allocation across 60+ audited factories, matched to product type, capacity and certification needs."
}, {
  i: ShieldCheck,
  t: "Quality Assurance",
  d: "In-line, mid-line and final inspections to AQL 2.5 — or your custom protocol."
}, {
  i: ClipboardCheck,
  t: "Compliance",
  d: "WRAP, BSCI, Sedex SMETA, Accord. Fresh audit reports with every PO."
}, {
  i: Boxes,
  t: "Packing & Labelling",
  d: "Polybag, carton, hangtag, RFID. Retailer-ready straight from the factory floor."
}, {
  i: Earth,
  t: "Logistics",
  d: "FCL, LCL, air. Door-to-door with customs handled by our forwarding partners."
}];
function Services() {
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(SiteLayout, { children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx(PageHeader, { eyebrow: "Services", title: "Eight services, one accountable team.", lead: "Pick the bundle you need. Most brands work with us end-to-end — from a sketch to a stocked warehouse." }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("section", { className: "section-reveal container-x grid gap-6 py-24 md:grid-cols-2", children: items.map(({
      i: Icon,
      t,
      d
    }) => /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex gap-5 rounded-2xl border border-border bg-card p-7", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "grid h-12 w-12 shrink-0 place-items-center rounded-xl bg-primary text-primary-foreground", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Icon, { className: "h-6 w-6" }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "font-display text-2xl text-primary", children: t }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-2 text-muted-foreground", children: d })
      ] })
    ] }, t)) }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("section", { className: "section-reveal bg-secondary/40 py-24", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "container-x", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "eyebrow", children: "How we work" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "mt-3 font-display text-4xl text-primary md:text-5xl", children: "A predictable, six-step process." }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("ol", { className: "mt-12 grid gap-6 md:grid-cols-3", children: [["01", "Brief & quote", "Send tech pack, target FOB and quantity. Quote in 48 hours."], ["02", "Sampling", "Proto, fit and PPS samples within 9–14 days."], ["03", "Factory match", "Allocation to the right audited factory."], ["04", "Production", "Daily WIP, photo updates, in-line QA."], ["05", "Final inspection", "AQL 2.5 final inspection, report shared."], ["06", "Shipping", "Container loading, BL, doc handover."]].map(([n, t, d]) => /* @__PURE__ */ jsxRuntimeExports.jsxs("li", { className: "rounded-2xl border border-border bg-card p-7", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-display text-3xl text-accent", children: n }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "mt-3 font-display text-xl text-primary", children: t }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-2 text-sm text-muted-foreground", children: d })
      ] }, n)) })
    ] }) })
  ] });
}
export {
  Services as component
};
