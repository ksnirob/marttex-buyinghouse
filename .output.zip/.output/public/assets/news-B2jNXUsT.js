import{j as t,O as o}from"./index-DdGn726k.js";const n=()=>t.jsx(o,{});export{n as component};
