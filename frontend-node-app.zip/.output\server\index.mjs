globalThis.__nitro_main__ = import.meta.url;
import { N as NodeResponse, s as serve } from "./_libs/srvx.mjs";
import { d as defineHandler, a as HTTPError, t as toEventHandler, b as defineLazyEventHandler, H as H3Core } from "./_libs/h3.mjs";
import { d as decodePath, w as withLeadingSlash, a as withoutTrailingSlash, j as joinURL } from "./_libs/ufo.mjs";
import { promises } from "node:fs";
import { fileURLToPath } from "node:url";
import { dirname, resolve } from "node:path";
import "node:http";
import "node:stream";
import "node:stream/promises";
import "node:https";
import "node:http2";
import "./_libs/rou3.mjs";
function lazyService(loader) {
  let promise, mod;
  return {
    fetch(req) {
      if (mod) {
        return mod.fetch(req);
      }
      if (!promise) {
        promise = loader().then((_mod) => mod = _mod.default || _mod);
      }
      return promise.then((mod2) => mod2.fetch(req));
    }
  };
}
const services = {
  ["ssr"]: lazyService(() => import("./_ssr/index.mjs"))
};
globalThis.__nitro_vite_envs__ = services;
const headers = ((m) => function headersRouteRule(event) {
  for (const [key2, value] of Object.entries(m.options || {})) {
    event.res.headers.set(key2, value);
  }
});
const assets = {
  "/robots.txt": {
    "type": "text/plain; charset=utf-8",
    "etag": '"19-yHADZo6lKl+mSNPU9098EiqzPCE"',
    "mtime": "2026-05-21T12:36:07.800Z",
    "size": 25,
    "path": "../public/robots.txt"
  },
  "/assets/about-D_dwicHj.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"e89-IpOTueAkSyFg5OMejp+f7G6cBCM"',
    "mtime": "2026-07-14T15:57:00.152Z",
    "size": 3721,
    "path": "../public/assets/about-D_dwicHj.js"
  },
  "/assets/admin-DIyBgwLU.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"a350-2pvO5hAj0PuRBMMxxe6i1MAg67w"',
    "mtime": "2026-07-14T15:57:00.152Z",
    "size": 41808,
    "path": "../public/assets/admin-DIyBgwLU.js"
  },
  "/assets/boxes-BkelcdsK.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"350-DtB3nrev8IMG4TatRIs4zdXDFDo"',
    "mtime": "2026-07-14T15:57:00.152Z",
    "size": 848,
    "path": "../public/assets/boxes-BkelcdsK.js"
  },
  "/assets/BgShapes-D9n4oFDd.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"810-PU2TSDkmmL3d2gC0yb7sfGsXR3c"',
    "mtime": "2026-07-14T15:57:00.152Z",
    "size": 2064,
    "path": "../public/assets/BgShapes-D9n4oFDd.js"
  },
  "/assets/circle-check-ChHDfZfO.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"aa-RGdynWwxQvWQfPysgT/nPwiZywI"',
    "mtime": "2026-07-14T15:57:00.152Z",
    "size": 170,
    "path": "../public/assets/circle-check-ChHDfZfO.js"
  },
  "/assets/arrow-left-BoynkDXx.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"a2-OXwkAezgJWdapTNCZtQic4CVx+Y"',
    "mtime": "2026-07-14T15:57:00.153Z",
    "size": 162,
    "path": "../public/assets/arrow-left-BoynkDXx.js"
  },
  "/assets/calendar-CsqdpjLC.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"fe-zfMtyiQ9+OzNrwv/lPmKas4wJI4"',
    "mtime": "2026-07-14T15:57:00.153Z",
    "size": 254,
    "path": "../public/assets/calendar-CsqdpjLC.js"
  },
  "/assets/chevron-right-fomD89T6.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"d1-2Nzm2NDK4nZ8NiBn2hzY5Z0dzNY"',
    "mtime": "2026-07-14T15:57:00.152Z",
    "size": 209,
    "path": "../public/assets/chevron-right-fomD89T6.js"
  },
  "/assets/factory-BmFxQKBQ.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"194-FDAhOkk5YJgCqsbdpWxCYEXnmLw"',
    "mtime": "2026-07-14T15:57:00.152Z",
    "size": 404,
    "path": "../public/assets/factory-BmFxQKBQ.js"
  },
  "/assets/contact-SaRarPF6.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"fae-aBMmK2jmaIcPtFus3P9KcFSdBow"',
    "mtime": "2026-07-14T15:57:00.152Z",
    "size": 4014,
    "path": "../public/assets/contact-SaRarPF6.js"
  },
  "/assets/gallery-cNQxCNqi.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"46e-hVzuZ/eeDUkl0f8333dRFnnq0AU"',
    "mtime": "2026-07-14T15:57:00.152Z",
    "size": 1134,
    "path": "../public/assets/gallery-cNQxCNqi.js"
  },
  "/assets/Layout-BVB6FUiQ.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"2fb9-DgUg6yxnDNrLE7xmiSCZnKWSRjE"',
    "mtime": "2026-07-14T15:57:00.153Z",
    "size": 12217,
    "path": "../public/assets/Layout-BVB6FUiQ.js"
  },
  "/assets/factory-BUD3QnGw.jpg": {
    "type": "image/jpeg",
    "etag": '"3674d-FTQiGg1WB1FYmMZ711M1xWLH8lE"',
    "mtime": "2026-07-14T15:57:00.151Z",
    "size": 223053,
    "path": "../public/assets/factory-BUD3QnGw.jpg"
  },
  "/assets/layers-Da3yjROL.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"2fb-hPQ4oV2hYG8hqLUWH8wa305Zhw4"',
    "mtime": "2026-07-14T15:57:00.152Z",
    "size": 763,
    "path": "../public/assets/layers-Da3yjROL.js"
  },
  "/assets/Lightbox-Cf4JBT1h.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"8ff-eoqifo/CwaHw6laIy+KxKYGWvys"',
    "mtime": "2026-07-14T15:57:00.152Z",
    "size": 2303,
    "path": "../public/assets/Lightbox-Cf4JBT1h.js"
  },
  "/assets/index-BXLTNNKl.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"14109-DB2EawC5cmo/G7SlMDjqLWWB0Y8"',
    "mtime": "2026-07-14T15:57:00.152Z",
    "size": 82185,
    "path": "../public/assets/index-BXLTNNKl.js"
  },
  "/assets/index-BSXPnZSn.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"58499-vKAJCcJOVz0su15bNVzkmpN+VXQ"',
    "mtime": "2026-07-14T15:57:00.152Z",
    "size": 361625,
    "path": "../public/assets/index-BSXPnZSn.js"
  },
  "/assets/hero-garments-CIxYALS4.jpg": {
    "type": "image/jpeg",
    "etag": '"3dc5d-T9DW5w4otFMIPzlWImUjElSOMP4"',
    "mtime": "2026-07-14T15:57:00.151Z",
    "size": 253021,
    "path": "../public/assets/hero-garments-CIxYALS4.jpg"
  },
  "/assets/model-s2-male1-BuGgDqm4.png": {
    "type": "image/png",
    "etag": '"61175-cd3fkZCGdcMyAmPJ4IGoxvyXWtg"',
    "mtime": "2026-07-14T15:57:00.151Z",
    "size": 397685,
    "path": "../public/assets/model-s2-male1-BuGgDqm4.png"
  },
  "/assets/model-s2-kid-Zb19UdeQ.png": {
    "type": "image/png",
    "etag": '"945c1-ocKwgLjhVUuFs8WG0b9C22L8wFc"',
    "mtime": "2026-07-14T15:57:00.153Z",
    "size": 607681,
    "path": "../public/assets/model-s2-kid-Zb19UdeQ.png"
  },
  "/assets/model-male-2-D2UiDuxX.png": {
    "type": "image/png",
    "etag": '"ae992-/E6ooTZDO7b1LxE6/sN8WP+bJM0"',
    "mtime": "2026-07-14T15:57:00.153Z",
    "size": 715154,
    "path": "../public/assets/model-male-2-D2UiDuxX.png"
  },
  "/assets/model-s2-male2-BrTDs8Gy.png": {
    "type": "image/png",
    "etag": '"866e9-S1h6+qAcNL4wQBVNAQvMzlseZhc"',
    "mtime": "2026-07-14T15:57:00.154Z",
    "size": 550633,
    "path": "../public/assets/model-s2-male2-BrTDs8Gy.png"
  },
  "/assets/model-male-1-C-QSinrP.png": {
    "type": "image/png",
    "etag": '"bc99c-FlX9+6cLpOiWPR73wOYrINuJ2Us"',
    "mtime": "2026-07-14T15:57:00.154Z",
    "size": 772508,
    "path": "../public/assets/model-male-1-C-QSinrP.png"
  },
  "/assets/model-kid-BcXzc0og.png": {
    "type": "image/png",
    "etag": '"e69f6-BwUffu0l0rzO6ztiGfqg8znsgjQ"',
    "mtime": "2026-07-14T15:57:00.154Z",
    "size": 944630,
    "path": "../public/assets/model-kid-BcXzc0og.png"
  },
  "/assets/news._slug-CAm8guZn.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"875-eoYCxqY+moX35/T8j1ZHhZAJ1b8"',
    "mtime": "2026-07-14T15:57:00.153Z",
    "size": 2165,
    "path": "../public/assets/news._slug-CAm8guZn.js"
  },
  "/assets/news-B3canw4C.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"5f-eS1Tr3McbjxuaYibVt+9LnEueio"',
    "mtime": "2026-07-14T15:57:00.152Z",
    "size": 95,
    "path": "../public/assets/news-B3canw4C.js"
  },
  "/assets/product-denim-CDQDm1R3.jpg": {
    "type": "image/jpeg",
    "etag": '"19661-UnSNbbIQvztF0zDfgJg2YW1PC48"',
    "mtime": "2026-07-14T15:57:00.151Z",
    "size": 104033,
    "path": "../public/assets/product-denim-CDQDm1R3.jpg"
  },
  "/assets/model-s3-male2-uHDxJdAg.png": {
    "type": "image/png",
    "etag": '"707b1-dEa4n+xdSM1LfrC46LP3pHSl/as"',
    "mtime": "2026-07-14T15:57:00.152Z",
    "size": 460721,
    "path": "../public/assets/model-s3-male2-uHDxJdAg.png"
  },
  "/assets/news.index-DIvNhiT-.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"6a7-ubnUTDwCmpzuEtOYlYTnh3aO08U"',
    "mtime": "2026-07-14T15:57:00.153Z",
    "size": 1703,
    "path": "../public/assets/news.index-DIvNhiT-.js"
  },
  "/assets/product-kids-DgcnQG_p.jpg": {
    "type": "image/jpeg",
    "etag": '"cd10-7Pxnl359qXBT/5v6CwsWlhhvfn8"',
    "mtime": "2026-07-14T15:57:00.151Z",
    "size": 52496,
    "path": "../public/assets/product-kids-DgcnQG_p.jpg"
  },
  "/assets/product-knit-Cr2DhAld.jpg": {
    "type": "image/jpeg",
    "etag": '"57927-mW3XxE4Se+jvC/AuisjuGqT9qfI"',
    "mtime": "2026-07-14T15:57:00.151Z",
    "size": 358695,
    "path": "../public/assets/product-knit-Cr2DhAld.jpg"
  },
  "/assets/product-kids-CxfrayWT.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"c5-avO4aZV7IZsjPcqOy53u+LFyBLg"',
    "mtime": "2026-07-14T15:57:00.152Z",
    "size": 197,
    "path": "../public/assets/product-kids-CxfrayWT.js"
  },
  "/assets/product-woven-CUPOsHic.jpg": {
    "type": "image/jpeg",
    "etag": '"d5cb-Ud/kblLkHHEHfXFc9ktRJLJyKck"',
    "mtime": "2026-07-14T15:57:00.152Z",
    "size": 54731,
    "path": "../public/assets/product-woven-CUPOsHic.jpg"
  },
  "/assets/products.index-AJA6T0vP.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"ca0-7tyaAIpzIv3H6JNdQS1i2DWrLA4"',
    "mtime": "2026-07-14T15:57:00.152Z",
    "size": 3232,
    "path": "../public/assets/products.index-AJA6T0vP.js"
  },
  "/assets/products-B3canw4C.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"5f-eS1Tr3McbjxuaYibVt+9LnEueio"',
    "mtime": "2026-07-14T15:57:00.152Z",
    "size": 95,
    "path": "../public/assets/products-B3canw4C.js"
  },
  "/assets/services-BHZ8OdVT.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"ddb-kE5fSo+b83x/h2d0LuAp/5Aypos"',
    "mtime": "2026-07-14T15:57:00.152Z",
    "size": 3547,
    "path": "../public/assets/services-BHZ8OdVT.js"
  },
  "/assets/products._category-eJ2twLa5.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"723-BHhd6jBelxQnsmBcm1sXglNEwQI"',
    "mtime": "2026-07-14T15:57:00.152Z",
    "size": 1827,
    "path": "../public/assets/products._category-eJ2twLa5.js"
  },
  "/assets/shield-check-DHH27vdV.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"39b-C3UTJPkE4EvbAUnRN9sDCRtHPjY"',
    "mtime": "2026-07-14T15:57:00.152Z",
    "size": 923,
    "path": "../public/assets/shield-check-DHH27vdV.js"
  },
  "/assets/profile-CBr-N8fy.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"2cd0-5MfeGrhf8Vemj03zx2vnyuhK6og"',
    "mtime": "2026-07-14T15:57:00.152Z",
    "size": 11472,
    "path": "../public/assets/profile-CBr-N8fy.js"
  },
  "/assets/quality-Da0hWhni.jpg": {
    "type": "image/jpeg",
    "etag": '"14814-mQEH2Eygoyw9mQfwhlqLh/ukRcU"',
    "mtime": "2026-07-14T15:57:00.150Z",
    "size": 83988,
    "path": "../public/assets/quality-Da0hWhni.jpg"
  },
  "/assets/sourcing-BgwhvRNY.jpg": {
    "type": "image/jpeg",
    "etag": '"28464-IjoKLrHaHrBK9IBWd3dfZsqZmAw"',
    "mtime": "2026-07-14T15:57:00.150Z",
    "size": 164964,
    "path": "../public/assets/sourcing-BgwhvRNY.jpg"
  },
  "/assets/styles-BKmtNVNG.css": {
    "type": "text/css; charset=utf-8",
    "etag": '"1bbf8-oSnxn0TaDSntSPef1ZcBpQ9cuDg"',
    "mtime": "2026-07-14T15:57:00.152Z",
    "size": 113656,
    "path": "../public/assets/styles-BKmtNVNG.css"
  },
  "/assets/model-s3-kid-1KTPCKRP.png": {
    "type": "image/png",
    "etag": '"9396f-68kwpYeovYQSjRIWVGat4Vcw6AA"',
    "mtime": "2026-07-14T15:57:00.154Z",
    "size": 604527,
    "path": "../public/assets/model-s3-kid-1KTPCKRP.png"
  },
  "/assets/model-s3-male1-BJhwrFuc.png": {
    "type": "image/png",
    "etag": '"9fd7f-i8W7xgtgnX65ZBiULQXRSpHJOE0"',
    "mtime": "2026-07-14T15:57:00.153Z",
    "size": 654719,
    "path": "../public/assets/model-s3-male1-BJhwrFuc.png"
  },
  "/assets/x-B21rfPYk.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"5f4-ztTiy6FleZ5PTiUZxQrblBXzSWo"',
    "mtime": "2026-07-14T15:57:00.154Z",
    "size": 1524,
    "path": "../public/assets/x-B21rfPYk.js"
  }
};
function readAsset(id) {
  const serverDir = dirname(fileURLToPath(globalThis.__nitro_main__));
  return promises.readFile(resolve(serverDir, assets[id].path));
}
const publicAssetBases = {};
function isPublicAssetURL(id = "") {
  if (assets[id]) {
    return true;
  }
  for (const base in publicAssetBases) {
    if (id.startsWith(base)) {
      return true;
    }
  }
  return false;
}
function getAsset(id) {
  return assets[id];
}
const METHODS = /* @__PURE__ */ new Set(["HEAD", "GET"]);
const EncodingMap = {
  gzip: ".gz",
  br: ".br",
  zstd: ".zst"
};
const _esMaHO = defineHandler((event) => {
  if (event.req.method && !METHODS.has(event.req.method)) {
    return;
  }
  let id = decodePath(withLeadingSlash(withoutTrailingSlash(event.url.pathname)));
  let asset;
  const encodingHeader = event.req.headers.get("accept-encoding") || "";
  const encodings = [...encodingHeader.split(",").map((e) => EncodingMap[e.trim()]).filter(Boolean).sort(), ""];
  for (const encoding of encodings) {
    for (const _id of [id + encoding, joinURL(id, "index.html" + encoding)]) {
      const _asset = getAsset(_id);
      if (_asset) {
        asset = _asset;
        id = _id;
        break;
      }
    }
  }
  if (!asset) {
    if (isPublicAssetURL(id)) {
      event.res.headers.delete("Cache-Control");
      throw new HTTPError({ status: 404 });
    }
    return;
  }
  if (encodings.length > 1) {
    event.res.headers.append("Vary", "Accept-Encoding");
  }
  const ifNotMatch = event.req.headers.get("if-none-match") === asset.etag;
  if (ifNotMatch) {
    event.res.status = 304;
    event.res.statusText = "Not Modified";
    return "";
  }
  const ifModifiedSinceH = event.req.headers.get("if-modified-since");
  const mtimeDate = new Date(asset.mtime);
  if (ifModifiedSinceH && asset.mtime && new Date(ifModifiedSinceH) >= mtimeDate) {
    event.res.status = 304;
    event.res.statusText = "Not Modified";
    return "";
  }
  if (asset.type) {
    event.res.headers.set("Content-Type", asset.type);
  }
  if (asset.etag && !event.res.headers.has("ETag")) {
    event.res.headers.set("ETag", asset.etag);
  }
  if (asset.mtime && !event.res.headers.has("Last-Modified")) {
    event.res.headers.set("Last-Modified", mtimeDate.toUTCString());
  }
  if (asset.encoding && !event.res.headers.has("Content-Encoding")) {
    event.res.headers.set("Content-Encoding", asset.encoding);
  }
  if (asset.size > 0 && !event.res.headers.has("Content-Length")) {
    event.res.headers.set("Content-Length", asset.size.toString());
  }
  return readAsset(id);
});
const findRouteRules = /* @__PURE__ */ (() => {
  const $0 = [{ name: "headers", route: "/assets/**", handler: headers, options: { "cache-control": "public, max-age=31536000, immutable" } }];
  return (m, p) => {
    let r = [];
    if (p.charCodeAt(p.length - 1) === 47) p = p.slice(0, -1) || "/";
    let s = p.split("/"), l = s.length;
    if (l > 1) {
      if (s[1] === "assets") {
        r.unshift({ data: $0, params: { "_": s.slice(2).join("/") } });
      }
    }
    return r;
  };
})();
const _lazy_Jqd10v = defineLazyEventHandler(() => import("./_chunks/ssr-renderer.mjs"));
const findRoute = /* @__PURE__ */ (() => {
  const data = { route: "/**", handler: _lazy_Jqd10v };
  return ((_m, p) => {
    return { data, params: { "_": p.slice(1) } };
  });
})();
const globalMiddleware = [
  toEventHandler(_esMaHO)
].filter(Boolean);
const errorHandler$1 = (error, event) => {
  const res = defaultHandler(error, event);
  return new NodeResponse(typeof res.body === "string" ? res.body : JSON.stringify(res.body, null, 2), res);
};
function defaultHandler(error, event) {
  const unhandled = error.unhandled ?? !HTTPError.isError(error);
  const { status = 500, statusText = "" } = unhandled ? {} : error;
  if (status === 404) {
    const url = event.url || new URL(event.req.url);
    const baseURL = "/";
    if (/^\/[^/]/.test(baseURL) && !url.pathname.startsWith(baseURL)) {
      return {
        status: 302,
        headers: new Headers({ location: `${baseURL}${url.pathname.slice(1)}${url.search}` })
      };
    }
  }
  const headers2 = new Headers(unhandled ? {} : error.headers);
  headers2.set("content-type", "application/json; charset=utf-8");
  const jsonBody = unhandled ? {
    status,
    unhandled: true
  } : typeof error.toJSON === "function" ? error.toJSON() : {
    status,
    statusText,
    message: error.message
  };
  return {
    status,
    statusText,
    headers: headers2,
    body: {
      error: true,
      ...jsonBody
    }
  };
}
const errorHandlers = [errorHandler$1];
async function errorHandler(error, event) {
  for (const handler of errorHandlers) {
    try {
      const response = await handler(error, event, { defaultHandler });
      if (response) {
        return response;
      }
    } catch (error2) {
      console.error(error2);
    }
  }
}
function createNitroApp() {
  const captureError = (error, errorCtx) => {
    if (errorCtx?.event) {
      const errors = errorCtx.event.req.context?.nitro?.errors;
      if (errors) {
        errors.push({ error, context: errorCtx });
      }
    }
  };
  const h3App = createH3App({
    onError(error, event) {
      return errorHandler(error, event);
    }
  });
  let appHandler = (req) => {
    req.context ||= {};
    req.context.nitro = req.context.nitro || { errors: [] };
    return h3App.fetch(req);
  };
  return {
    fetch: appHandler,
    h3: h3App,
    hooks: void 0,
    captureError
  };
}
function createH3App(config) {
  const h3App = new H3Core(config);
  h3App["~findRoute"] = (event) => findRoute(event.req.method, event.url.pathname);
  h3App["~middleware"].push(...globalMiddleware);
  h3App["~getMiddleware"] = (event, route) => {
    const pathname = event.url.pathname;
    const method = event.req.method;
    const middleware = [];
    const routeRules = getRouteRules(method, pathname);
    event.context.routeRules = routeRules?.routeRules;
    if (routeRules?.routeRuleMiddleware.length) {
      middleware.push(...routeRules.routeRuleMiddleware);
    }
    middleware.push(...h3App["~middleware"]);
    if (route?.data?.middleware?.length) {
      middleware.push(...route.data.middleware);
    }
    return middleware;
  };
  return h3App;
}
const APP_ID = "default";
function useNitroApp() {
  let instance = useNitroApp._instance;
  if (instance) {
    return instance;
  }
  instance = useNitroApp._instance = createNitroApp();
  globalThis.__nitro__ = globalThis.__nitro__ || {};
  globalThis.__nitro__[APP_ID] = instance;
  return instance;
}
function getRouteRules(method, pathname) {
  const m = findRouteRules(method, pathname);
  if (!m?.length) {
    return { routeRuleMiddleware: [] };
  }
  const routeRules = {};
  for (const layer of m) {
    for (const rule of layer.data) {
      const currentRule = routeRules[rule.name];
      if (currentRule) {
        if (rule.options === false) {
          delete routeRules[rule.name];
          continue;
        }
        if (typeof currentRule.options === "object" && typeof rule.options === "object") {
          currentRule.options = {
            ...currentRule.options,
            ...rule.options
          };
        } else {
          currentRule.options = rule.options;
        }
        currentRule.route = rule.route;
        currentRule.params = {
          ...currentRule.params,
          ...layer.params
        };
      } else if (rule.options !== false) {
        routeRules[rule.name] = {
          ...rule,
          params: layer.params
        };
      }
    }
  }
  const middleware = [];
  const orderedRules = Object.values(routeRules).sort((a, b) => (a.handler?.order || 0) - (b.handler?.order || 0));
  for (const rule of orderedRules) {
    if (rule.options === false || !rule.handler) {
      continue;
    }
    middleware.push(rule.handler(rule));
  }
  return {
    routeRules,
    routeRuleMiddleware: middleware
  };
}
function _captureError(error, type) {
  console.error(`[${type}]`, error);
  useNitroApp().captureError?.(error, { tags: [type] });
}
function trapUnhandledErrors() {
  process.on("unhandledRejection", (error) => _captureError(error, "unhandledRejection"));
  process.on("uncaughtException", (error) => _captureError(error, "uncaughtException"));
}
const tracingSrvxPlugins = [];
const _parsedPort = Number.parseInt(process.env.NITRO_PORT ?? process.env.PORT ?? "");
const port = Number.isNaN(_parsedPort) ? 3e3 : _parsedPort;
const host = process.env.NITRO_HOST || process.env.HOST;
const cert = process.env.NITRO_SSL_CERT;
const key = process.env.NITRO_SSL_KEY;
const nitroApp = useNitroApp();
serve({
  port,
  hostname: host,
  tls: cert && key ? {
    cert,
    key
  } : void 0,
  fetch: nitroApp.fetch,
  plugins: [...tracingSrvxPlugins]
});
trapUnhandledErrors();
const nodeServer = {};
export {
  nodeServer as default
};
