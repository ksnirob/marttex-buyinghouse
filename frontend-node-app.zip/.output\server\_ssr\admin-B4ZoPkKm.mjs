import { r as reactExports, j as jsxRuntimeExports } from "../_libs/react.mjs";
import { f as CircleCheck, X, p as Menu, R as RefreshCw, n as LogOut, B as Boxes, T as Tags, h as Contact, v as Settings, H as Type, N as Newspaper, q as MessageSquareQuote, l as Images, I as ImagePlus, S as Save, D as Trash2, t as Plus, i as FilePlusCorner, c as ChevronDown, k as GripVertical } from "../_libs/lucide-react.mjs";
const API_URL = "https://api.marttex.net";
const tokenKey = "martxbd_admin_token";
function adminAssetUrl(value) {
  if (!value) return "";
  return /^https?:\/\//i.test(value) ? value : `${API_URL}${value.startsWith("/") ? "" : "/"}${value}`;
}
function AdminDashboard() {
  const [token, setToken] = reactExports.useState("");
  const [tab, setTab] = reactExports.useState("all-products");
  const [sidebarOpen, setSidebarOpen] = reactExports.useState(false);
  const [message, setMessage] = reactExports.useState("");
  const [loading, setLoading] = reactExports.useState(false);
  const [categories, setCategories] = reactExports.useState([]);
  const [products, setProducts] = reactExports.useState([]);
  const [settings, setSettings] = reactExports.useState({});
  const [blocks, setBlocks] = reactExports.useState([]);
  const isLoggedIn = Boolean(token);
  reactExports.useEffect(() => {
    setToken(window.localStorage.getItem(tokenKey) || "");
  }, []);
  async function api(path, options = {}) {
    const headers = new Headers(options.headers);
    if (!(options.body instanceof FormData)) headers.set("Content-Type", "application/json");
    if (token) headers.set("Authorization", `Bearer ${token}`);
    const response = await fetch(`${API_URL}${path}`, {
      ...options,
      headers
    });
    const result = await response.json().catch(() => ({}));
    if (!response.ok) {
      throw new Error(result.message || "Request failed.");
    }
    return result;
  }
  async function loadData() {
    setLoading(true);
    setMessage("");
    try {
      const [categoryRes, productRes, settingsRes, contentRes] = await Promise.all([api("/api/categories?includeInactive=true"), api("/api/products?includeInactive=true&limit=100"), api("/api/site-settings"), api("/api/content?includeInactive=true")]);
      setCategories(categoryRes.data || []);
      setProducts(productRes.data || []);
      setSettings(settingsRes.data || {});
      setBlocks(contentRes.data || []);
    } catch (error) {
      setMessage(error instanceof Error ? error.message : "Could not load dashboard data.");
    } finally {
      setLoading(false);
    }
  }
  reactExports.useEffect(() => {
    if (isLoggedIn) void loadData();
  }, [isLoggedIn]);
  reactExports.useEffect(() => {
    if (!message) return;
    const timer = window.setTimeout(() => setMessage(""), 3500);
    return () => window.clearTimeout(timer);
  }, [message]);
  function saveToken(nextToken) {
    window.localStorage.setItem(tokenKey, nextToken);
    setToken(nextToken);
  }
  function logout() {
    window.localStorage.removeItem(tokenKey);
    setToken("");
  }
  function selectTab(nextTab) {
    setTab(nextTab);
    setSidebarOpen(false);
  }
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("main", { className: "min-h-[calc(100vh+1px)] bg-secondary/40 text-foreground", children: [
    message && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "fixed right-5 top-5 z-[100] flex max-w-sm items-start gap-3 rounded-xl border border-emerald-200 bg-white px-4 py-3 text-sm text-emerald-950 shadow-xl", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(CircleCheck, { className: "mt-0.5 h-5 w-5 shrink-0 text-emerald-600" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "flex-1", children: message }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("button", { type: "button", onClick: () => setMessage(""), "aria-label": "Close notification", className: "text-emerald-800/60 hover:text-emerald-950", children: /* @__PURE__ */ jsxRuntimeExports.jsx(X, { className: "h-4 w-4" }) })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("header", { className: "border-b border-border bg-card", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "container-x flex items-start justify-between gap-3 py-5", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "min-w-0 flex-1", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "eyebrow", children: "Mart Tex" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("h1", { className: "mt-1 text-2xl font-semibold tracking-normal", children: "Admin Dashboard" })
      ] }),
      isLoggedIn && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex shrink-0 items-center gap-2", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("button", { className: "grid h-10 w-10 shrink-0 place-items-center rounded-full bg-primary text-primary-foreground shadow-sm transition hover:-translate-y-0.5 hover:shadow-md xl:hidden", onClick: () => setSidebarOpen(true), type: "button", "aria-label": "Open admin menu", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Menu, { className: "h-5 w-5" }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("button", { className: "btn-outline h-10 !w-10 !p-0 sm:h-11 sm:!w-[128px] sm:justify-center sm:!px-5 sm:!py-0", onClick: loadData, type: "button", "aria-label": "Refresh dashboard", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(RefreshCw, { className: "h-4 w-4" }),
          " ",
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "hidden sm:inline", children: "Refresh" })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("button", { className: "btn-outline hidden h-11 !w-[128px] justify-center !px-5 !py-0 xl:inline-flex", onClick: logout, type: "button", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(LogOut, { className: "h-4 w-4" }),
          " Logout"
        ] })
      ] })
    ] }) }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "container-x py-8", children: !isLoggedIn ? /* @__PURE__ */ jsxRuntimeExports.jsx(LoginPanel, { onToken: saveToken }) : /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid min-w-0 gap-6 xl:grid-cols-[250px_minmax(0,1fr)]", children: [
      sidebarOpen && /* @__PURE__ */ jsxRuntimeExports.jsx("button", { type: "button", "aria-label": "Close admin menu", onClick: () => setSidebarOpen(false), className: "fixed inset-0 z-[80] bg-primary/35 backdrop-blur-sm xl:hidden" }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("aside", { className: `fixed inset-y-0 left-0 z-[90] block h-full w-[min(320px,85vw)] overflow-y-auto border-r border-border bg-card p-4 shadow-2xl transition-transform duration-300 xl:sticky xl:top-6 xl:z-auto xl:h-fit xl:w-[250px] xl:self-start xl:translate-x-0 xl:overflow-visible xl:rounded-xl xl:border xl:p-3 xl:shadow-none ${sidebarOpen ? "translate-x-0" : "-translate-x-full"}`, children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mb-4 flex items-center justify-between border-b border-border pb-3 xl:hidden", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "eyebrow", children: "Mart Tex" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-1 font-semibold", children: "Admin menu" })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("button", { type: "button", onClick: () => setSidebarOpen(false), className: "grid h-10 w-10 place-items-center rounded-full border border-border", "aria-label": "Close menu", children: /* @__PURE__ */ jsxRuntimeExports.jsx(X, { className: "h-4 w-4" }) })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "col-span-full px-3 pb-2 pt-1 text-xs font-semibold uppercase tracking-wider text-muted-foreground", children: "Products" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(SidebarButton, { icon: Boxes, label: "All products", active: tab === "all-products", onClick: () => selectTab("all-products") }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(SidebarButton, { icon: Tags, label: "Categories", active: tab === "categories", onClick: () => selectTab("categories") }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "col-span-full my-2 border-t border-border xl:my-3" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "col-span-full px-3 pb-2 text-xs font-semibold uppercase tracking-wider text-muted-foreground", children: "Site options" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(SidebarButton, { icon: Menu, label: "Menu", active: tab === "menu", onClick: () => selectTab("menu") }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(SidebarButton, { icon: Contact, label: "Footer & contact", active: tab === "contact", onClick: () => selectTab("contact") }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(SidebarButton, { icon: Settings, label: "Logo & branding", active: tab === "site-options", onClick: () => selectTab("site-options") }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "col-span-full my-2 border-t border-border xl:my-3" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "col-span-full px-3 pb-2 text-xs font-semibold uppercase tracking-wider text-muted-foreground", children: "Content" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(SidebarButton, { icon: Type, label: "Pages", active: tab === "pages", onClick: () => selectTab("pages") }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(SidebarButton, { icon: Newspaper, label: "News", active: tab === "news", onClick: () => selectTab("news") }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(SidebarButton, { icon: MessageSquareQuote, label: "Testimonials", active: tab === "testimonials", onClick: () => selectTab("testimonials") }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(SidebarButton, { icon: Images, label: "Brand logos", active: tab === "brands", onClick: () => selectTab("brands") }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "mt-4 border-t border-border pt-4 xl:hidden", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("button", { type: "button", onClick: logout, className: "flex w-full items-center gap-3 rounded-lg px-3 py-2.5 text-left text-sm text-destructive transition hover:bg-destructive/10", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(LogOut, { className: "h-4 w-4" }),
          " Logout"
        ] }) })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "min-w-0", children: loading ? /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "rounded-lg border border-border bg-card p-6 text-sm text-muted-foreground", children: "Loading content..." }) : /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
        tab === "all-products" && /* @__PURE__ */ jsxRuntimeExports.jsx(ProductsPanel, { api, categories, reload: loadData, setMessage, view: "list" }),
        tab === "categories" && /* @__PURE__ */ jsxRuntimeExports.jsx(CategoriesPanel, { api, categories, reload: loadData, setMessage }),
        tab === "contact" && /* @__PURE__ */ jsxRuntimeExports.jsx(ContactPanel, { api, settings, setSettings, setMessage }),
        tab === "menu" && /* @__PURE__ */ jsxRuntimeExports.jsx(MenuPanel, { api, settings, setSettings, setMessage }),
        tab === "site-options" && /* @__PURE__ */ jsxRuntimeExports.jsx(SiteOptionsPanel, { api, settings, setSettings, setMessage }),
        tab === "pages" && /* @__PURE__ */ jsxRuntimeExports.jsx(PagesPanel, { api, blocks, reload: loadData, setMessage }),
        tab === "news" && /* @__PURE__ */ jsxRuntimeExports.jsx(ContentCollectionPanel, { kind: "news", blockKey: "site-news", api, blocks, reload: loadData, setMessage }),
        tab === "testimonials" && /* @__PURE__ */ jsxRuntimeExports.jsx(ContentCollectionPanel, { kind: "testimonials", blockKey: "home-testimonials", api, blocks, reload: loadData, setMessage }),
        tab === "brands" && /* @__PURE__ */ jsxRuntimeExports.jsx(ContentCollectionPanel, { kind: "brands", blockKey: "home-brands", api, blocks, reload: loadData, setMessage })
      ] }) })
    ] }) }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("footer", { className: "border-t border-border bg-card", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "container-x py-5 text-center text-xs text-muted-foreground", children: [
      "Developed by",
      " ",
      /* @__PURE__ */ jsxRuntimeExports.jsx("a", { href: "https://ksnirob.com", target: "_blank", rel: "noreferrer", className: "font-medium text-foreground transition hover:text-primary", children: "KS Nirob" })
    ] }) })
  ] });
}
function LoginPanel({
  onToken
}) {
  const [email, setEmail] = reactExports.useState("admin@example.com");
  const [password, setPassword] = reactExports.useState("change-me-now");
  const [message, setMessage] = reactExports.useState("");
  const [loading, setLoading] = reactExports.useState(false);
  async function login(event) {
    event.preventDefault();
    setMessage("");
    setLoading(true);
    try {
      const response = await fetch(`${API_URL}/api/auth/login`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          email,
          password
        })
      });
      const result = await response.json();
      if (!response.ok) {
        setMessage(result.message || "Login failed.");
        return;
      }
      onToken(result.token);
    } catch {
      setMessage("Could not reach the backend. Make sure http://127.0.0.1:4000 is running.");
    } finally {
      setLoading(false);
    }
  }
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("form", { onSubmit: login, className: "mx-auto max-w-md rounded-lg border border-border bg-card p-6 shadow-sm", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "text-xl font-semibold tracking-normal", children: "Login" }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-5 grid gap-4", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(Field, { label: "Email", value: email, onChange: setEmail, type: "email" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(Field, { label: "Password", value: password, onChange: setPassword, type: "password" }),
      message && /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm text-destructive", children: message }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("button", { className: "btn-primary", type: "submit", disabled: loading, children: loading ? "Logging in..." : "Login" })
    ] })
  ] });
}
function ProductsPanel({
  api,
  categories,
  reload,
  setMessage,
  view
}) {
  const emptyProduct = reactExports.useMemo(() => ({
    name: "",
    category: categories[0]?._id || "",
    summary: "",
    description: "",
    tagsText: "",
    imageUrl: "",
    isFeatured: false,
    isActive: true
  }), [categories]);
  const [form, setForm] = reactExports.useState(emptyProduct);
  reactExports.useEffect(() => setForm(emptyProduct), [emptyProduct]);
  async function saveProduct(event) {
    event.preventDefault();
    const editId = form._id;
    const body = {
      name: form.name,
      category: form.category,
      summary: form.summary,
      description: form.description,
      tags: form.tagsText.split(",").map((tag) => tag.trim()).filter(Boolean),
      images: form.imageUrl ? [{
        url: form.imageUrl,
        alt: form.name,
        sortOrder: 0
      }] : [],
      isFeatured: form.isFeatured,
      isActive: form.isActive
    };
    await api(editId ? `/api/products/${editId}` : "/api/products", {
      method: editId ? "PATCH" : "POST",
      body: JSON.stringify(body)
    });
    if (!editId && form.imageUrl) {
      const category = categories.find((item) => item._id === form.category);
      if (category) {
        const galleryImages = [...category.galleryImages || [], {
          url: form.imageUrl,
          alt: form.name,
          sortOrder: category.galleryImages?.length || 0
        }];
        await api(`/api/categories/${category._id}`, {
          method: "PATCH",
          body: JSON.stringify({
            galleryImages
          })
        });
      }
    }
    setMessage("Product saved.");
    setForm(emptyProduct);
    await reload();
  }
  async function uploadImage(file) {
    const body = new FormData();
    body.append("image", file);
    const result = await api("/api/uploads/image", {
      method: "POST",
      body
    });
    setForm((current) => ({
      ...current,
      imageUrl: `${API_URL}${result.data.url}`
    }));
    setMessage("Image uploaded. Save the product to keep it.");
  }
  async function uploadGalleryImages(category, files) {
    if (!files.length) return;
    setMessage(`Uploading ${files.length} image${files.length === 1 ? "" : "s"}...`);
    const uploadedImages = [];
    for (const file of files) {
      const body = new FormData();
      body.append("image", file);
      const uploaded = await api("/api/uploads/image", {
        method: "POST",
        body
      });
      uploadedImages.push({
        url: uploaded.data.url,
        alt: category.name,
        sortOrder: (category.galleryImages?.length || 0) + uploadedImages.length
      });
    }
    const galleryImages = [...category.galleryImages || [], ...uploadedImages];
    await api(`/api/categories/${category._id}`, {
      method: "PATCH",
      body: JSON.stringify({
        galleryImages
      })
    });
    setMessage(`${files.length} product image${files.length === 1 ? "" : "s"} added.`);
    await reload();
  }
  async function deleteGalleryImage(category, imageIndex) {
    const galleryImages = (category.galleryImages || []).filter((_, index) => index !== imageIndex).map((image, index) => ({
      ...image,
      sortOrder: index
    }));
    await api(`/api/categories/${category._id}`, {
      method: "PATCH",
      body: JSON.stringify({
        galleryImages
      })
    });
    setMessage("Product image deleted.");
    await reload();
  }
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("section", { className: "grid gap-6", children: [
    view === "form" && /* @__PURE__ */ jsxRuntimeExports.jsxs("form", { onSubmit: saveProduct, className: "rounded-lg border border-border bg-card p-5", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(PanelTitle, { title: "Product", action: "Add or edit product" }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-5 grid gap-4", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(Field, { label: "Name", value: form.name, onChange: (value) => setForm({
          ...form,
          name: value
        }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("label", { className: "grid gap-2 text-sm font-medium", children: [
          "Category",
          /* @__PURE__ */ jsxRuntimeExports.jsx("select", { value: form.category, onChange: (event) => setForm({
            ...form,
            category: event.target.value
          }), className: "rounded-lg border border-input bg-background px-3 py-2.5 text-sm outline-none focus:ring-2 focus:ring-ring", children: categories.map((category) => /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: category._id, children: category.name }, category._id)) })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(Field, { label: "Summary", value: form.summary, onChange: (value) => setForm({
          ...form,
          summary: value
        }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(TextArea, { label: "Description", value: form.description, onChange: (value) => setForm({
          ...form,
          description: value
        }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(Field, { label: "Tags", value: form.tagsText, onChange: (value) => setForm({
          ...form,
          tagsText: value
        }), placeholder: "knit, cotton, export" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(Field, { label: "Image URL", value: form.imageUrl, onChange: (value) => setForm({
          ...form,
          imageUrl: value
        }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("label", { className: "inline-flex cursor-pointer items-center gap-2 rounded-lg border border-dashed border-border bg-background px-4 py-3 text-sm", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(ImagePlus, { className: "h-4 w-4" }),
          "Upload image",
          /* @__PURE__ */ jsxRuntimeExports.jsx("input", { className: "hidden", type: "file", accept: "image/*", onChange: (event) => {
            const file = event.target.files?.[0];
            if (file) void uploadImage(file);
          } })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(Check, { label: "Featured", checked: form.isFeatured, onChange: (value) => setForm({
          ...form,
          isFeatured: value
        }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(Check, { label: "Active", checked: form.isActive, onChange: (value) => setForm({
          ...form,
          isActive: value
        }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex flex-wrap gap-2", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("button", { className: "btn-primary", type: "submit", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Save, { className: "h-4 w-4" }),
          " Save product"
        ] }) })
      ] })
    ] }),
    view === "list" && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "grid gap-5", children: categories.map((category) => /* @__PURE__ */ jsxRuntimeExports.jsxs("article", { className: "rounded-xl border border-border bg-card p-5", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mb-4 flex flex-wrap items-center justify-between gap-3", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "text-lg font-semibold", children: category.name }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "text-sm text-muted-foreground", children: [
            category.galleryImages?.length || 0,
            " product images"
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("label", { className: "btn-outline cursor-pointer px-4 py-2", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(ImagePlus, { className: "h-4 w-4" }),
          " Add image",
          /* @__PURE__ */ jsxRuntimeExports.jsx("input", { className: "hidden", type: "file", accept: "image/*", multiple: true, onChange: (event) => {
            const files = Array.from(event.target.files || []);
            if (files.length) void uploadGalleryImages(category, files);
            event.target.value = "";
          } })
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5", children: (category.galleryImages || []).map((image, imageIndex) => /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "group relative aspect-[4/3] overflow-hidden rounded-lg border border-border bg-secondary", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("img", { src: adminAssetUrl(image.url), alt: image.alt || category.name, className: "h-full w-full object-cover" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("button", { type: "button", "aria-label": "Delete product image", onClick: () => void deleteGalleryImage(category, imageIndex), className: "absolute right-2 top-2 grid h-8 w-8 place-items-center rounded-full bg-background/95 text-destructive opacity-0 shadow transition group-hover:opacity-100", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Trash2, { className: "h-4 w-4" }) })
      ] }, `${image.url}-${imageIndex}`)) })
    ] }, category._id)) })
  ] });
}
function CategoriesPanel({
  api,
  categories,
  reload,
  setMessage
}) {
  const [name, setName] = reactExports.useState("");
  const [description, setDescription] = reactExports.useState("");
  async function addCategory(event) {
    event.preventDefault();
    await api("/api/categories", {
      method: "POST",
      body: JSON.stringify({
        name,
        description,
        isActive: true
      })
    });
    setName("");
    setDescription("");
    setMessage("Category added.");
    await reload();
  }
  async function updateCategory(category, patch) {
    await api(`/api/categories/${category._id}`, {
      method: "PATCH",
      body: JSON.stringify(patch)
    });
    setMessage("Category updated.");
    await reload();
  }
  async function deleteCategory(category) {
    if (!window.confirm(`Delete "${category.name}"? This cannot be undone.`)) return;
    try {
      await api(`/api/categories/${category._id}`, {
        method: "DELETE"
      });
      setMessage("Category deleted.");
      await reload();
    } catch (error) {
      setMessage(error instanceof Error ? error.message : "Could not delete category.");
    }
  }
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("section", { className: "grid min-w-0 gap-6 xl:grid-cols-[340px_minmax(0,1fr)]", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("form", { onSubmit: addCategory, className: "rounded-lg border border-border bg-card p-5", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(PanelTitle, { title: "Category", action: "Add category" }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-5 grid gap-4", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(Field, { label: "Name", value: name, onChange: setName }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(TextArea, { label: "Description", value: description, onChange: setDescription }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("button", { className: "btn-primary", type: "submit", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Plus, { className: "h-4 w-4" }),
          " Add category"
        ] })
      ] })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "grid gap-3", children: categories.map((category) => /* @__PURE__ */ jsxRuntimeExports.jsx("article", { className: "rounded-xl border border-border bg-card p-4", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid gap-3 sm:grid-cols-2 xl:grid-cols-[1fr_1.4fr_auto_auto]", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(Field, { label: "Name", value: category.name, onChange: (value) => updateCategory(category, {
        name: value
      }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(Field, { label: "Description", value: category.description || "", onChange: (value) => updateCategory(category, {
        description: value
      }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(Check, { label: "Active", checked: category.isActive !== false, onChange: (value) => updateCategory(category, {
        isActive: value
      }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("button", { type: "button", onClick: () => void deleteCategory(category), className: "grid h-10 w-10 place-items-center self-center rounded-full border border-border text-destructive hover:border-destructive", "aria-label": `Delete ${category.name}`, children: /* @__PURE__ */ jsxRuntimeExports.jsx(Trash2, { className: "h-4 w-4" }) })
    ] }) }, category._id)) })
  ] });
}
function ContactPanel({
  api,
  settings,
  setSettings,
  setMessage
}) {
  const phonesText = settings.phones?.join(", ") || "";
  async function saveContact(event) {
    event.preventDefault();
    const result = await api("/api/site-settings", {
      method: "PATCH",
      body: JSON.stringify(settings)
    });
    setSettings(result.data);
    setMessage("Contact information saved.");
  }
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("form", { onSubmit: saveContact, className: "max-w-2xl rounded-lg border border-border bg-card p-4 sm:p-5", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx(PanelTitle, { title: "Contact information", action: "Shown on contact/footer areas" }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-5 grid gap-4 sm:grid-cols-2", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(Field, { label: "Company", value: settings.companyName || "", onChange: (value) => setSettings({
        ...settings,
        companyName: value
      }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(Field, { label: "Contact person name", value: settings.contactPerson || "", onChange: (value) => setSettings({
        ...settings,
        contactPerson: value
      }), placeholder: "Mukhlesur Rahman (Shakil)" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(Field, { label: "Email", value: settings.email || "", onChange: (value) => setSettings({
        ...settings,
        email: value
      }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(Field, { label: "Phones", value: phonesText, onChange: (value) => setSettings({
        ...settings,
        phones: value.split(",").map((phone) => phone.trim()).filter(Boolean)
      }), placeholder: "+880..., +880..." }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(Field, { label: "WhatsApp", value: settings.whatsapp || "", onChange: (value) => setSettings({
        ...settings,
        whatsapp: value
      }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(Field, { label: "Working hours", value: settings.workingHours || "", onChange: (value) => setSettings({
        ...settings,
        workingHours: value
      }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "sm:col-span-2", children: /* @__PURE__ */ jsxRuntimeExports.jsx(TextArea, { label: "Address", value: settings.address || "", onChange: (value) => setSettings({
        ...settings,
        address: value
      }) }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("button", { className: "btn-primary sm:col-span-2", type: "submit", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(Save, { className: "h-4 w-4" }),
        " Save contact"
      ] })
    ] })
  ] });
}
const editablePages = [{
  key: "page-home",
  label: "Home"
}, {
  key: "page-about-header",
  label: "About"
}, {
  key: "page-profile-header",
  label: "Profile"
}, {
  key: "page-products-header",
  label: "Products"
}, {
  key: "page-services-header",
  label: "Services"
}, {
  key: "page-gallery-header",
  label: "Gallery"
}, {
  key: "page-news-header",
  label: "News"
}, {
  key: "page-contact-header",
  label: "Contact"
}];
function PagesPanel({
  api,
  blocks,
  reload,
  setMessage
}) {
  const [selectedKey, setSelectedKey] = reactExports.useState(editablePages[0].key);
  const selected = blocks.find((block) => block.key === selectedKey) || {
    key: selectedKey,
    isActive: true
  };
  const [draft, setDraft] = reactExports.useState(selected);
  const [expandedSlide, setExpandedSlide] = reactExports.useState(0);
  const isHome = selectedKey === "page-home";
  const isGallery = selectedKey === "page-gallery-header";
  const slides = draft.items || [];
  const galleryImages = draft.items || [];
  reactExports.useEffect(() => setDraft(selected), [selectedKey, blocks]);
  async function uploadThumbnail(file) {
    const body = new FormData();
    body.append("image", file);
    const result = await api("/api/uploads/image", {
      method: "POST",
      body
    });
    setDraft((current) => ({
      ...current,
      thumbnail: result.data.url
    }));
    setMessage("SEO thumbnail uploaded. Save the page to publish it.");
  }
  function updateSlide(index, patch) {
    setDraft({
      ...draft,
      items: slides.map((slide, slideIndex) => slideIndex === index ? {
        ...slide,
        ...patch
      } : slide)
    });
  }
  async function uploadSlideImages(index, files) {
    const uploadedUrls = [];
    for (const file of files.slice(0, Math.max(3 - slides[index].images.length, 0))) {
      const body = new FormData();
      body.append("image", file);
      const result = await api("/api/uploads/image", {
        method: "POST",
        body
      });
      uploadedUrls.push(result.data.url);
    }
    updateSlide(index, {
      images: [...slides[index].images, ...uploadedUrls].slice(0, 3)
    });
    setMessage("Slider images uploaded. Save the page to publish them.");
  }
  async function uploadPageGalleryImages(files) {
    const uploaded = [];
    for (const file of files) {
      const body = new FormData();
      body.append("image", file);
      const result = await api("/api/uploads/image", {
        method: "POST",
        body
      });
      uploaded.push({
        url: result.data.url,
        alt: file.name.replace(/\.[^.]+$/, "")
      });
    }
    setDraft({
      ...draft,
      items: [...galleryImages, ...uploaded]
    });
    setMessage(`${uploaded.length} gallery image${uploaded.length === 1 ? "" : "s"} uploaded. Save the page to publish.`);
  }
  async function savePage(event) {
    event.preventDefault();
    await api(`/api/content/${draft.key}`, {
      method: "PUT",
      body: JSON.stringify({
        title: draft.title || "",
        body: draft.body || "",
        seoTitle: draft.seoTitle || "",
        seoDescription: draft.seoDescription || "",
        thumbnail: draft.thumbnail || "",
        items: draft.items || [],
        isActive: draft.isActive !== false
      })
    });
    setMessage("Page heading and description saved.");
    await reload();
  }
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("section", { className: "grid gap-6 lg:grid-cols-[280px_1fr]", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rounded-lg border border-border bg-card p-4", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(PanelTitle, { title: "Pages", action: "Choose a page" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "mt-4 grid gap-2", children: editablePages.map((page) => /* @__PURE__ */ jsxRuntimeExports.jsx("button", { onClick: () => setSelectedKey(page.key), className: `rounded-lg border px-3 py-2 text-left text-sm ${selectedKey === page.key ? "border-primary bg-primary text-primary-foreground" : "border-border bg-background"}`, type: "button", children: page.label }, page.key)) })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("form", { onSubmit: savePage, className: "rounded-lg border border-border bg-card p-5", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(PanelTitle, { title: `${editablePages.find((page) => page.key === selectedKey)?.label || "Page"} header`, action: "Top heading and description" }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-5 grid gap-4", children: [
        isHome ? /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid gap-5", children: [
          slides.map((slide, slideIndex) => /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rounded-xl border border-border bg-background p-4", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mb-4 flex items-center justify-between gap-3", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("button", { type: "button", onClick: () => setExpandedSlide((current) => current === slideIndex ? null : slideIndex), className: "flex flex-1 items-center justify-between gap-3 text-left", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "block font-semibold", children: [
                    "Slide ",
                    slideIndex + 1
                  ] }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "block text-xs text-muted-foreground", children: slide.word || "Untitled slide" })
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsx(ChevronDown, { className: `h-5 w-5 transition-transform ${expandedSlide === slideIndex ? "rotate-180" : ""}` })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("button", { type: "button", className: "btn-outline px-3 py-2 text-destructive", onClick: () => setDraft({
                ...draft,
                items: slides.filter((_, index) => index !== slideIndex)
              }), children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(Trash2, { className: "h-4 w-4" }),
                " Remove"
              ] })
            ] }),
            expandedSlide === slideIndex && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid gap-4 border-t border-border pt-4", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Field, { label: "Large word", value: slide.word, onChange: (value) => updateSlide(slideIndex, {
                word: value
              }), placeholder: "CRAFT" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(Field, { label: "Eyebrow", value: slide.eyebrow, onChange: (value) => updateSlide(slideIndex, {
                eyebrow: value
              }) }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(TextArea, { label: "Description", value: slide.description, onChange: (value) => updateSlide(slideIndex, {
                description: value
              }) }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mb-2 text-sm font-medium", children: "Model images (maximum 3)" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "grid grid-cols-3 gap-3", children: slide.images.map((image, imageIndex) => /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "group relative aspect-[3/4] overflow-hidden rounded-lg border border-border bg-secondary", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("img", { src: adminAssetUrl(image), alt: "", className: "h-full w-full object-contain" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("button", { type: "button", onClick: () => updateSlide(slideIndex, {
                    images: slide.images.filter((_, index) => index !== imageIndex)
                  }), className: "absolute right-2 top-2 grid h-8 w-8 place-items-center rounded-full bg-white text-destructive shadow", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Trash2, { className: "h-4 w-4" }) })
                ] }, `${image}-${imageIndex}`)) })
              ] }),
              slide.images.length < 3 && /* @__PURE__ */ jsxRuntimeExports.jsxs("label", { className: "btn-outline w-fit cursor-pointer", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(ImagePlus, { className: "h-4 w-4" }),
                " Add images",
                /* @__PURE__ */ jsxRuntimeExports.jsx("input", { className: "hidden", type: "file", accept: "image/*", multiple: true, onChange: (event) => {
                  const files = Array.from(event.target.files || []);
                  if (files.length) void uploadSlideImages(slideIndex, files);
                  event.target.value = "";
                } })
              ] })
            ] })
          ] }, slideIndex)),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("button", { type: "button", className: "btn-outline w-fit", onClick: () => {
            setDraft({
              ...draft,
              items: [...slides, {
                word: "NEW",
                eyebrow: "New collection",
                description: "",
                images: []
              }]
            });
            setExpandedSlide(slides.length);
          }, children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Plus, { className: "h-4 w-4" }),
            " Add slide"
          ] })
        ] }) : /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Field, { label: "Top heading", value: draft.title || "", onChange: (value) => setDraft({
            ...draft,
            title: value
          }) }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(TextArea, { label: "Description", value: draft.body || "", onChange: (value) => setDraft({
            ...draft,
            body: value
          }) }),
          isGallery && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid gap-4 rounded-xl border border-border bg-background p-4", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-wrap items-center justify-between gap-3", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "font-semibold", children: "Gallery images" }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "text-xs text-muted-foreground", children: [
                  galleryImages.length,
                  " images"
                ] })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("label", { className: "btn-outline cursor-pointer", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(ImagePlus, { className: "h-4 w-4" }),
                " Add images",
                /* @__PURE__ */ jsxRuntimeExports.jsx("input", { className: "hidden", type: "file", accept: "image/*", multiple: true, onChange: (event) => {
                  const files = Array.from(event.target.files || []);
                  if (files.length) void uploadPageGalleryImages(files);
                  event.target.value = "";
                } })
              ] })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "grid grid-cols-2 gap-3 sm:grid-cols-3", children: galleryImages.map((image, imageIndex) => /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative overflow-hidden rounded-lg border border-border", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("img", { src: adminAssetUrl(image.url), alt: image.alt, className: "aspect-[4/3] w-full object-cover" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("button", { type: "button", onClick: () => setDraft({
                ...draft,
                items: galleryImages.filter((_, index) => index !== imageIndex)
              }), className: "absolute right-2 top-2 grid h-8 w-8 place-items-center rounded-full bg-white text-destructive shadow", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Trash2, { className: "h-4 w-4" }) }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("input", { value: image.alt, onChange: (event) => setDraft({
                ...draft,
                items: galleryImages.map((item, index) => index === imageIndex ? {
                  ...item,
                  alt: event.target.value
                } : item)
              }), className: "w-full border-t border-border bg-white px-2 py-2 text-xs", placeholder: "Image alt text" })
            ] }, `${image.url}-${imageIndex}`)) })
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "my-1 border-t border-border" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(PanelTitle, { title: "SEO settings", action: "Search and social sharing" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(Field, { label: "SEO title", value: draft.seoTitle || "", onChange: (value) => setDraft({
          ...draft,
          seoTitle: value
        }), placeholder: "Page title shown in search results" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(TextArea, { label: "Meta description", value: draft.seoDescription || "", onChange: (value) => setDraft({
          ...draft,
          seoDescription: value
        }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(Field, { label: "Thumbnail URL", value: draft.thumbnail || "", onChange: (value) => setDraft({
          ...draft,
          thumbnail: value
        }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("label", { className: "inline-flex w-fit cursor-pointer items-center gap-2 rounded-lg border border-dashed border-border bg-background px-4 py-3 text-sm", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(ImagePlus, { className: "h-4 w-4" }),
          " Upload thumbnail",
          /* @__PURE__ */ jsxRuntimeExports.jsx("input", { className: "hidden", type: "file", accept: "image/*", onChange: (event) => {
            const file = event.target.files?.[0];
            if (file) void uploadThumbnail(file);
          } })
        ] }),
        draft.thumbnail && /* @__PURE__ */ jsxRuntimeExports.jsx("img", { src: adminAssetUrl(draft.thumbnail), alt: "SEO thumbnail preview", className: "aspect-[1.91/1] w-full max-w-md rounded-lg border border-border object-cover" }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("button", { className: "btn-primary", type: "submit", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Save, { className: "h-4 w-4" }),
          " Save page"
        ] })
      ] })
    ] })
  ] });
}
function ContentCollectionPanel({
  kind,
  blockKey,
  api,
  blocks,
  reload,
  setMessage
}) {
  const source = blocks.find((block) => block.key === blockKey);
  const [items, setItems] = reactExports.useState(source?.items || []);
  const [draggedIndex, setDraggedIndex] = reactExports.useState(null);
  const [expandedItem, setExpandedItem] = reactExports.useState(null);
  reactExports.useEffect(() => {
    setItems(source?.items || []);
  }, [source]);
  const labels = {
    news: "News",
    testimonials: "Testimonials",
    brands: "Brand logos"
  };
  function addItem() {
    const item = kind === "news" ? {
      title: "New article",
      slug: `article-${Date.now()}`,
      tag: "News",
      date: "",
      lead: "",
      body: "",
      image: ""
    } : kind === "testimonials" ? {
      name: "New client",
      role: "",
      initials: "",
      quote: ""
    } : {
      name: "Brand",
      image: ""
    };
    setExpandedItem(0);
    setItems((current) => [item, ...current]);
  }
  function updateItem(index, patch) {
    setItems((current) => current.map((item, itemIndex) => itemIndex === index ? {
      ...item,
      ...patch
    } : item));
  }
  async function uploadItemImage(index, file) {
    const body = new FormData();
    body.append("image", file);
    const result = await api("/api/uploads/image", {
      method: "POST",
      body
    });
    updateItem(index, {
      image: result.data.url
    });
    setMessage("Image uploaded. Save changes to publish it.");
  }
  async function uploadBrandLogos(files) {
    const uploaded = [];
    setMessage(`Uploading ${files.length} logo${files.length === 1 ? "" : "s"}...`);
    for (const file of files) {
      const body = new FormData();
      body.append("image", file);
      const result = await api("/api/uploads/image", {
        method: "POST",
        body
      });
      uploaded.push({
        name: file.name.replace(/\.[^.]+$/, "").replace(/[-_]+/g, " "),
        image: result.data.url
      });
    }
    setItems((current) => [...current, ...uploaded]);
    setMessage(`${uploaded.length} logo${uploaded.length === 1 ? "" : "s"} uploaded. Save changes to publish.`);
  }
  function moveItem(from, to) {
    if (from === to) return;
    setItems((current) => {
      const next = [...current];
      const [moved] = next.splice(from, 1);
      next.splice(to, 0, moved);
      return next;
    });
  }
  async function saveItems() {
    await api(`/api/content/${blockKey}`, {
      method: "PUT",
      body: JSON.stringify({
        items,
        isActive: true
      })
    });
    setMessage(`${labels[kind]} saved.`);
    await reload();
  }
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("section", { className: "max-w-5xl rounded-xl border border-border bg-card p-4 sm:p-5", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-wrap items-center justify-between gap-3", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(PanelTitle, { title: labels[kind] }),
      kind === "brands" ? /* @__PURE__ */ jsxRuntimeExports.jsxs("label", { className: "btn-outline cursor-pointer", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(ImagePlus, { className: "h-4 w-4" }),
        " Add logos",
        /* @__PURE__ */ jsxRuntimeExports.jsx("input", { className: "hidden", type: "file", accept: "image/*,.svg", multiple: true, onChange: (event) => {
          const files = Array.from(event.target.files || []);
          if (files.length) void uploadBrandLogos(files);
          event.target.value = "";
        } })
      ] }) : /* @__PURE__ */ jsxRuntimeExports.jsxs("button", { type: "button", className: "btn-outline", onClick: addItem, children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(Plus, { className: "h-4 w-4" }),
        " Add"
      ] })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-5 grid gap-4", children: [
      kind === "brands" && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-4", children: items.map((item, index) => /* @__PURE__ */ jsxRuntimeExports.jsx("div", { draggable: true, onDragStart: () => setDraggedIndex(index), onDragOver: (event) => event.preventDefault(), onDrop: () => {
        if (draggedIndex !== null) moveItem(draggedIndex, index);
        setDraggedIndex(null);
      }, onDragEnd: () => setDraggedIndex(null), className: `group relative rounded-xl border bg-background p-3 transition ${draggedIndex === index ? "border-primary opacity-50" : "border-border"}`, children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative grid aspect-[4/3] place-items-center overflow-hidden rounded-lg border border-border bg-white p-3", children: [
        item.image ? /* @__PURE__ */ jsxRuntimeExports.jsx("img", { src: adminAssetUrl(item.image), alt: "Brand logo", className: "max-h-full max-w-full object-contain" }) : /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-xs text-muted-foreground", children: "No logo" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "absolute left-2 top-2 grid h-8 w-8 cursor-grab place-items-center rounded-full bg-white/95 text-muted-foreground shadow", children: /* @__PURE__ */ jsxRuntimeExports.jsx(GripVertical, { className: "h-4 w-4" }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("button", { type: "button", "aria-label": "Delete logo", onClick: () => setItems((current) => current.filter((_, itemIndex) => itemIndex !== index)), className: "absolute right-2 top-2 grid h-8 w-8 place-items-center rounded-full bg-white/95 text-destructive shadow", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Trash2, { className: "h-4 w-4" }) })
      ] }) }, `${item.image}-${index}`)) }),
      kind !== "brands" && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: kind === "news" || kind === "testimonials" ? "grid gap-4 md:grid-cols-2" : "grid gap-4", children: items.map((item, index) => {
        if (kind === "news" && expandedItem !== null && expandedItem !== index) return null;
        return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: `overflow-hidden rounded-xl border border-border bg-background ${(kind === "news" || kind === "testimonials") && expandedItem === index ? "md:col-span-2" : ""}`, children: [
          kind === "news" && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: `grid gap-4 p-4 ${expandedItem === index ? "sm:grid-cols-[180px_1fr]" : ""}`, children: [
            item.image && /* @__PURE__ */ jsxRuntimeExports.jsx("img", { src: adminAssetUrl(item.image), alt: "", className: `w-full rounded-lg border border-border object-cover ${expandedItem === index ? "aspect-[4/3]" : "aspect-[16/8]"}` }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex min-w-0 flex-col", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "min-w-0", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "text-xs uppercase tracking-wider text-muted-foreground", children: [
                    item.tag || "News",
                    " · ",
                    item.date || "No date"
                  ] }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "mt-2 line-clamp-2 font-display text-xl text-primary", children: item.title || "Untitled article" })
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("button", { type: "button", onClick: () => setExpandedItem((current) => current === index ? null : index), className: "btn-outline !w-auto self-start px-4 py-2", children: expandedItem === index ? "Close" : "Edit" })
              ] }),
              expandedItem !== index && item.lead && /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-3 line-clamp-2 text-sm text-muted-foreground", children: item.lead })
            ] })
          ] }),
          kind === "testimonials" && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-col gap-4 p-4 sm:flex-row", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "grid h-12 w-12 shrink-0 place-items-center rounded-full bg-primary/10 font-display text-sm text-primary", children: item.initials || "—" }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "min-w-0 flex-1", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "font-semibold", children: item.name || "Unnamed client" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-muted-foreground", children: item.role || "No role" })
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("button", { type: "button", onClick: () => setExpandedItem((current) => current === index ? null : index), className: "btn-outline !w-auto self-start px-4 py-2", children: expandedItem === index ? "Close" : "Edit" })
              ] }),
              expandedItem !== index && /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "mt-3 line-clamp-3 text-sm italic text-foreground/75", children: [
                "“",
                item.quote || "No testimonial text",
                "”"
              ] })
            ] })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: `flex justify-end px-4 ${kind === "news" || kind === "testimonials" ? "pb-4" : "pt-4"}`, children: /* @__PURE__ */ jsxRuntimeExports.jsx("button", { type: "button", className: "grid h-9 w-9 place-items-center rounded-full border border-border text-destructive", onClick: () => setItems((current) => current.filter((_, itemIndex) => itemIndex !== index)), children: /* @__PURE__ */ jsxRuntimeExports.jsx(Trash2, { className: "h-4 w-4" }) }) }),
          (kind !== "news" && kind !== "testimonials" || expandedItem === index) && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid gap-4 border-t border-border p-4 sm:grid-cols-2", children: [
            kind === "news" && /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Field, { label: "Title", value: item.title || "", onChange: (value) => updateItem(index, {
                title: value
              }) }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(Field, { label: "Slug", value: item.slug || "", onChange: (value) => updateItem(index, {
                slug: value
              }) }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(Field, { label: "Category", value: item.tag || "", onChange: (value) => updateItem(index, {
                tag: value
              }) }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(Field, { label: "Date", value: item.date || "", onChange: (value) => updateItem(index, {
                date: value
              }) }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "sm:col-span-2", children: /* @__PURE__ */ jsxRuntimeExports.jsx(TextArea, { label: "Summary", value: item.lead || "", onChange: (value) => updateItem(index, {
                lead: value
              }) }) }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "sm:col-span-2", children: /* @__PURE__ */ jsxRuntimeExports.jsx(TextArea, { label: "Article body (separate paragraphs with a blank line)", value: item.body || "", onChange: (value) => updateItem(index, {
                body: value
              }) }) })
            ] }),
            kind === "testimonials" && /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Field, { label: "Name", value: item.name || "", onChange: (value) => updateItem(index, {
                name: value
              }) }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(Field, { label: "Role / company", value: item.role || "", onChange: (value) => updateItem(index, {
                role: value
              }) }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(Field, { label: "Initials", value: item.initials || "", onChange: (value) => updateItem(index, {
                initials: value
              }) }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "sm:col-span-2", children: /* @__PURE__ */ jsxRuntimeExports.jsx(TextArea, { label: "Quote", value: item.quote || "", onChange: (value) => updateItem(index, {
                quote: value
              }) }) })
            ] }),
            kind !== "testimonials" && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: kind === "news" ? "sm:col-span-2" : "", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Field, { label: "Image URL", value: item.image || "", onChange: (value) => updateItem(index, {
                image: value
              }) }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("label", { className: "btn-outline mt-3 w-fit cursor-pointer", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(ImagePlus, { className: "h-4 w-4" }),
                " Upload image",
                /* @__PURE__ */ jsxRuntimeExports.jsx("input", { className: "hidden", type: "file", accept: "image/*", onChange: (event) => {
                  const file = event.target.files?.[0];
                  if (file) void uploadItemImage(index, file);
                } })
              ] }),
              item.image && /* @__PURE__ */ jsxRuntimeExports.jsx("img", { src: adminAssetUrl(item.image), alt: "", className: "mt-3 h-24 max-w-full rounded-lg border border-border object-contain" })
            ] })
          ] })
        ] }, index);
      }) })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("button", { type: "button", className: "btn-primary mt-5", onClick: saveItems, children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(Save, { className: "h-4 w-4" }),
      " Save changes"
    ] })
  ] });
}
function MenuPanel({
  api,
  settings,
  setSettings,
  setMessage
}) {
  const items = settings.menuItems || [];
  function updateItem(index, patch) {
    setSettings({
      ...settings,
      menuItems: items.map((item, itemIndex) => itemIndex === index ? {
        ...item,
        ...patch
      } : item)
    });
  }
  async function saveMenu() {
    const result = await api("/api/site-settings", {
      method: "PATCH",
      body: JSON.stringify({
        menuItems: items
      })
    });
    setSettings(result.data);
    setMessage("Website menu saved.");
  }
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("section", { className: "max-w-4xl rounded-xl border border-border bg-card p-5", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx(PanelTitle, { title: "Website menu", action: "Header and footer navigation" }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-5 grid gap-3", children: [
      items.map((item, index) => /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid gap-3 rounded-lg border border-border bg-background p-4 md:grid-cols-[1fr_1.4fr_auto_auto]", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(Field, { label: "Label", value: item.label, onChange: (value) => updateItem(index, {
          label: value
        }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(Field, { label: "Path", value: item.path, onChange: (value) => updateItem(index, {
          path: value
        }), placeholder: "/about" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(Check, { label: "Visible", checked: item.isActive !== false, onChange: (value) => updateItem(index, {
          isActive: value
        }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("button", { type: "button", className: "btn-outline self-center px-3 py-2.5", onClick: () => setSettings({
          ...settings,
          menuItems: items.filter((_, itemIndex) => itemIndex !== index)
        }), children: /* @__PURE__ */ jsxRuntimeExports.jsx(Trash2, { className: "h-4 w-4" }) })
      ] }, `${item.path}-${index}`)),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("button", { type: "button", className: "btn-outline w-fit", onClick: () => setSettings({
        ...settings,
        menuItems: [...items, {
          label: "New link",
          path: "/",
          isActive: true
        }]
      }), children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(FilePlusCorner, { className: "h-4 w-4" }),
        " Add menu item"
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("button", { type: "button", className: "btn-primary w-fit", onClick: saveMenu, children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(Save, { className: "h-4 w-4" }),
        " Save menu"
      ] })
    ] })
  ] });
}
function SiteOptionsPanel({
  api,
  settings,
  setSettings,
  setMessage
}) {
  async function uploadLogo(file) {
    const body = new FormData();
    body.append("image", file);
    const result = await api("/api/uploads/image", {
      method: "POST",
      body
    });
    setSettings({
      ...settings,
      logoUrl: result.data.url
    });
    setMessage("Logo uploaded. Save branding to publish it.");
  }
  async function uploadFavicon(file) {
    const body = new FormData();
    body.append("image", file);
    const result = await api("/api/uploads/image", {
      method: "POST",
      body
    });
    setSettings({
      ...settings,
      faviconUrl: result.data.url
    });
    setMessage("Favicon uploaded. Save branding to publish it.");
  }
  async function saveOptions(event) {
    event.preventDefault();
    const result = await api("/api/site-settings", {
      method: "PATCH",
      body: JSON.stringify({
        companyName: settings.companyName || "",
        logoUrl: settings.logoUrl || "",
        faviconUrl: settings.faviconUrl || "",
        footerText: settings.footerText || "",
        copyrightText: settings.copyrightText || ""
      })
    });
    setSettings(result.data);
    setMessage("Branding options saved.");
  }
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("form", { onSubmit: saveOptions, className: "max-w-2xl rounded-xl border border-border bg-card p-4 sm:p-5", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx(PanelTitle, { title: "Logo and branding", action: "Used across header and footer" }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-5 grid gap-4", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(Field, { label: "Company name", value: settings.companyName || "", onChange: (value) => setSettings({
        ...settings,
        companyName: value
      }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(Field, { label: "Logo URL", value: settings.logoUrl || "", onChange: (value) => setSettings({
        ...settings,
        logoUrl: value
      }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("label", { className: "inline-flex w-fit cursor-pointer items-center gap-2 rounded-lg border border-dashed border-border bg-background px-4 py-3 text-sm", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(ImagePlus, { className: "h-4 w-4" }),
        " Upload logo",
        /* @__PURE__ */ jsxRuntimeExports.jsx("input", { className: "hidden", type: "file", accept: "image/*", onChange: (event) => {
          const file = event.target.files?.[0];
          if (file) void uploadLogo(file);
        } })
      ] }),
      settings.logoUrl && /* @__PURE__ */ jsxRuntimeExports.jsx("img", { src: settings.logoUrl.startsWith("http") ? settings.logoUrl : `${API_URL}${settings.logoUrl}`, alt: "Logo preview", className: "h-20 w-auto max-w-xs rounded-lg border border-border bg-background p-3 object-contain" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(Field, { label: "Favicon URL", value: settings.faviconUrl || "", onChange: (value) => setSettings({
        ...settings,
        faviconUrl: value
      }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("label", { className: "inline-flex w-fit cursor-pointer items-center gap-2 rounded-lg border border-dashed border-border bg-background px-4 py-3 text-sm", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(ImagePlus, { className: "h-4 w-4" }),
        " Upload favicon",
        /* @__PURE__ */ jsxRuntimeExports.jsx("input", { className: "hidden", type: "file", accept: "image/*", onChange: (event) => {
          const file = event.target.files?.[0];
          if (file) void uploadFavicon(file);
        } })
      ] }),
      settings.faviconUrl && /* @__PURE__ */ jsxRuntimeExports.jsx("img", { src: settings.faviconUrl.startsWith("http") ? settings.faviconUrl : `${API_URL}${settings.faviconUrl}`, alt: "Favicon preview", className: "h-12 w-12 rounded-lg border border-border bg-background p-2 object-contain" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(TextArea, { label: "Footer description", value: settings.footerText || "", onChange: (value) => setSettings({
        ...settings,
        footerText: value
      }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(Field, { label: "Copyright text", value: settings.copyrightText || "", onChange: (value) => setSettings({
        ...settings,
        copyrightText: value
      }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("button", { className: "btn-primary w-fit", type: "submit", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(Save, { className: "h-4 w-4" }),
        " Save branding"
      ] })
    ] })
  ] });
}
function SidebarButton({
  icon: Icon,
  label,
  active,
  onClick
}) {
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("button", { type: "button", onClick, className: `mb-1 flex w-full items-center gap-3 rounded-lg px-3 py-2.5 text-left text-sm transition ${active ? "bg-primary text-primary-foreground" : "text-foreground/75 hover:bg-secondary hover:text-primary"}`, children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx(Icon, { className: "h-4 w-4" }),
    " ",
    label
  ] });
}
function PanelTitle({
  title,
  action
}) {
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
    action && /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "eyebrow", children: action }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: action ? "mt-1 text-xl font-semibold tracking-normal" : "text-xl font-semibold tracking-normal", children: title })
  ] });
}
function Field({
  label,
  value,
  onChange,
  type = "text",
  placeholder
}) {
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("label", { className: "grid gap-2 text-sm font-medium", children: [
    label,
    /* @__PURE__ */ jsxRuntimeExports.jsx("input", { value, onChange: (event) => onChange(event.target.value), type, placeholder, className: "rounded-lg border border-input bg-background px-3 py-2.5 text-sm outline-none focus:ring-2 focus:ring-ring" })
  ] });
}
function TextArea({
  label,
  value,
  onChange
}) {
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("label", { className: "grid gap-2 text-sm font-medium", children: [
    label,
    /* @__PURE__ */ jsxRuntimeExports.jsx("textarea", { value, onChange: (event) => onChange(event.target.value), rows: 4, className: "rounded-lg border border-input bg-background px-3 py-2.5 text-sm outline-none focus:ring-2 focus:ring-ring" })
  ] });
}
function Check({
  label,
  checked,
  onChange
}) {
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("label", { className: "flex items-center gap-2 text-sm font-medium", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx("input", { checked, onChange: (event) => onChange(event.target.checked), type: "checkbox", className: "h-4 w-4 rounded border-input" }),
    label
  ] });
}
export {
  AdminDashboard as component
};
