import { r as reactExports, j as jsxRuntimeExports } from "../_libs/react.mjs";
import { L as Link } from "../_libs/tanstack__react-router.mjs";
import { S as SiteLayout, P as PageHeader } from "./Layout-CqF9pYSV.mjs";
import { c as articles, A as API_URL, d as assetUrl } from "./router-BReRZXck.mjs";
import { b as ArrowUpRight } from "../_libs/lucide-react.mjs";
import "../_libs/tanstack__router-core.mjs";
import "../_libs/tanstack__history.mjs";
import "../_libs/cookie-es.mjs";
import "../_libs/seroval.mjs";
import "../_libs/seroval-plugins.mjs";
import "node:stream/web";
import "node:stream";
import "../_libs/react-dom.mjs";
import "util";
import "crypto";
import "async_hooks";
import "stream";
import "../_libs/isbot.mjs";
import "../_libs/tanstack__query-core.mjs";
import "../_libs/tanstack__react-query.mjs";
function News() {
  const [newsItems, setNewsItems] = reactExports.useState(articles);
  reactExports.useEffect(() => {
    fetch(`${API_URL}/api/content/site-news`).then((response) => response.json()).then((result) => {
      if (Array.isArray(result.data?.items) && result.data.items.length) {
        setNewsItems(result.data.items.map((item) => ({
          ...item,
          img: assetUrl(item.image),
          body: typeof item.body === "string" ? item.body.split(/\n\s*\n/) : item.body
        })));
      }
    }).catch(() => void 0);
  }, []);
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(SiteLayout, { children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx(PageHeader, { eyebrow: "News", title: "Notes from the floor.", lead: "Sourcing trends, factory updates and what's shifting in Bangladesh garment supply." }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("section", { className: "section-reveal container-x grid gap-8 py-24 md:grid-cols-2 lg:grid-cols-3", children: newsItems.map((p) => /* @__PURE__ */ jsxRuntimeExports.jsxs("article", { className: "group overflow-hidden rounded-2xl border border-border bg-card", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "aspect-[5/4] overflow-hidden", children: /* @__PURE__ */ jsxRuntimeExports.jsx("img", { src: p.img, alt: "", loading: "lazy", className: "h-full w-full object-cover transition duration-700 group-hover:scale-105" }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-6", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 text-xs uppercase tracking-widest text-muted-foreground", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: p.tag }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "·" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: p.date })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(Link, { to: "/news/$slug", params: {
          slug: p.slug
        }, className: "mt-3 block font-display text-2xl leading-tight text-primary hover:underline underline-offset-2", children: p.title }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs(Link, { to: "/news/$slug", params: {
          slug: p.slug
        }, className: "mt-5 inline-flex items-center gap-2 text-sm font-medium text-primary", children: [
          "Read article ",
          /* @__PURE__ */ jsxRuntimeExports.jsx(ArrowUpRight, { className: "h-4 w-4" })
        ] })
      ] })
    ] }, p.slug)) })
  ] });
}
export {
  News as component
};
