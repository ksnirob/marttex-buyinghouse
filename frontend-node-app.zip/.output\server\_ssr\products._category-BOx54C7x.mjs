import { r as reactExports, j as jsxRuntimeExports } from "../_libs/react.mjs";
import { L as Link } from "../_libs/tanstack__react-router.mjs";
import { S as SiteLayout, P as PageHeader } from "./Layout-CqF9pYSV.mjs";
import { u as useLightbox, L as Lightbox } from "./Lightbox-0tM-xTMN.mjs";
import { a as Route$1, g as getPublicSiteData, d as assetUrl } from "./router-BReRZXck.mjs";
import { A as ArrowLeft, Z as ZoomIn } from "../_libs/lucide-react.mjs";
import "../_libs/tanstack__router-core.mjs";
import "../_libs/tanstack__history.mjs";
import "../_libs/cookie-es.mjs";
import "../_libs/seroval.mjs";
import "../_libs/seroval-plugins.mjs";
import "node:stream/web";
import "node:stream";
import "../_libs/react-dom.mjs";
import "util";
import "crypto";
import "async_hooks";
import "stream";
import "../_libs/isbot.mjs";
import "../_libs/tanstack__query-core.mjs";
import "../_libs/tanstack__react-query.mjs";
function ProductCategory() {
  const {
    category
  } = Route$1.useParams();
  const [categoryData, setCategoryData] = reactExports.useState(null);
  const [loading, setLoading] = reactExports.useState(true);
  const lb = useLightbox();
  reactExports.useEffect(() => {
    getPublicSiteData().then((result) => setCategoryData(result.categories.find((item) => item.slug === category) || null)).finally(() => setLoading(false));
  }, [category]);
  const gallery = categoryData?.galleryImages || [];
  const images = gallery.map((image) => assetUrl(image.url));
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(SiteLayout, { children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx(PageHeader, { eyebrow: "Products", title: categoryData?.name || (loading ? "Loading..." : "Category"), lead: categoryData?.description }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "container-x py-6", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(Link, { to: "/products", className: "inline-flex items-center gap-2 text-sm text-muted-foreground", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(ArrowLeft, { className: "h-4 w-4" }),
      " All Products"
    ] }) }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("section", { className: "container-x py-12", children: [
      !loading && !gallery.length && /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "rounded-2xl border border-border bg-card p-8", children: "Category not found or has no gallery images." }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "grid gap-5 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4", children: gallery.map((image) => {
        const src = assetUrl(image.url);
        return /* @__PURE__ */ jsxRuntimeExports.jsx("button", { onClick: () => lb.open(images.indexOf(src)), className: "group overflow-hidden rounded-2xl border border-border bg-card text-left shadow-sm", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative aspect-[4/5] overflow-hidden", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("img", { src, alt: image.alt || categoryData?.name || "Product", className: "h-full w-full object-cover transition duration-700 group-hover:scale-105" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "absolute inset-0 grid place-items-center bg-primary/35 opacity-0 transition group-hover:opacity-100", children: /* @__PURE__ */ jsxRuntimeExports.jsx(ZoomIn, { className: "h-7 w-7 text-white" }) })
        ] }) }, src);
      }) })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsx(Lightbox, { images, index: lb.index, onClose: lb.close, onIndex: lb.to })
  ] });
}
export {
  ProductCategory as component
};
