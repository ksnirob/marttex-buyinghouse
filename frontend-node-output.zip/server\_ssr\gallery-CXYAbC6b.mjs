import { r as reactExports, j as jsxRuntimeExports } from "../_libs/react.mjs";
import { S as SiteLayout, P as PageHeader } from "./Layout-DtPkLD29.mjs";
import { f as factory, q as quality, s as sourcing, A as API_URL, d as assetUrl } from "./router-DgiGK9HX.mjs";
import { a as knit, d as denim, w as woven, k as kids } from "./product-kids-BAtRuyBg.mjs";
import "../_libs/tanstack__react-router.mjs";
import "../_libs/tanstack__router-core.mjs";
import "../_libs/tanstack__history.mjs";
import "../_libs/cookie-es.mjs";
import "../_libs/seroval.mjs";
import "../_libs/seroval-plugins.mjs";
import "node:stream/web";
import "node:stream";
import "../_libs/react-dom.mjs";
import "util";
import "crypto";
import "async_hooks";
import "stream";
import "../_libs/isbot.mjs";
import "../_libs/lucide-react.mjs";
import "../_libs/tanstack__query-core.mjs";
import "../_libs/tanstack__react-query.mjs";
const hero = "/assets/hero-garments-CIxYALS4.jpg";
const imgs = [hero, factory, quality, sourcing, knit, denim, woven, kids];
function Gallery() {
  const [images, setImages] = reactExports.useState(imgs.map((url) => ({
    url,
    alt: "Mart Tex garment sourcing gallery"
  })));
  reactExports.useEffect(() => {
    fetch(`${API_URL}/api/content/page-gallery-header`).then((response) => response.json()).then((result) => {
      if (Array.isArray(result.data?.items) && result.data.items.length) {
        setImages(result.data.items.map((image) => ({
          url: assetUrl(image.url),
          alt: image.alt || "Mart Tex garment sourcing gallery"
        })));
      }
    }).catch(() => void 0);
  }, []);
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(SiteLayout, { children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx(PageHeader, { eyebrow: "Gallery", title: "Behind the seams.", lead: "A glimpse into our showrooms, sampling studio and partner factory floors." }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("section", { className: "section-reveal container-x py-24", children: /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "columns-1 gap-6 sm:columns-2 lg:columns-3 [&>*]:mb-6 [&>*]:break-inside-avoid", children: images.map((image, i) => /* @__PURE__ */ jsxRuntimeExports.jsx("img", { src: image.url, alt: image.alt, loading: "lazy", className: "w-full rounded-2xl object-cover" }, `${image.url}-${i}`)) }) })
  ] });
}
export {
  Gallery as component
};
