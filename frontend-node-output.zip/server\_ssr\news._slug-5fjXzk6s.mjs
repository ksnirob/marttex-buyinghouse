import { r as reactExports, j as jsxRuntimeExports } from "../_libs/react.mjs";
import { b as Route, c as articles, A as API_URL, d as assetUrl } from "./router-DgiGK9HX.mjs";
import { L as Link } from "../_libs/tanstack__react-router.mjs";
import { S as SiteLayout } from "./Layout-DtPkLD29.mjs";
import { A as ArrowLeft, C as Calendar } from "../_libs/lucide-react.mjs";
import "../_libs/tanstack__query-core.mjs";
import "../_libs/tanstack__react-query.mjs";
import "../_libs/tanstack__router-core.mjs";
import "../_libs/tanstack__history.mjs";
import "../_libs/cookie-es.mjs";
import "../_libs/seroval.mjs";
import "../_libs/seroval-plugins.mjs";
import "node:stream/web";
import "node:stream";
import "../_libs/react-dom.mjs";
import "util";
import "crypto";
import "async_hooks";
import "stream";
import "../_libs/isbot.mjs";
function NewsDetail() {
  const {
    slug
  } = Route.useParams();
  const [article, setArticle] = reactExports.useState(articles.find((a) => a.slug === slug));
  reactExports.useEffect(() => {
    fetch(`${API_URL}/api/content/site-news`).then((response) => response.json()).then((result) => {
      const item = Array.isArray(result.data?.items) ? result.data.items.find((entry) => entry.slug === slug) : null;
      if (item) {
        setArticle({
          ...item,
          img: assetUrl(item.image),
          body: typeof item.body === "string" ? item.body.split(/\n\s*\n/) : item.body
        });
      }
    }).catch(() => void 0);
  }, [slug]);
  if (!article) {
    return /* @__PURE__ */ jsxRuntimeExports.jsx(SiteLayout, { children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "container-x py-32 text-center", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("h1", { className: "font-display text-4xl text-primary", children: "Article not found" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(Link, { to: "/news", className: "btn-primary mt-8 inline-flex", children: "Back to News" })
    ] }) });
  }
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(SiteLayout, { children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "section-reveal container-x pt-10", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(Link, { to: "/news", className: "inline-flex items-center gap-2 text-sm text-muted-foreground transition hover:text-primary", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(ArrowLeft, { className: "h-4 w-4" }),
      " Back to News"
    ] }) }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "section-reveal container-x mt-6", children: /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "overflow-hidden rounded-3xl", children: /* @__PURE__ */ jsxRuntimeExports.jsx("img", { src: article.img, alt: article.title, loading: "eager", className: "aspect-[16/8] w-full object-cover" }) }) }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("article", { className: "section-reveal container-x max-w-4xl py-14", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-3 text-xs uppercase tracking-widest text-muted-foreground", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "rounded-full bg-secondary px-3 py-1", children: article.tag }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "inline-flex items-center gap-1.5", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Calendar, { className: "h-3 w-3" }),
          " ",
          article.date
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("h1", { className: "mt-6 font-display text-4xl leading-tight text-primary md:text-5xl", children: article.title }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-6 border-l-4 border-primary/30 pl-5 text-lg leading-relaxed text-muted-foreground", children: article.lead }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "mt-10 space-y-6", children: article.body.map((para, i) => /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "leading-relaxed text-foreground/80", children: para }, i)) })
    ] })
  ] });
}
export {
  NewsDetail as component
};
