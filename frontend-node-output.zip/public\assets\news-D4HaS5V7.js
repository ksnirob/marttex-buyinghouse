import{j as t,O as o}from"./index-BvEIn7VO.js";const n=()=>t.jsx(o,{});export{n as component};
