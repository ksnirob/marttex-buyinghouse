const s="/assets/product-knit-Cr2DhAld.jpg",t="/assets/product-denim-CDQDm1R3.jpg",n="/assets/product-woven-CUPOsHic.jpg",o="/assets/product-kids-DgcnQG_p.jpg";export{s as a,t as d,o as k,n as w};
