import { r as reactExports, j as jsxRuntimeExports } from "../_libs/react.mjs";
import { X, d as ChevronLeft, e as ChevronRight } from "../_libs/lucide-react.mjs";
function Lightbox({
  images,
  index,
  onClose,
  onIndex
}) {
  const open = index !== null;
  reactExports.useEffect(() => {
    if (!open) return;
    document.body.style.overflow = "hidden";
    const onKey = (e) => {
      if (e.key === "Escape") onClose();
      if (e.key === "ArrowRight") onIndex(((index ?? 0) + 1) % images.length);
      if (e.key === "ArrowLeft") onIndex(((index ?? 0) - 1 + images.length) % images.length);
    };
    window.addEventListener("keydown", onKey);
    return () => {
      document.body.style.overflow = "";
      window.removeEventListener("keydown", onKey);
    };
  }, [open, index, images.length, onClose, onIndex]);
  if (!open || index === null) return null;
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "fixed inset-0 z-[100] flex items-center justify-center bg-primary/95 p-4 backdrop-blur-sm animate-fade-up", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx(
      "button",
      {
        onClick: onClose,
        "aria-label": "Close",
        className: "absolute right-6 top-6 grid h-12 w-12 place-items-center rounded-full bg-primary-foreground/10 text-primary-foreground transition hover:bg-primary-foreground/20",
        children: /* @__PURE__ */ jsxRuntimeExports.jsx(X, { className: "h-6 w-6" })
      }
    ),
    /* @__PURE__ */ jsxRuntimeExports.jsx(
      "button",
      {
        onClick: (e) => {
          e.stopPropagation();
          onIndex((index - 1 + images.length) % images.length);
        },
        "aria-label": "Previous",
        className: "absolute left-4 grid h-12 w-12 place-items-center rounded-full bg-primary-foreground/10 text-primary-foreground transition hover:bg-primary-foreground/20 md:left-10",
        children: /* @__PURE__ */ jsxRuntimeExports.jsx(ChevronLeft, { className: "h-6 w-6" })
      }
    ),
    /* @__PURE__ */ jsxRuntimeExports.jsx(
      "img",
      {
        src: images[index],
        alt: "",
        className: "max-h-[88vh] max-w-[88vw] rounded-2xl object-contain shadow-2xl animate-zoom-in",
        onClick: (e) => e.stopPropagation()
      }
    ),
    /* @__PURE__ */ jsxRuntimeExports.jsx(
      "button",
      {
        onClick: (e) => {
          e.stopPropagation();
          onIndex((index + 1) % images.length);
        },
        "aria-label": "Next",
        className: "absolute right-4 grid h-12 w-12 place-items-center rounded-full bg-primary-foreground/10 text-primary-foreground transition hover:bg-primary-foreground/20 md:right-10",
        children: /* @__PURE__ */ jsxRuntimeExports.jsx(ChevronRight, { className: "h-6 w-6" })
      }
    ),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "absolute bottom-6 left-1/2 -translate-x-1/2 text-xs uppercase tracking-[0.3em] text-primary-foreground/70", children: [
      index + 1,
      " / ",
      images.length
    ] })
  ] });
}
function useLightbox() {
  const [i, set] = reactExports.useState(null);
  return { index: i, open: (n) => set(n), close: () => set(null), to: (n) => set(n) };
}
export {
  Lightbox as L,
  useLightbox as u
};
