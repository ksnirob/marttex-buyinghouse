const knit = "/assets/product-knit-Cr2DhAld.jpg";
const denim = "/assets/product-denim-CDQDm1R3.jpg";
const woven = "/assets/product-woven-CUPOsHic.jpg";
const kids = "/assets/product-kids-DgcnQG_p.jpg";
export {
  knit as a,
  denim as d,
  kids as k,
  woven as w
};
